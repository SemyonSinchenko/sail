
�
0�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v3.ArgenteaBfsApi�{"version":3,"algorithm":"bfs_direction","source":-5,"max_levels":0,"alpha":14,"beta":24,"partitions":5,"vertices":8,"max_phase_budget":32,"batch_rows":2,"generation":1,"operation_id":"b6c3c63f-fa6b-4919-87f1-dcc1ea9f95fa","snapshot_id":"8d274121-deee-45e1-a51a-bd1abb007bc3","verb":"result","phase":1}F
D
/>
<
:argentea_phase_cd7549ad137341f8908f29adcf078ee4_02_apply_0(