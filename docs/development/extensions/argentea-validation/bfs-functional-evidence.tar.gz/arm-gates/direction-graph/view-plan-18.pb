
�
]�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v3.ArgenteaBfsApi�{"version":3,"algorithm":"bfs_direction","source":-5,"max_levels":14,"alpha":14,"beta":24,"partitions":5,"vertices":8,"max_phase_budget":32,"batch_rows":2,"generation":1,"operation_id":"21dfb9b1-8738-4a4c-b793-73bcf9457059","snapshot_id":"d946369a-fdac-4660-b415-45971b76fc0f","verb":"apply","phase":8}G
E
\?
=
;argentea_phase_f745eee8499b49308729cc7868acce58_17_decide_8(