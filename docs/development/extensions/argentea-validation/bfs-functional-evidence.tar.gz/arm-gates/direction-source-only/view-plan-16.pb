
�
X�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v3.ArgenteaBfsApi�{"version":3,"algorithm":"bfs_direction","source":0,"max_levels":14,"alpha":14,"beta":24,"partitions":5,"vertices":1,"max_phase_budget":32,"batch_rows":2,"generation":1,"operation_id":"5a50f9b1-484c-4af2-b10a-06e98c2f2f52","snapshot_id":"ed1d7e19-99f3-4672-9e34-bc4a254355ba","verb":"apply","phase":7}G
E
W?
=
;argentea_phase_0d3b61041ea640458de62dbc71e1474c_15_decide_7(