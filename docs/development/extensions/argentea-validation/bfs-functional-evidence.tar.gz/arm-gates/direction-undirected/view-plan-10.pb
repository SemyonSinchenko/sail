
�
G�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v3.ArgenteaBfsApi�{"version":3,"algorithm":"bfs_direction","source":10,"max_levels":14,"alpha":14,"beta":24,"partitions":5,"vertices":8,"max_phase_budget":32,"batch_rows":2,"generation":1,"operation_id":"f83aceea-f8a1-4f38-a36c-5308dbaa06cb","snapshot_id":"b76a859e-925a-4a33-a9b5-87b06724c9e3","verb":"apply","phase":4}G
E
F?
=
;argentea_phase_7e9debc5bfbb4372aab179f166a3b9dc_09_decide_4(