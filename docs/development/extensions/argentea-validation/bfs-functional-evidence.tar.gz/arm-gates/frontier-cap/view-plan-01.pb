
�
*�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v3.ArgenteaBfsApi�{"version":3,"algorithm":"bfs_frontier","source":-5,"max_levels":0,"alpha":14,"beta":24,"partitions":5,"vertices":8,"max_phase_budget":32,"batch_rows":2,"generation":1,"operation_id":"d8e5362f-92e6-45bc-bc9a-1bf48fbd3dab","snapshot_id":"de3c7989-eb51-4583-b80f-88e78c6d74a4","verb":"decide","phase":0}E
C
)=
;
9argentea_phase_3d97475a9ec44a0cbd77ff01c8484d42_00_init_0(