
�
`�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v3.ArgenteaBfsApi�{"version":3,"algorithm":"bfs_frontier","source":-5,"max_levels":14,"alpha":14,"beta":24,"partitions":5,"vertices":8,"max_phase_budget":32,"batch_rows":2,"generation":1,"operation_id":"62924210-3ecc-46d1-a443-72a8173d131f","snapshot_id":"9470c72a-8eb0-464d-a9e3-8c75f205288f","verb":"decide","phase":9}F
D
_>
<
:argentea_phase_4a1e9f47d7454098bbab3bf7dc14c0ca_18_apply_8(