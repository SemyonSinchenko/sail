
�
U�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v3.ArgenteaBfsApi�{"version":3,"algorithm":"bfs_frontier","source":0,"max_levels":14,"alpha":14,"beta":24,"partitions":5,"vertices":1,"max_phase_budget":32,"batch_rows":2,"generation":1,"operation_id":"930c3f25-01ee-46db-a751-862c336d64d3","snapshot_id":"27359d7f-2b8a-4945-b9a5-e40e39de18aa","verb":"decide","phase":7}F
D
T>
<
:argentea_phase_d30b882e67d0413aabee007fcf62f497_14_apply_6(