
�
z�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v3.ArgenteaBfsApi�{"version":3,"algorithm":"bfs_frontier","source":10,"max_levels":14,"alpha":14,"beta":24,"partitions":5,"vertices":8,"max_phase_budget":32,"batch_rows":2,"generation":1,"operation_id":"158e3909-de6a-4efb-8231-8b651856b756","snapshot_id":"4224fadc-f8e6-4c77-8ce4-622b4af73d9d","verb":"decide","phase":13}G
E
y?
=
;argentea_phase_bdfd79df805e49fa9a7bb63716d7fe10_26_apply_12(