
�
*�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v3.ArgenteaBfsApi�{"version":3,"algorithm":"bfs_reference","source":-5,"max_levels":0,"alpha":14,"beta":24,"partitions":5,"vertices":8,"max_phase_budget":32,"batch_rows":2,"generation":1,"operation_id":"c15e1afe-3538-4494-a75f-1ad793e691e8","snapshot_id":"333ef1eb-8ba3-4173-93f1-6a5f298e2407","verb":"decide","phase":0}E
C
)=
;
9argentea_phase_7232c59983be44fc9fde48a791608fee_00_init_0(