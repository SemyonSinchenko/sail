
�
*�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v3.ArgenteaBfsApi�{"version":3,"algorithm":"bfs_reference","source":-5,"max_levels":14,"alpha":14,"beta":24,"partitions":5,"vertices":8,"max_phase_budget":32,"batch_rows":2,"generation":1,"operation_id":"55b90101-b9d4-40f4-91be-22e56c49ab55","snapshot_id":"ed6a1101-aea7-45a3-82cc-711a5942d88b","verb":"decide","phase":0}E
C
)=
;
9argentea_phase_6e6def28eebc4e1b8976a45bd5b6c1da_00_init_0(