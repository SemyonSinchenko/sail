
�
F�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v3.ArgenteaBfsApi�{"version":3,"algorithm":"bfs_reference","source":0,"max_levels":14,"alpha":14,"beta":24,"partitions":5,"vertices":1,"max_phase_budget":32,"batch_rows":2,"generation":1,"operation_id":"307174cf-31f5-401e-b3a3-4c1546d2007f","snapshot_id":"6d614729-78c6-4e5d-951f-bf3faf76e62b","verb":"apply","phase":4}G
E
E?
=
;argentea_phase_ffc2987f1f7f42f5acd1e2fca42f997d_09_decide_4(