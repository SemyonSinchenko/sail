
�
t�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v3.ArgenteaBfsApi�{"version":3,"algorithm":"bfs_reference","source":10,"max_levels":14,"alpha":14,"beta":24,"partitions":5,"vertices":8,"max_phase_budget":32,"batch_rows":2,"generation":1,"operation_id":"bd98d502-9de6-4512-badd-1bab77a6a3b8","snapshot_id":"22307c3c-c572-4075-905f-c701b90e3d33","verb":"decide","phase":12}G
E
s?
=
;argentea_phase_295287d6ee774cfd8f45a611e5c43905_24_apply_11(