
�
,�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v3.ArgenteaBfsApi�{"version":3,"algorithm":"bfs_direction","source":-5,"max_levels":0,"alpha":14,"beta":24,"partitions":5,"vertices":8,"max_phase_budget":32,"batch_rows":2,"generation":1,"operation_id":"36876969-3b31-4214-bdde-ed91dd958fd3","snapshot_id":"9ad77460-7524-4313-a46c-2ad40d23cc0b","verb":"decide","phase":0}E
C
+=
;
9argentea_phase_7c65f83d97264e2d87d876a1ed47aed2_00_init_0(