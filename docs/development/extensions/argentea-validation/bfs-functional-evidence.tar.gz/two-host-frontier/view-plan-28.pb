
�
}�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v3.ArgenteaBfsApi�{"version":3,"algorithm":"bfs_frontier","source":-5,"max_levels":14,"alpha":14,"beta":24,"partitions":5,"vertices":8,"max_phase_budget":32,"batch_rows":2,"generation":1,"operation_id":"5b95e396-de10-4f91-bb95-908c4e6113ec","snapshot_id":"8e1927c3-3443-4855-99e4-1c5b09fe490b","verb":"apply","phase":13}H
F
|@
>
<argentea_phase_c200e4bc39974ba599d31ee0ea6d9c7d_27_decide_13(