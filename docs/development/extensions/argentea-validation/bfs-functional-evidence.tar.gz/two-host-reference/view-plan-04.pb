
�
7�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v3.ArgenteaBfsApi�{"version":3,"algorithm":"bfs_reference","source":-5,"max_levels":14,"alpha":14,"beta":24,"partitions":5,"vertices":8,"max_phase_budget":32,"batch_rows":2,"generation":1,"operation_id":"ae4cd487-d779-4a09-87b9-0268dd726e2b","snapshot_id":"ebd89100-d577-4f23-bbcb-67245a77e236","verb":"apply","phase":1}G
E
6?
=
;argentea_phase_5124568c7a914b7898c736278c48f8e4_03_decide_1(