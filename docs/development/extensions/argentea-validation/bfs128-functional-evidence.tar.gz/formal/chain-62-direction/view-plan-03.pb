
�
0�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v3.ArgenteaBfsApi�{"version":3,"algorithm":"bfs_direction","source":0,"max_levels":62,"alpha":14,"beta":24,"partitions":5,"vertices":62,"max_phase_budget":128,"batch_rows":2,"generation":1,"operation_id":"83b5aef0-0b03-459f-b64e-96e98ab19361","snapshot_id":"4f3af9ac-009c-4474-8897-b58e0de952cf","verb":"decide","phase":1}F
D
/>
<
:argentea_phase_57dd1d9c7fca48f388b5c8d893119c53_02_apply_0(