
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v3.ArgenteaBfsApi�{"version":3,"algorithm":"bfs_frontier","source":0,"max_levels":62,"alpha":14,"beta":24,"partitions":5,"vertices":62,"max_phase_budget":128,"batch_rows":2,"generation":1,"operation_id":"95d5b2e1-7c71-40a2-bcfc-0f615dee28ef","snapshot_id":"950409d0-fbd2-4f7f-94cf-3e8216fb2eb3","verb":"apply","phase":44}I
G
�@
>
<argentea_phase_eafe1112d94a4aaa8dd000ae7f33b8a4_89_decide_44(