
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v3.ArgenteaBfsApi�{"version":3,"algorithm":"bfs_reference","source":0,"max_levels":62,"alpha":14,"beta":24,"partitions":5,"vertices":62,"max_phase_budget":128,"batch_rows":2,"generation":1,"operation_id":"016f9425-d3e7-4862-970f-4b4be73736cb","snapshot_id":"15252a8b-680d-4cbc-a21c-3bf72dcaaa36","verb":"result","phase":63}I
G
�@
>
<argentea_phase_9e88dce9c11d4980aca5f40513fda5b1_126_apply_62(