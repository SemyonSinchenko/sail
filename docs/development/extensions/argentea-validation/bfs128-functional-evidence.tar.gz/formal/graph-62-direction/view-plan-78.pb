
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v3.ArgenteaBfsApi�{"version":3,"algorithm":"bfs_direction","source":-5,"max_levels":62,"alpha":14,"beta":24,"partitions":5,"vertices":8,"max_phase_budget":128,"batch_rows":2,"generation":1,"operation_id":"fedb8d2c-7402-4d1d-8458-c448387d2f91","snapshot_id":"b6a1896c-0252-41bc-899d-6d7c838eb607","verb":"apply","phase":38}I
G
�@
>
<argentea_phase_b62945c37a474536bdb8c02cd01de0d2_77_decide_38(