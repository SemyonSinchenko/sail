
�
(�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
.type.googleapis.com/nutmeg.v2.ArgenteaDeltaApi�{"version":2,"algorithm":"pagerank_delta","operation_id":"a70db5ca-02c1-4742-8dc1-3461df9cc6ce","snapshot_id":"9b1807ee-9d6e-4e98-98c8-c2a16da37958","generation":1,"partitions":5,"vertices":3,"damping":0.85,"tolerance":1e-12,"max_pushes":0,"max_phase_budget":32,"batch_rows":2,"verb":"decide","phase":0}E
C
'=
;
9argentea_delta_925185737cb64314976c3a8c4e82f25a_00_init_0(