
�
.�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
.type.googleapis.com/nutmeg.v2.ArgenteaDeltaApi�{"version":2,"algorithm":"pagerank_delta","operation_id":"46ac1e0d-6173-490e-94e9-476a146e623d","snapshot_id":"b9a07b14-b4f2-47f0-bf03-fbe91a8d66d4","generation":1,"partitions":5,"vertices":3,"damping":0.85,"tolerance":1e-12,"max_pushes":0,"max_phase_budget":32,"batch_rows":2,"verb":"result","phase":1}F
D
->
<
:argentea_delta_9e536f256a6448d29bd7d0db21205b1b_02_apply_0(