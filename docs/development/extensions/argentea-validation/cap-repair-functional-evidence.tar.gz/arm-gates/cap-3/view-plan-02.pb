
�
+�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
.type.googleapis.com/nutmeg.v2.ArgenteaDeltaApi�{"version":2,"algorithm":"pagerank_delta","operation_id":"de45b995-702f-4601-ba11-9f7310916352","snapshot_id":"18ca6255-3e4d-41a2-a10e-dcdcb99b0636","generation":1,"partitions":5,"vertices":3,"damping":0.85,"tolerance":1e-12,"max_pushes":0,"max_phase_budget":32,"batch_rows":2,"verb":"apply","phase":0}G
E
*?
=
;argentea_delta_12b9c677104348de897979e79cd14299_01_decide_0(