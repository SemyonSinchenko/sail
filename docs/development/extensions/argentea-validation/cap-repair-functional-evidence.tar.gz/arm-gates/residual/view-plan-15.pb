
�
R�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
.type.googleapis.com/nutmeg.v2.ArgenteaDeltaApi�{"version":2,"algorithm":"pagerank_delta","operation_id":"3fb487a4-709c-4380-bd3d-9aea598cdb90","snapshot_id":"0e83ad93-738f-44b9-a4d8-03636fa2e81b","generation":1,"partitions":5,"vertices":3,"damping":0.85,"tolerance":0.001,"max_pushes":7,"max_phase_budget":32,"batch_rows":2,"verb":"decide","phase":7}F
D
Q>
<
:argentea_delta_3742fde5f56a49b2968cca61ac6d1c88_14_apply_6(