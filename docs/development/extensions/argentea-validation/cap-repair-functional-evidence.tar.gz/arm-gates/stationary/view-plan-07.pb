
�
:�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
.type.googleapis.com/nutmeg.v2.ArgenteaDeltaApi�{"version":2,"algorithm":"pagerank_delta","operation_id":"6babd0c8-7755-4cad-948a-ef70ad165ea8","snapshot_id":"68711e4d-58b2-44c4-8714-759af59af321","generation":1,"partitions":5,"vertices":3,"damping":0.85,"tolerance":1e-12,"max_pushes":7,"max_phase_budget":32,"batch_rows":2,"verb":"decide","phase":3}F
D
9>
<
:argentea_delta_be637ff3ee8c4dbcbbb3c06f1d1e76d4_06_apply_2(