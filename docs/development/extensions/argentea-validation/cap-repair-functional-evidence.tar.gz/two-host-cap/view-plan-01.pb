
�
*�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
.type.googleapis.com/nutmeg.v2.ArgenteaDeltaApi�{"version":2,"algorithm":"pagerank_delta","operation_id":"48d77c9a-add5-4192-93ff-310fcb45b69f","snapshot_id":"da6c2c4e-d522-47a1-a42a-5e55afa82ad5","generation":1,"partitions":5,"vertices":3,"damping":0.85,"tolerance":1e-12,"max_pushes":0,"max_phase_budget":32,"batch_rows":2,"verb":"decide","phase":0}E
C
)=
;
9argentea_delta_d8b2c17e8e4b4d51b9bb1ef5a4700d6f_00_init_0(