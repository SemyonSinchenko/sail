
�
u�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
.type.googleapis.com/nutmeg.v2.ArgenteaDeltaApi�{"version":2,"algorithm":"pagerank_delta","operation_id":"04471d41-5cce-4e6e-a511-e5ec20e4589e","snapshot_id":"281d07e0-66d4-4946-9d42-e8ad69970a0d","generation":1,"partitions":5,"vertices":3,"damping":0.85,"tolerance":0.001,"max_pushes":7,"max_phase_budget":32,"batch_rows":2,"verb":"apply","phase":12}H
F
t@
>
<argentea_delta_835febf6f985468f92818390dc567b3a_25_decide_12(