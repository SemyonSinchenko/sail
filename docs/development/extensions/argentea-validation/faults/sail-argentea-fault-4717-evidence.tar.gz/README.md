# Argentea fault qualification: both first-error paths

Final qualifier: 4717680503c7e31505af13cc79741310feff5870, descendant of
error-path correction a37e1dc88a35662965a3be9e3730541aa518f6df and frozen
original qualifier 9a7d0ffea46e316ab2d344290c613302503d0ad2.
Host: d9c6381a0effe07ab89ddb87739a0b2003b9664b, artifact SHA256
8138df899bfb7978dedf3020faa190c289c1bb5fce0bbeaa0cbc5f9e21343a1c.
Native: 50195d14aafca6559aace887bf699d2d18c62c6f, installed native binary SHA256
feb5702b64e11eafaf780d2632c63aabf4e28ca9fbde0fc2d39d74b88357a921.

All six fresh live cases passed: cancellation, explicit pre-init bind quota,
default worker loss, explicit loss of native owner 0, explicit loss of native
owner 1, and the unchanged 277 positive residual PageRank control. The first
three worker-loss paths were scheduler_failure, scheduler_failure and
bare_h2_transport, respectively. The selected owner was mapped to a supervised
PID after both native owners initialized and both worker processes were stopped.
Every native task remained on attempt zero; every task in the failed job reached
a terminal state. The survivor closed once, no result returned, and session
shutdown removed all observed processes and staging files. The positive control
returned correct ranks and closed all owners. Functional proof on two Capitola
processes only; no timing, two-host fault, zero-RSS, or retained-Arrow-buffer claim.

The final output task's placement is observed independently from the stage
inventory and task log. In the explicit owner 1 run, the killed worker also ran
the final output task and the first RPC was bare HTTP/2. Neither the fixture nor
the audit asserts that this placement always determines error ordering.

The host repair makes failed-job cleanup report terminal task state before
unassigning workers. The original 9a7 qualifier separately failed a literal error
phrase check on a repaired-host bare-HTTP/2 run despite terminal task inventory.
The new qualifier accepts exactly the observed typed bare error only alongside
authoritative FAILED-job, supervised victim/window, complete no-replay task and
owner, and cleanup evidence. Generic unrelated errors are rejected. The wrapped
scheduler path remains explicit. All 292 Python tests pass, including negative
controls for both paths, owner selection and output-task placement.

Earlier evidence remains immutable and is not reclassified:

- Baseline 038c host/9a7 qualifier failures:
  /tmp/sail-argentea-fault-9a7d-evidence.tar.gz,
  SHA256 08e4643873b7c18ff7d6fe429bb400f059430006909d9fac13540f36e9363f56.
- Repaired d9c host/original 9a7 qualifier: four passed, one strict qualifier failed.
  /tmp/sail-argentea-fault-d9c-evidence.tar.gz,
  SHA256 1737ad524168ed0c5e18fcd80487e38883a2b66a9c21924f44e1a2ed124823ee.
- Repaired d9c host/a37 qualifier: 13 passed, all worker losses scheduler path.
  /tmp/sail-argentea-fault-a37e-evidence.tar.gz,
  SHA256 62fa6423a20d5d43a8862bb778ba55d664a152b2f1c1efed5cc553b39c9f5e86.

`gates/summary.json` contains every exact fresh command. `source-gate.json`
rechecks all qualifier source files, native package files and Sail binary after
the runs. `qualifier-changes.patch` carries the focused changes since 9a7.
`FAULTS.md` provides standalone commands and defines the proof boundary.
Morrobay was not used for these controls and remained reserved for measurements.
