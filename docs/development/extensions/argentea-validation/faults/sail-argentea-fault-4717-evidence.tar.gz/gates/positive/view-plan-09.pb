
�
@�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
.type.googleapis.com/nutmeg.v2.ArgenteaDeltaApi�{"version":2,"algorithm":"pagerank_delta","operation_id":"8a692841-5fc2-4975-9479-b5d5f9d2070c","snapshot_id":"8a0114b0-b505-4579-ad4e-613d774816ea","generation":1,"partitions":5,"vertices":3,"damping":0.85,"tolerance":0.001,"max_pushes":7,"max_phase_budget":32,"batch_rows":2,"verb":"decide","phase":4}F
D
?>
<
:argentea_delta_71d7ebf357734e26954a52bce6139db5_08_apply_3(