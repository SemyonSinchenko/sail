import datetime, hashlib, json, pathlib, subprocess
root=pathlib.Path('/tmp/sail-argentea-fault-4717-host-d9c-gates'); root.mkdir(exist_ok=False)
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
python='/tmp/sail-argentea-cap-arm-venv/bin/python'
host='/tmp/sail-argentea-artifacts/sail-arm64-d9c6381a0eff'
assert sha(host)=='8138df899bfb7978dedf3020faa190c289c1bb5fce0bbeaa0cbc5f9e21343a1c'
summary=dict(started_utc=now(),fault_source='4717680503c7e31505af13cc79741310feff5870',positive_source='277ae341c90cad66e118a667565c0699ece3d77b',runtime_source='d9c6381a0effe07ab89ddb87739a0b2003b9664b',native_source='50195d14aafca6559aace887bf699d2d18c62c6f',host_sha256=sha(host),cases=[],boundary='Functional fault qualification; all attempts retained; no performance claim')
for source,expected in [('/tmp/sail-argentea-fault-owner-work',summary['fault_source']),('/tmp/sail-argentea-cap-combined-work',summary['positive_source'])]:
 assert subprocess.check_output(['git','-C',source,'rev-parse','HEAD'],text=True).strip()==expected
 assert not subprocess.check_output(['git','-C',source,'status','--porcelain'],text=True)
def save(): (root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
save()
for name,case,source,script in [('cancel','cancel','/tmp/sail-argentea-fault-owner-work','qualify_faults.py'),('quota','quota','/tmp/sail-argentea-fault-owner-work','qualify_faults.py'),('worker-loss-default','worker-loss','/tmp/sail-argentea-fault-owner-work','qualify_faults.py'),('worker-loss-owner0','worker-loss','/tmp/sail-argentea-fault-owner-work','qualify_faults.py'),('worker-loss-owner1','worker-loss','/tmp/sail-argentea-fault-owner-work','qualify_faults.py'),('positive','residual','/tmp/sail-argentea-cap-combined-work','qualify_delta.py')]:
 cmd=[python,source+'/examples/extensions/argentea/python/'+script,'--case',case,'--output',str(root/name),'--sail-binary',host,'--runtime-source-sha',summary['runtime_source'],'--native-source-sha',summary['native_source']]
 if name.endswith(('owner0','owner1')):cmd+=['--victim-owner',name[-1]]
 record=dict(name=name,command=cmd,started_utc=now()); summary['cases'].append(record); save()
 with (root/(name+'.log')).open('w') as log: result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 receipt=json.loads((root/name/'receipt.json').read_text()) if (root/name/'receipt.json').exists() else {}
 record.update(finished_utc=now(),returncode=result.returncode,outcome=receipt.get('outcome','missing receipt')); save(); print(name,result.returncode,record['outcome'],flush=True)
summary.update(finished_utc=now(),host_bytes_unchanged=sha(host)==summary['host_sha256'],verdict='PASS' if all(x['returncode']==0 for x in summary['cases']) else 'FAILED_CASE_RETAINED'); save()
