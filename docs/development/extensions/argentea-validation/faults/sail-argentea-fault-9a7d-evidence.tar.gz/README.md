# Argentea ARM fault qualification

Qualifier source: 9a7d0ffea46e316ab2d344290c613302503d0ad2 (clean detached source, parent277ae341c90cad66e118a667565c0699ece3d77b). Host038c9b9597d3fcf7e0b8c30c1253d7d77563f012; native50195d14aafca6559aace887bf699d2d18c62c6f. Binary and installed native file hashes are in every final receipt and independently rechecked after the campaign. No Morrobay fault/performance run, no public deployment.

## Verdict

- 250 Python tests passed on exact clean qualifier source.
- Fresh cancellation PASS: registered interrupt RPC; both native owners initialized; both stopped in supervised group before interruption;64 native tasks terminal, attempt0, one native job; both owners close; session views, process group, all worker PIDs and staging files clean.
- Fresh bind-time quota PASS: explicit `procedure memory budget exceeded (limit 1)` with no native partition initialized;64 native tasks stopped without retry; process/session/staging cleanup. This does not establish allocation-refusal cleanup after CSR initialization.
- Fresh worker-loss FAIL: whole job FAILED and surviving native owner closed, but killed-worker native task rows remained RUNNING after heartbeat retirement and30s polling. Error first reached client as raw h2 body failure. Final process/session/staging cleanup passed. Do not describe this case as qualified.

`frozen-gates/summary.json` contains exact commands and every outcome. `source-gate.json` pins tests and unchanged artifact hashes. All earlier development failures and probes are retained separately.

## Earlier controls

- Pre-init pause blocked ordinary input exchange; controller canceled safely; no fault qualification claim.
- Post-init cancellation probe established the held active window; the formal gate additionally confirms OS stop state.
- Quota65536 allocation-refusal candidate surfaced peer cancellation without retained quota cause; unqualified.
- Worker-loss1 native failure/close succeeded but immediate diagnostic SQL hit the dead worker before heartbeat retirement. The qualifier now waits for the existing driver retirement event before diagnostic SQL; it never retries the failed native query.
- Worker-loss2 native task audit passed but the PID check mistook an unreaped killed child for a running process. The final qualifier records ps state: killed child must be absent or Z before session stop, surviving worker neither Z nor T, all PIDs absent after final reap.
- Worker-loss3, then the frozen worker-loss case, exposed RUNNING task records. Native/host source has not been changed here. A separate host investigation owns any repair and must rerun the same strict qualifier.

These are functional failure/lifecycle observations on Capitola, not benchmark timings, two-host fault coverage, an RSS-zero result, or native Arrow-buffer retention evidence.
