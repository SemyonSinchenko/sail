import sys,os,signal,threading,time,json,re
from pathlib import Path
from types import SimpleNamespace
root=Path('/tmp/sail-argentea-fault-work')
sys.path[:0]=[str(root/'examples/extensions/argentea/python')]
import qualify_delta as q
from pyspark.sql.connect.session import SparkSession
from pyspark.sql.connect.client.retries import DefaultPolicy
from pyspark_pecan import CancellationToken
from argentea_runtime import local_server
from argentea_readiness import wait_for_workers
from argentea_resource_evidence import operation_records,read_complete_log
from argentea_delta_client import ArgenteaDelta
out=Path('/tmp/sail-argentea-fault-window-quota-probe-2');out.mkdir()
a=SimpleNamespace(output=out,sail_binary=Path('/tmp/sail-argentea-artifacts/sail-arm64-038c9b9597d3'),mode='process-cluster',partitions=2,threads=4,worker_task_slots=32,sail_pool_bytes=2<<30,native_quota=1)
e={};pids=[];controller=None;token=CancellationToken()
try:
 with local_server(a,[]) as (endpoint,driver):
  s=SparkSession.builder.remote(endpoint).create()
  s.client.set_retry_policies([DefaultPolicy(max_retries=0,initial_backoff=100,max_backoff=100,jitter=0)])
  wait_for_workers(s,evidence=e)
  pids=[int(v) for v in re.findall(r'extension process worker \d+: pid=Some\((\d+)\)',(out/'server.log').read_text())]
  assert len(pids)==2
  def obs(ev): e['request']=ev['request']
  try:
   ArgenteaDelta(s,observer=obs).pagerank(s.range(4096).selectExpr('id'),s.range(4096*128).selectExpr('id % 4096 AS src', '(id + 1) % 4096 AS dst'),max_pushes=7,partitions=2,tolerance=1e-12,batch_rows=1,cancellation=token)
  except BaseException as err:e['query_error']=repr(err)
  finally:
   if controller:controller.join(30)
   for p in pids:
    try:os.kill(p,signal.SIGCONT)
    except ProcessLookupError:pass
   s.stop()
finally:
 (out/'probe.json').write_text(json.dumps(e,indent=2,default=str))
 print(json.dumps(e,indent=2,default=str))
