import sys,os,signal,threading,time,json,re
from pathlib import Path
from types import SimpleNamespace
root=Path('/tmp/sail-argentea-fault-work')
sys.path[:0]=[str(root/'examples/extensions/argentea/python')]
import qualify_delta as q
from pyspark.sql.connect.session import SparkSession
from pyspark.sql.connect.client.retries import DefaultPolicy
from pyspark_pecan import CancellationToken
from argentea_runtime import local_server
from argentea_readiness import wait_for_workers
from argentea_resource_evidence import operation_records,read_complete_log
from argentea_delta_client import ArgenteaDelta
out=Path('/tmp/sail-argentea-fault-window-probe-1');out.mkdir()
a=SimpleNamespace(output=out,sail_binary=Path('/tmp/sail-argentea-artifacts/sail-arm64-038c9b9597d3'),mode='process-cluster',partitions=2,threads=4,worker_task_slots=32,sail_pool_bytes=2<<30,native_quota=256<<20)
e={};pids=[];controller=None;token=CancellationToken()
try:
 with local_server(a,[]) as (endpoint,driver):
  s=SparkSession.builder.remote(endpoint).create()
  s.client.set_retry_policies([DefaultPolicy(max_retries=0,initial_backoff=100,max_backoff=100,jitter=0)])
  wait_for_workers(s,evidence=e)
  pids=[int(v) for v in re.findall(r'extension process worker \d+: pid=Some\((\d+)\)',(out/'server.log').read_text())]
  assert len(pids)==2
  def obs(ev):
   global controller
   e['request']=ev['request'];e['signals']=[]
   def send(pid,sig):
    os.kill(pid,sig);e['signals'].append([pid,sig.name,time.time()])
   for p in pids:send(p,signal.SIGSTOP)
   def control():
    try:
     for p in pids:
      send(p,signal.SIGCONT)
      end=time.monotonic()+8
      while True:
       rr=operation_records(read_complete_log(out/'server.log'),ev['request'])
       if any(r['event']=='init' and r['pid']==p for r in rr): break
       if time.monotonic()>end:raise TimeoutError(f'no init from {p}; records={rr}')
       time.sleep(.002)
      send(p,signal.SIGSTOP)
     e['barrier']=operation_records(read_complete_log(out/'server.log'),ev['request'])
     assert not any(r['event']=='result' for r in e['barrier'])
     e['window']='reached'
     token.cancel()
    except BaseException as err:e['controller_error']=repr(err);token.cancel()
    finally:
     for p in pids:
      try:send(p,signal.SIGCONT)
      except ProcessLookupError:pass
   controller=threading.Thread(target=control);controller.start()
  try:
   ArgenteaDelta(s,observer=obs).pagerank(s.createDataFrame([(0,),(1,),(2,)],'id long'),s.createDataFrame([(0,1),(1,2),(2,0)],'src long,dst long'),max_pushes=1,partitions=2,tolerance=1e-12,batch_rows=1,cancellation=token)
  except BaseException as err:e['query_error']=repr(err)
  finally:
   if controller:controller.join(30)
   for p in pids:
    try:os.kill(p,signal.SIGCONT)
    except ProcessLookupError:pass
   s.stop()
finally:
 (out/'probe.json').write_text(json.dumps(e,indent=2,default=str))
 print(json.dumps(e,indent=2,default=str))
