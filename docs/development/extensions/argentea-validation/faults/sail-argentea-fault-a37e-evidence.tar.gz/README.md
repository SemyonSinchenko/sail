# Fresh a37 Argentea fault qualification

Qualifier a37e1dc88a35662965a3be9e3730541aa518f6df, host
d9c6381a0effe07ab89ddb87739a0b2003b9664b, native
50195d14aafca6559aace887bf699d2d18c62c6f. All13 live controls passed:
cancellation, explicit pre-init bind quota, ten worker-loss attempts, and the
unchanged277 positive residual control. The correction strengthens loss auditing
with a FAILED job, supervised victim/window matching, all job tasks terminal and
attempt0, explicit Connect retries0 and recognized first-error paths.

All ten worker-loss calls observed scheduler_failure. No live bare_h2_transport
claim is made for this archive. The retained earlier9a7/d9c bare-h2 attempt failed
its original error-phrase assertion and remains a separate failed receipt. The
new qualifier has282 passing Python tests, including explicit negative controls
for both first-error paths. Source, host and installed native bytes were rehashed
after these runs. This evidence is on Capitola with two local processes only;
no performance, two-host fault, zero-RSS or retained-Arrow-buffer claim.

Every run and diagnostic is retained. `source-gate.json` gives the complete13-case
inventory, source identities and first error messages. Further focused ordering
coverage must use new output directories and retain this campaign unchanged.
