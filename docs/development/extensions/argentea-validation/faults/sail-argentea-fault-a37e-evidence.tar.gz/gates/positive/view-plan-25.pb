
�
p�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
.type.googleapis.com/nutmeg.v2.ArgenteaDeltaApi�{"version":2,"algorithm":"pagerank_delta","operation_id":"16785e75-3000-484c-844f-31dc6f39881b","snapshot_id":"55908762-92db-4b23-8bf8-4f51670265a7","generation":1,"partitions":5,"vertices":3,"damping":0.85,"tolerance":0.001,"max_pushes":7,"max_phase_budget":32,"batch_rows":2,"verb":"decide","phase":12}G
E
o?
=
;argentea_delta_d727ed9838c142319d2a3f81efef4218_24_apply_11(