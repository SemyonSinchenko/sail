import datetime,hashlib,json,pathlib,subprocess
root=pathlib.Path('/tmp/sail-argentea-fault-a37e-host-d9c-gates')
summary=dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),cases=[],purpose='Seek entirely bare h2 first RPC, retaining every unchanged frozen qualifier attempt')
def save():(root/'additional-loss-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for i in range(2,6):
 name=f'worker-loss-{i}';cmd=['/tmp/sail-argentea-cap-arm-venv/bin/python','/tmp/sail-argentea-fault-order-work/examples/extensions/argentea/python/qualify_faults.py','--case','worker-loss','--output',str(root/name),'--sail-binary','/tmp/sail-argentea-artifacts/sail-arm64-d9c6381a0eff','--runtime-source-sha','d9c6381a0effe07ab89ddb87739a0b2003b9664b','--native-source-sha','50195d14aafca6559aace887bf699d2d18c62c6f']
 record=dict(name=name,command=cmd,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());summary['cases'].append(record);save()
 with (root/(name+'.log')).open('x') as log:run=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 r=json.loads((root/name/'receipt.json').read_text());e=r.get('checks',{}).get('error','')
 record.update(returncode=run.returncode,outcome=r['outcome'],first_error=e,first_error_type=r.get('checks',{}).get('error_type'),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),bare_h2=e.startswith('h2 protocol error:'))
 save();print(name,run.returncode,record['bare_h2'],e,flush=True)
 if record['bare_h2']:break
summary['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
