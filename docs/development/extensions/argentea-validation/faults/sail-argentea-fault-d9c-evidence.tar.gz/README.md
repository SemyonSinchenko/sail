# Repaired-host Argentea fault evidence, immutable qualifier9a7

Host d9c6381a0effe07ab89ddb87739a0b2003b9664b; native50195d14aafca6559aace887bf699d2d18c62c6f.
The original frozen9a7 qualifier is unchanged. Cancel, bind quota, wrapped-h2
worker loss and a277 positive residual control passed. A second worker-loss
attempt returned a completely bare h2 body-read SparkRuntimeException and FAILED
its unchanged qualifier because the error lacked "automatic retry disabled".
Do not describe this full campaign as an unqualified pass or replace that receipt.

The bare-h2 attempt has a FAILED job and all70 stored tasks terminal:65 CANCELED,
5 SUCCEEDED, all attempt0. Its survivor close is present; all three processes
were absent after teardown and staging was empty. The failing assertion is the
error phrase, after task/owner checks. These are direct observations about the
repaired task-state bookkeeping, not a passed9a7 verdict. A new qualifier must
be frozen and rerun to revise the diagnostic error-path assumption.

Sail forward_job_output preserves the first observed data-plane error. The
separate scheduler refresh_job failure action adds the retry-disabled prefix.
The order is not globally guaranteed. Earlier baseline038c retained failures,
deterministic actual-method regression and host compile/test evidence live in
separate immutable archives; these new receipts do not rewrite those outcomes.

`gates/summary.json` is the original four-case pass summary;
`gates/additional-loss-summary.json` retains the later failed fifth attempt.
`source-gate.json` gives the complete five-case verdict and verifies that every
qualifier source file, installed native package file and Sail artifact remained
byte-identical after the runs. Two processes on Capitola only; no two-host fault,
performance, zero-RSS or retained-Arrow-array claim.
