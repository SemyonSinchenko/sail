
�
1�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
.type.googleapis.com/nutmeg.v2.ArgenteaDeltaApi�{"version":2,"algorithm":"pagerank_delta","operation_id":"9253e339-1389-40dd-8cf4-6cb3580484d8","snapshot_id":"abb5229f-18f1-47ee-9823-3a19b8dcf3d3","generation":1,"partitions":5,"vertices":3,"damping":0.85,"tolerance":0.001,"max_pushes":7,"max_phase_budget":32,"batch_rows":2,"verb":"apply","phase":1}G
E
0?
=
;argentea_delta_f7bb571e30384b8a85fbd14082275a58_03_decide_1(