import pathlib,subprocess,json,datetime,sys,os
root=pathlib.Path('/tmp/sail-argentea-wcc-integration-work');sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert sha=='d03579496d71741bbc672dc4e1e352f0f67b0b0a';assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
output=pathlib.Path('/tmp/sail-argentea-graph-fault-d035-arm-gates');output.mkdir(exist_ok=False)
record=dict(source=sha,cases=[])
env=os.environ.copy();env['PYTHONPATH']='examples/extensions/argentea/python:examples/extensions/nutmeg/python:examples/extensions/graph-algorithms/src'
cmd=['/tmp/sail-argentea-sssp-arm-venv/bin/python','-m','pytest','-q','examples/extensions/argentea/python','examples/extensions/benchmarks','examples/extensions/nutmeg/tests','examples/extensions/graph-algorithms/tests']
with (output/'unit-gates.log').open('w') as f:subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
record['unit_gates']=dict(command=cmd,outcome='passed')
cases=[('pagerank_delta','cancel',None)]
for algorithm in ['wcc_reference','wcc_star','sssp_reference','sssp_delta_star']:
 cases.extend([(algorithm,'cancel',None),(algorithm,'worker-loss',0),(algorithm,'worker-loss',1)])
for algorithm,case,victim in cases:
 name=f'{algorithm}-{case}'+('' if victim is None else f'-owner{victim}')
 cmd=['/tmp/sail-argentea-sssp-arm-venv/bin/python','examples/extensions/argentea/python/qualify_faults.py','--algorithm',algorithm,'--case',case,'--sail-binary','/tmp/sail-argentea-artifacts/sail-arm64-d9c6381a0eff','--runtime-source-sha','d9c6381a0effe07ab89ddb87739a0b2003b9664b','--native-source-sha','00ebb7ac96eefcb66d52c4364104e95579eacd4e','--output',str(output/name)]
 if victim is not None:cmd+=['--victim-owner',str(victim)]
 item=dict(name=name,command=cmd,started=datetime.datetime.now(datetime.timezone.utc).isoformat());record['cases'].append(item)
 with (output/(name+'.log')).open('w') as f:run=subprocess.run(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT)
 item.update(returncode=run.returncode,finished=datetime.datetime.now(datetime.timezone.utc).isoformat());p=output/name/'receipt.json'
 if p.exists():item['outcome']=json.loads(p.read_text())['outcome']
 (output/'summary.json').write_text(json.dumps(record,indent=2)+'\n');print(name,item.get('outcome','missing'),run.returncode,flush=True)
 if run.returncode:sys.exit(run.returncode)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==sha
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
record['outcome']='passed';(output/'summary.json').write_text(json.dumps(record,indent=2)+'\n')
