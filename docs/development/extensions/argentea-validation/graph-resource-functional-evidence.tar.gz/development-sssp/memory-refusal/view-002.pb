
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":524288,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"e78bf6ea-50ad-4718-b703-5218c8a9d708","snapshot_id":"a613ba7d-40e2-44cc-b79f-39bcb4eb40eb","verb":"apply","phase":0}H
F
�?
=
;argentea_phase_68c39fa3e37848cf8f58a217af67ece8_01_decide_0(