
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"e38b9b2b-dd09-4a2c-8649-d2240014e2b9","snapshot_id":"6bb67898-2d0a-4140-992c-d1ef9bb7c00f","verb":"decide","phase":0}F
D
�=
;
9argentea_phase_2f195ca4d49c41f3afcc1d313f655acf_00_init_0(