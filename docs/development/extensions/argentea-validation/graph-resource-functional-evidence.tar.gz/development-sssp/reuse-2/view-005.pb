
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"28274779-db23-437c-b0b9-0e7e93baebd4","snapshot_id":"123d2415-7686-41dc-8662-bbed6e40a8bd","verb":"decide","phase":2}G
E
�>
<
:argentea_phase_fa953b21aaa746fe96c0973b71e15d2f_04_apply_1(