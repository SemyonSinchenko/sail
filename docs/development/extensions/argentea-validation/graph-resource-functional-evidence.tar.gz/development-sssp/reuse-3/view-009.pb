
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"808f3a11-d1c1-419a-9b21-243679d313df","snapshot_id":"90e7f995-4a83-473c-baac-796679dc101b","verb":"result","phase":4}G
E
�>
<
:argentea_phase_e9b3a57cdf2449d390989823510b1a3e_08_apply_3(