
�
9�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"b0ae7c3b-647c-462f-8825-31030cbb06c6","snapshot_id":"f7e27173-3a34-4bf5-8fe2-ab9083abdbd0","verb":"apply","phase":2}G
E
8?
=
;argentea_phase_3a6115bb7b9d4b77b113ee18dfbc2696_05_decide_2(