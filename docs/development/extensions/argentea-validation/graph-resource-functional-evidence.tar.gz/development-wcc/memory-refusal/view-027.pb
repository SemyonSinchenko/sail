
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_star","max_rounds":3,"seed":42,"partitions":2,"vertices":786432,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"8ace4449-d1dc-48c7-aa04-d63e01256794","snapshot_id":"1676068c-3897-4550-99a0-f22a2ef41550","verb":"result","phase":13}H
F
�?
=
;argentea_phase_08663bcdadd24891a288c1db92cd6f27_26_apply_12(