
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_star","max_rounds":3,"seed":42,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"7166a187-7efe-44b3-8d13-c7d48a0272e8","snapshot_id":"58edd760-a864-4a9a-abd1-58392ea5bf2b","verb":"apply","phase":0}H
F
�?
=
;argentea_phase_f257432744d04e31b25d8fc4570c3275_01_decide_0(