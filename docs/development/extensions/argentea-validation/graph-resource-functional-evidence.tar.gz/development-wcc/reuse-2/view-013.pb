
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_star","max_rounds":3,"seed":42,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"7753d2a4-7f0a-441e-b86a-0f070d7912fc","snapshot_id":"34ad24e7-b4ef-4809-a5b9-50fdc430f233","verb":"decide","phase":6}G
E
�>
<
:argentea_phase_cfbf0d9f349c4b51b3bed498fc10e2c0_12_apply_5(