
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_star","max_rounds":3,"seed":42,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"2e344751-f72c-4dc4-99f2-d4328017dcf1","snapshot_id":"e4740813-083d-449e-ab6c-386e0360f947","verb":"apply","phase":11}I
G
�@
>
<argentea_phase_149bd7efae864e469e155aa6d850385d_23_decide_11(