
�
i�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_star","max_rounds":3,"seed":42,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"271e9146-b581-4cdd-a7a3-cbaaf1fc07d1","snapshot_id":"512f4494-fdab-4535-a787-d1873568cff4","verb":"apply","phase":10}H
F
h@
>
<argentea_phase_ab2a6041171c4ff6914c5e2b62ca514d_21_decide_10(