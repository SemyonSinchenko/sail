
�
9�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":524288,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"8637e2af-e8ec-4091-b725-f9c4fe86b59a","snapshot_id":"9899af5d-1f3d-4731-9fda-46a3551d0c98","verb":"apply","phase":2}G
E
8?
=
;argentea_phase_bb315c7969dd47ffb5f6bc041ed841c6_05_decide_2(