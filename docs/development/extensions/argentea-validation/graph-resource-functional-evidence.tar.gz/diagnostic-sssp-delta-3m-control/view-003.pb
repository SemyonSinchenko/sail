
�
0�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":16384,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"ad783685-5c06-4f4a-9ccd-166687c8ec0f","snapshot_id":"92db9fb6-a257-4a50-9147-a991653de2e8","verb":"decide","phase":1}F
D
/>
<
:argentea_phase_c2974bc9935e47799a57ccf9bac5a8e7_02_apply_0(