
�
-�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":16384,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"7881aa75-857b-4e37-9171-becbba290632","snapshot_id":"7ea00302-fe67-43d3-b403-92079bed0d9b","verb":"apply","phase":0}G
E
,?
=
;argentea_phase_70a5822f030e453facb984f81315dcfd_01_decide_0(