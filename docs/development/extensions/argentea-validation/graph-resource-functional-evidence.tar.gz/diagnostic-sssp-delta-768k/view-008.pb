
�
?�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":16384,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"07db9192-b047-46e1-9d28-8b0b4fa88e71","snapshot_id":"cd771d27-1e7d-4436-805b-3835b5af6e0d","verb":"apply","phase":3}G
E
>?
=
;argentea_phase_d6064805f90843da9f20963e52c0ec64_07_decide_3(