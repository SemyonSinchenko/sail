
�
l�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_star","max_rounds":3,"seed":42,"partitions":2,"vertices":16384,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"ac242483-501a-41c9-b03c-d969a177db7e","snapshot_id":"0f41e933-55d8-4509-b3e0-f5e341b69dde","verb":"decide","phase":11}G
E
k?
=
;argentea_phase_60ed3fab2c5d40f59c6ec2ef8e235cb4_22_apply_10(