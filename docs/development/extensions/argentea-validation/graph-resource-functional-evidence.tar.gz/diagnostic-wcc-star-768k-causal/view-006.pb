
�
9�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_star","max_rounds":3,"seed":42,"partitions":2,"vertices":16384,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"4fc3ec4c-2b00-4b9a-b9c0-25c50f7847bc","snapshot_id":"ea06ce93-1df8-45df-81ee-9cf8e9066007","verb":"apply","phase":2}G
E
8?
=
;argentea_phase_abef276e156c4666b9182d8bde770763_05_decide_2(