
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":524288,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"2f1040a4-55c5-464a-b8dd-81f4245b6efd","snapshot_id":"823f31d5-39d5-45e3-8de0-3c2ebcf6affe","verb":"decide","phase":1}G
E
�>
<
:argentea_phase_58f4c5c547ae411895d8229c4e3e5082_02_apply_0(