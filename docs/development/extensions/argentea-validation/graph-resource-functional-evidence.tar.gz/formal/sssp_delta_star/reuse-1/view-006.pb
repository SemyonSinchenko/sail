
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"14bef4cf-c24d-4ced-adcd-5eb0ec9af0b2","snapshot_id":"230528c7-6d0c-40ae-ad55-01b9739bdac0","verb":"apply","phase":2}H
F
�?
=
;argentea_phase_8f4bf61eea664983a7e66e68bc286dc1_05_decide_2(