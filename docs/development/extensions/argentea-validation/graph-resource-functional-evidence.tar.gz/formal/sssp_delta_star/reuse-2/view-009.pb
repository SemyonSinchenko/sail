
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"86f82274-61b1-42c5-b6dc-71bf03bfa089","snapshot_id":"09cc49ce-5e42-43ba-bdd1-3daaa2a23115","verb":"result","phase":4}G
E
�>
<
:argentea_phase_0b9ec01975d4428ca4be0c4900d9c98f_08_apply_3(