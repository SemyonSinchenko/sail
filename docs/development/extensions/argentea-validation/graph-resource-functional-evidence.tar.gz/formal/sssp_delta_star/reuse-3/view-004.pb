
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"5949de01-f9bb-4a6d-bea8-dac127f832ec","snapshot_id":"f9edd1a5-0c70-47b2-a2b6-1bb660c57925","verb":"apply","phase":1}H
F
�?
=
;argentea_phase_8467c6ad38fa4820a90effd03f5b5464_03_decide_1(