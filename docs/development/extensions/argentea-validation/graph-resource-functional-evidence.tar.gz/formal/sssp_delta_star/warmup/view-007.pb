
�
<�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"7f0c1efb-4dfe-4fca-b015-66daa894c75b","snapshot_id":"a970c104-fe29-473a-adc6-9751cefbea7f","verb":"decide","phase":3}F
D
;>
<
:argentea_phase_9fa47d2514ce461096f9f3a2dc708f54_06_apply_2(