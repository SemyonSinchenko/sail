
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_reference","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":524288,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"a7d27b40-05d1-43e6-9d7d-36e5f93ff536","snapshot_id":"f09a37f3-8bdd-40d0-851d-ca39e1e88075","verb":"decide","phase":3}G
E
�>
<
:argentea_phase_95db3bde73c640bbaeedc83f4ba02438_06_apply_2(