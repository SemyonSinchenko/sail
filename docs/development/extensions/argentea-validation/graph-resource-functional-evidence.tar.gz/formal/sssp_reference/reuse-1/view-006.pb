
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_reference","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"b5b25038-a2a2-45aa-a2db-7c1a510258bf","snapshot_id":"d7907214-7422-4eca-aa52-f2fb2c51317e","verb":"apply","phase":2}H
F
�?
=
;argentea_phase_d543732dbf1b4f578527c1c32fcfb238_05_decide_2(