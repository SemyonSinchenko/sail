
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_reference","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"7337012c-84c4-4048-9d2b-49d196cb0ca9","snapshot_id":"c6152566-e226-405b-acee-05ccf7619bab","verb":"apply","phase":0}H
F
�?
=
;argentea_phase_af52c5c04ad3426aaf66d376a9c58c9e_01_decide_0(