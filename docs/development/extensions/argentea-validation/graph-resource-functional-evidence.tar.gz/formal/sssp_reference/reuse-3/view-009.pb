
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_reference","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"35a14bed-0981-476c-9a94-89839b65586d","snapshot_id":"03dcce43-aecc-4141-8712-8fad40d47fbf","verb":"result","phase":4}G
E
�>
<
:argentea_phase_3cb4c23a3dcb4be3a8c58269d607b57f_08_apply_3(