
�
3�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_reference","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"d2d9fbd4-d210-4ee0-929b-884407dd7ee1","snapshot_id":"976ac4e3-09f2-46f4-846b-d2a7ae033fdf","verb":"apply","phase":1}G
E
2?
=
;argentea_phase_0a3bd7656511423ab9d3326d2342d419_03_decide_1(