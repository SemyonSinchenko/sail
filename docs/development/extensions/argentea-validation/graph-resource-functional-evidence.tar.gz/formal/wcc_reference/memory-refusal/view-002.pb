
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_reference","max_rounds":3,"seed":42,"partitions":2,"vertices":786432,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"5f3682dd-ce33-43bc-a1b5-7bb187638607","snapshot_id":"bde5103c-2cfb-4b9a-948f-672af99f03ed","verb":"apply","phase":0}H
F
�?
=
;argentea_phase_317f1943e70d4d6cb2beb5d375c07a0d_01_decide_0(