
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_reference","max_rounds":3,"seed":42,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"1705fd97-90ac-413a-83c8-55a35757504e","snapshot_id":"797ef473-afd1-482c-a7ef-1442f79e80f5","verb":"apply","phase":0}H
F
�?
=
;argentea_phase_68f516992fcc4b9189658f1383da54bc_01_decide_0(