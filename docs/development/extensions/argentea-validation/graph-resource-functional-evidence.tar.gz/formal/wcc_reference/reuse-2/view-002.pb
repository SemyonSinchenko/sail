
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_reference","max_rounds":3,"seed":42,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"b6f58fbf-fe8e-48af-8bf1-1699b7aaa3d3","snapshot_id":"ea4947a1-b0b1-4b3b-a27e-61e46034cc48","verb":"apply","phase":0}H
F
�?
=
;argentea_phase_6a999e40f1d94d57a071082659380905_01_decide_0(