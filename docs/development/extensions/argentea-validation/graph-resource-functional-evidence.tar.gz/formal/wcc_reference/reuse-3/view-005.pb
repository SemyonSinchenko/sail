
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_reference","max_rounds":3,"seed":42,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"536248ca-9994-4ca5-9a46-9107db4ba83f","snapshot_id":"153ed8b6-ad31-4696-9723-9c0246698d06","verb":"decide","phase":2}G
E
�>
<
:argentea_phase_df68ed94cef4440a922c6642c5a7f530_04_apply_1(