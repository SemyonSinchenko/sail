
�
6�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_reference","max_rounds":3,"seed":42,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"762413cd-7296-419a-9ecc-cad551764d7e","snapshot_id":"2ec05ea1-2f7a-4ed6-a217-7d392f098f85","verb":"decide","phase":2}F
D
5>
<
:argentea_phase_43f70483a6c2434b964594a6264daafe_04_apply_1(