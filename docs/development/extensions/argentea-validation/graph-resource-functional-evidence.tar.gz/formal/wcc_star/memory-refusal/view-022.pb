
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_star","max_rounds":3,"seed":42,"partitions":2,"vertices":786432,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"cc8c74f7-737d-4b1e-b458-f05b3de1c9ad","snapshot_id":"460592a5-f627-40d8-97dc-c30fdbfdda74","verb":"apply","phase":10}I
G
�@
>
<argentea_phase_bcd20ca44b5741759640912bdb4dc356_21_decide_10(