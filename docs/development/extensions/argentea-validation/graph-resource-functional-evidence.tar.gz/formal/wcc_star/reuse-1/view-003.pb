
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_star","max_rounds":3,"seed":42,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"638f8ca4-6856-4053-8d49-15e54657fdbc","snapshot_id":"29648df8-e48a-488e-8865-cb25c78476cf","verb":"decide","phase":1}G
E
�>
<
:argentea_phase_9abd6811ed2c4705879e8205864a5ab9_02_apply_0(