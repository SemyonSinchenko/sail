
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_star","max_rounds":3,"seed":42,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"914f1390-f2d7-4247-a723-198ee1b14283","snapshot_id":"a38c4fbe-ec82-4cd8-adff-ed33e450e22e","verb":"apply","phase":8}H
F
�?
=
;argentea_phase_7ce0c64f899d4874a7d7870a507b28f9_17_decide_8(