
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_star","max_rounds":3,"seed":42,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"7bfb98f5-4f56-4fab-97f5-6b2117fdebc5","snapshot_id":"26a20cef-8ecd-479c-a348-2152b7bfddd4","verb":"decide","phase":1}G
E
�>
<
:argentea_phase_106384b8a40a48288c0557ec6c1e80ab_02_apply_0(