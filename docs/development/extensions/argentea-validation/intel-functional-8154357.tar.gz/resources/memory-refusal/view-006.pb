
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":524288,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"fe0a3817-db33-4af1-9e64-8f6f0e34ea10","snapshot_id":"a2ea49d7-ae92-4642-8424-3a06cdbc375e","verb":"apply","phase":2}H
F
�?
=
;argentea_phase_3b48b0f91bba46fa83c01bb6e4b3faa9_05_decide_2(