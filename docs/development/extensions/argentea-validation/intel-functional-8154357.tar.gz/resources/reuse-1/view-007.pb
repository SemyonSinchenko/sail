
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"6559f774-3925-4cbc-92bc-fe24d9d985f1","snapshot_id":"6badb7ed-f0c0-4271-8ec2-c482faa5b6bc","verb":"decide","phase":3}G
E
�>
<
:argentea_phase_815399813f2b4d92a3199de40ae7600e_06_apply_2(