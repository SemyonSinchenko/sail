
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"9831cb8b-374e-4797-a818-978a8f3bf8bc","snapshot_id":"5e857959-b87c-4b57-b538-178c868aee93","verb":"decide","phase":0}F
D
�=
;
9argentea_phase_7383158778154c81abc2fc94381f4a74_00_init_0(