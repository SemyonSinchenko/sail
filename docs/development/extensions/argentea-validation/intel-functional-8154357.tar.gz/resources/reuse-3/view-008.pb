
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"e6b81e3d-ec59-40f9-9b9d-e0b60154ad42","snapshot_id":"3b5d312c-a7e8-4b8a-842a-18f3672153c5","verb":"apply","phase":3}H
F
�?
=
;argentea_phase_056b086f66a7458fa8556001d477518c_07_decide_3(