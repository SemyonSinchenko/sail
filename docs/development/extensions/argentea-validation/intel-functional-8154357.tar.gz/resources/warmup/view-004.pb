
�
3�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"add27be6-0cfc-460e-80e8-8621b55aa29c","snapshot_id":"29ee0ea0-73f2-457d-8b06-6c8829aa45f4","verb":"apply","phase":1}G
E
2?
=
;argentea_phase_750b31f734eb4cef9ac6648298616881_03_decide_1(