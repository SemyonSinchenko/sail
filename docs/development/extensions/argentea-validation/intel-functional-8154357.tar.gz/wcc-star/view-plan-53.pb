
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_star","max_rounds":19,"seed":42,"partitions":5,"vertices":8,"max_phase_budget":128,"batch_rows":2,"generation":1,"operation_id":"4f057697-60be-4355-8459-d9fcda1a6c3d","snapshot_id":"40f46b02-52ee-4a19-8b8e-9826a5191886","verb":"decide","phase":26}H
F
�?
=
;argentea_phase_2b8fcf7fd09c4d1b965583ab5af9a4fe_52_apply_25(