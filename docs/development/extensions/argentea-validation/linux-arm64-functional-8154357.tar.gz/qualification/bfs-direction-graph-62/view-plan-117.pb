
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v3.ArgenteaBfsApi�{"version":3,"algorithm":"bfs_direction","source":-5,"max_levels":62,"alpha":14,"beta":24,"partitions":5,"vertices":8,"max_phase_budget":128,"batch_rows":2,"generation":1,"operation_id":"2769cfd4-26a7-4817-b4d7-1c4f2b64021a","snapshot_id":"887a8656-1bb1-49db-81da-37ec99bbfe43","verb":"decide","phase":58}I
G
�@
>
<argentea_phase_af895bf688954cb9980c181de9170f36_116_apply_57(