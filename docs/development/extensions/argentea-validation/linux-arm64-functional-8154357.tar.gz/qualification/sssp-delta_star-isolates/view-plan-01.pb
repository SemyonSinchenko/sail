
�
)�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":62,"source":-5,"delta":4.0,"partitions":5,"vertices":4,"max_phase_budget":128,"batch_rows":2,"generation":1,"operation_id":"10bd1a17-1bcb-4eeb-9dff-b71bc94a3ebc","snapshot_id":"da988248-14b0-42e0-a5a7-c6c02a59de01","verb":"decide","phase":0}E
C
(=
;
9argentea_phase_b7d03e571e29456cae2a166f1308cc77_00_init_0(