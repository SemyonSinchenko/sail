
�
+�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_reference","max_rounds":0,"seed":42,"partitions":5,"vertices":8,"max_phase_budget":128,"batch_rows":2,"generation":1,"operation_id":"5f2768f9-2c39-436e-b041-003280f07018","snapshot_id":"9b1e1d22-57ec-4ebd-b5ef-34697095285a","verb":"apply","phase":0}G
E
*?
=
;argentea_phase_95c2d604dd1f4f899ed00ffc670a945d_01_decide_0(