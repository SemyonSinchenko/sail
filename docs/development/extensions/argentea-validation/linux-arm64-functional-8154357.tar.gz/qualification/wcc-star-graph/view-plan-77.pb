
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_star","max_rounds":19,"seed":42,"partitions":5,"vertices":8,"max_phase_budget":128,"batch_rows":2,"generation":1,"operation_id":"963755f9-1035-4664-883c-0c3248dbf3ac","snapshot_id":"aabe888d-28d1-42c5-8254-ed475fbc5c36","verb":"decide","phase":38}H
F
�?
=
;argentea_phase_ce221e11e0644dc180690d7fe229f58e_76_apply_37(