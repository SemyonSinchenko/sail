
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":524288,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"92fedcb7-9fe2-4834-9f08-ecddd89e7b78","snapshot_id":"54097257-f464-46b8-bc81-0da136202034","verb":"decide","phase":3}G
E
�>
<
:argentea_phase_9c93d8c05e4542abb46b1c5f2dd51a1b_06_apply_2(