
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"985739e4-ef73-49f7-8646-5142fe6f2a9c","snapshot_id":"62478b9f-87d7-45fe-b5bc-ccf55e8e51e4","verb":"decide","phase":0}F
D
�=
;
9argentea_phase_1fe3f15bc1d748bea60f4a86c77519a5_00_init_0(