
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"62826370-5c97-48e7-810a-ce3d4c6f8158","snapshot_id":"e7b98dbb-9f47-4748-bd8b-ec81e59c5d68","verb":"decide","phase":0}F
D
�=
;
9argentea_phase_77bbe49d88a4477d80a8a64d22a235c7_00_init_0(