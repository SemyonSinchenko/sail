
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":3,"source":0,"delta":4.0,"partitions":2,"vertices":16,"max_phase_budget":128,"batch_rows":32,"generation":1,"operation_id":"9896dbd4-5ee3-42c0-8adb-79351d8cc999","snapshot_id":"67555459-b9ca-4b3d-9d61-338545b56f6c","verb":"decide","phase":0}F
D
�=
;
9argentea_phase_4655c6a69b694ba8bd010275dbb2dde6_00_init_0(