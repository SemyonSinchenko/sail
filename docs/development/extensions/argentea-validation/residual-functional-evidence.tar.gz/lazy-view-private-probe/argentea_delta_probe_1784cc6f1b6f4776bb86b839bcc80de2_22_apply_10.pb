
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
.type.googleapis.com/nutmeg.v2.ArgenteaDeltaApi�{"version":2,"algorithm":"pagerank_delta","operation_id":"880b82e0-2fc4-4688-836a-1053f3b80c0a","snapshot_id":"b52835a7-5d99-48a0-b20c-6f24ec231bd4","generation":1,"partitions":5,"vertices":3,"damping":0.85,"tolerance":0.001,"max_pushes":7,"max_phase_budget":32,"batch_rows":2,"verb":"apply","phase":10}O
M
�F
D
Bargentea_delta_probe_1784cc6f1b6f4776bb86b839bcc80de2_21_decide_10(