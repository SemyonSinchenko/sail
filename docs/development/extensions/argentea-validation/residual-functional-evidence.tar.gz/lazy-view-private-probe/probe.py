#!/usr/bin/env python3
"""PRIVATE diagnostic: unchanged host guard, lazy session-view composition."""
import argparse
import contextlib
import io
import json
from pathlib import Path
import shutil
import sys
import traceback
import uuid

REPO = Path('/tmp/sail-argentea-v2-qualification-gate')
EXAMPLES = REPO/'examples/extensions'
sys.path[:0] = [str(EXAMPLES/'argentea/python'),str(EXAMPLES/'graph-algorithms/src'),str(EXAMPLES/'scripts'),str(EXAMPLES/'benchmarks')]
from runtime import git,group_exists,native_package_identity,package_versions,sha256
from qualify_delta import save,utc
from qualify_resources import inventory,wait_empty
from argentea_runtime import local_server
from argentea_evidence import parse_log,parse_worker_tasks
from argentea_resource_evidence import live_pids,read_complete_log,wait_closed
from argentea_delta_evidence import validate_rows,validate_audit
from argentea_delta_client import ArgenteaDelta,ArgenteaDeltaRelation,ArgenteaDeltaResult,build_plan,_read_diagnostics
from pyspark.sql.connect.dataframe import DataFrame
from pyspark.sql.connect import functions as F
from pyspark.sql.connect.session import SparkSession
from pyspark.sql.connect.client.retries import DefaultPolicy
from pyspark_pecan import GraphAlgorithms

parser=argparse.ArgumentParser()
parser.add_argument('--case',choices=['views','stationary'],required=True)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
args.output=args.output.resolve();args.output.mkdir(exist_ok=False)
args.mode='process-cluster';args.partitions=5;args.threads=4;args.worker_task_slots=32
args.sail_pool_bytes=2<<30;args.native_quota=256<<20
args.sail_binary=Path('/tmp/sail-argentea-artifacts/sail-arm64-038c9b9597d3')
shutil.copyfile(__file__,args.output/'probe.py')
source=git(REPO,'rev-parse','HEAD')
assert source=='9ea08c3a477b420154061dff67dd114aaede92ea'
assert not git(REPO,'status','--porcelain')
receipt=dict(started_utc=utc(),outcome='running-private-diagnostic',source_commit=source,
    runtime_source_sha='038c9b9597d3fcf7e0b8c30c1253d7d77563f012',native_source_sha='f11fe6e8a091e4be56a21712850d2a1a205c3e6c',
    binary_sha256=sha256(args.sail_binary),native_package=native_package_identity(),packages=package_versions(),
    probe_sha256=sha256(Path(__file__)),arguments={k:str(v) if isinstance(v,Path) else v for k,v in vars(args).items()},
    boundary='private composition experiment, unchanged published client/host/native; functional evidence only',cleanup_errors=[])
check=receipt['checks']=dict(ids=[0,1,2],edges=[(0,1),(1,1)] if args.case=='views' else [(0,1),(1,2),(2,0)],view_registrations=[],view_drops=[])

def execute(spark):
    vertices=spark.createDataFrame([(x,) for x in check['ids']],'id long')
    edges=spark.createDataFrame(check['edges'],'src long,dst long')
    def observed(event):
        check['request']=event['request']
        (args.output/'client-plan.pb').write_bytes(event['plan_bytes'])
    if args.case=='stationary':
        return ArgenteaDelta(spark,observer=observed).pagerank(vertices,edges,max_pushes=0,partitions=5,tolerance=1e-12,batch_rows=2)
    def body(run,nodes,links,count):
        native_nodes=nodes.select('id',F.pmod(F.col('id'),F.lit(5)).cast('long').alias('owner'))
        native_edges=links.select('src','dst',F.pmod(F.col('src'),F.lit(5)).cast('long').alias('owner'))
        _,base=build_plan(spark,native_nodes,native_edges,vertices_count=count,max_pushes=7,partitions=5,tolerance=1e-3,batch_rows=2)
        check['request']=base
        prefix='argentea_delta_probe_'+uuid.uuid4().hex
        owned=[]
        def stage(verb,phase,inputs):
            frame=DataFrame(ArgenteaDeltaRelation(dict(base,verb=verb,phase=phase),inputs),spark)
            alias=f'{prefix}_{len(owned):02d}_{verb}_{phase}'
            serialized=frame._plan.to_proto(spark.client).SerializeToString()
            plan_file=args.output/(alias+'.pb');plan_file.write_bytes(serialized)
            info=dict(alias=alias,verb=verb,phase=phase,plan_bytes=len(serialized),plan_sha256=sha256(plan_file),registered=False)
            check['view_registrations'].append(info);owned.append(alias)
            save(args.output/'progress.json',check)
            frame.createTempView(alias)
            info['registered']=True
            records,_=parse_log(read_complete_log(args.output/'server.log'))
            info['native_receipts_after_registration']=len(records)
            assert not records,'native execution during lazy view registration'
            save(args.output/'progress.json',check)
            print(f'registered {verb}:{phase}, {len(serialized)} bytes, native receipts=0',flush=True)
            return spark.table(alias)
        try:
            frame=stage('init',0,(native_nodes,native_edges))
            for phase in range(15):
                frame=stage('decide',phase,(frame,))
                frame=stage('apply',phase,(frame,))
            frame=stage('result',15,(frame,))
            final_plan=frame._plan.to_proto(spark.client).SerializeToString()
            (args.output/'client-plan.pb').write_bytes(final_plan)
            capture=io.StringIO()
            with contextlib.redirect_stdout(capture):frame.explain(mode='extended')
            (args.output/'terminal-explain.txt').write_text(capture.getvalue())
            records,_=parse_log(read_complete_log(args.output/'server.log'))
            check['native_receipts_before_terminal_action']=len(records)
            assert not records,'native execution before terminal materialization'
            run.cancellation.check()
            path,stored=run.materialize(frame,expected_rows=count)
            diagnostics=_read_diagnostics(stored,base,run.cancellation)
            retained=run.finish(path,stored,algorithm='argentea-pagerank-delta',iterations=diagnostics['pushes'],converged=True)
            return ArgenteaDeltaResult(retained,base,final_plan,diagnostics)
        finally:
            for alias in reversed(owned):
                info=dict(alias=alias)
                try:
                    info['drop_return']=spark.catalog.dropTempView(alias)
                    info['still_exists']=spark.catalog.tableExists(alias)
                    assert not info['still_exists']
                except BaseException as error:
                    info['error']=repr(error);receipt['cleanup_errors'].append(dict(operation='drop_view',**info))
                check['view_drops'].append(info)
                save(args.output/'progress.json',check)
    return GraphAlgorithms(spark)._run(vertices,edges,5,None,body)

try:
    with local_server(args,receipt['cleanup_errors']) as(endpoint,pid):
        receipt['driver_pid']=pid
        spark=SparkSession.builder.remote(endpoint).create()
        spark.client.set_retry_policies([DefaultPolicy(max_retries=0,initial_backoff=100,max_backoff=100,jitter=0)])
        try:
            result=execute(spark)
            with result:
                rows=[r.asDict() for r in result.native_frame.collect()]
                check.update(rows=rows,result_path=result.path,actual_pushes=result.pushes,certificate_passes=result.certificate_passes,
                    residual=result.residual,native_phase_count=result.native_phase_count,
                    result_validation=validate_rows(rows,check['ids'],check['edges'],result.request))
                assert result.pushes==0 if args.case=='stationary' else result.pushes>0
            wait_closed(args.output/'server.log',check['request'])
            check['worker_endpoints'],check['stages']=inventory(spark)
        finally:
            try:
                if 'stages' not in check:
                    check['worker_endpoints'],check['stages']=inventory(spark)
            finally:spark.stop()
            check['post_session_storage']=wait_empty(args.output/'staging')
    log=(args.output/'server.log').read_text();records,supervisors=parse_log(log)
    receipt['native_receipts']=records
    receipt['native_execution']=validate_audit(records,check['rows'],check['request'],stages=check['stages'],task_statuses=parse_worker_tasks(log),worker_endpoints=check['worker_endpoints'],minimum_workers=2)
    assert not receipt['cleanup_errors']
    receipt['outcome']='passed-private-diagnostic'
except BaseException:
    receipt.update(outcome='failed-private-diagnostic',error=traceback.format_exc())
    raise
finally:
    receipt['finished_utc']=utc()
    log=(args.output/'server.log').read_text() if (args.output/'server.log').exists() else ''
    records,supervisors=parse_log(log)
    receipt['native_receipts']=records
    if 'driver_pid' in receipt:
        receipt['process_cleanup']=live_pids([receipt['driver_pid'],*[r['pid'] for r in records],*[r['pid'] for r in supervisors]])
        receipt['driver_process_group_exists']=group_exists(receipt['driver_pid'])
    receipt['remaining_staging_files']=[str(p) for p in (args.output/'staging').rglob('*') if p.is_file() or p.is_symlink()]
    receipt['end_source_commit']=git(REPO,'rev-parse','HEAD');receipt['end_source_dirty']=git(REPO,'status','--porcelain')
    save(args.output/'receipt.json',receipt)
    print(json.dumps(dict(outcome=receipt['outcome'],receipt=str(args.output/'receipt.json')),sort_keys=True))
