
�
+�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
.type.googleapis.com/nutmeg.v2.ArgenteaDeltaApi�{"version":2,"algorithm":"pagerank_delta","operation_id":"d57a3198-5eec-4af4-b8ef-33a40ec0d6bc","snapshot_id":"9fa0c6c2-b08c-4895-9537-79517b2fc310","generation":1,"partitions":5,"vertices":3,"damping":0.85,"tolerance":1e-12,"max_pushes":0,"max_phase_budget":32,"batch_rows":2,"verb":"apply","phase":0}G
E
*?
=
;argentea_delta_4cc3c5279b154a5ea397ede1b07ff58f_01_decide_0(