
�
.�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
.type.googleapis.com/nutmeg.v2.ArgenteaDeltaApi�{"version":2,"algorithm":"pagerank_delta","operation_id":"162b0e7e-b46c-40b0-9594-97eac93fedf2","snapshot_id":"dbe34814-da8d-4cf5-8e57-7c948c6fc970","generation":1,"partitions":5,"vertices":3,"damping":0.85,"tolerance":1e-12,"max_pushes":0,"max_phase_budget":32,"batch_rows":2,"verb":"result","phase":1}F
D
->
<
:argentea_delta_200a236a13d5458b9163394cfbede3fb_02_apply_0(