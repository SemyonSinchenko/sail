
�
@�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
.type.googleapis.com/nutmeg.v2.ArgenteaDeltaApi�{"version":2,"algorithm":"pagerank_delta","operation_id":"e660b3c4-7a4b-40bf-b504-f3d64a18c0d4","snapshot_id":"b3a33a0a-6cc1-44bc-9ebf-e973ceab26ac","generation":1,"partitions":5,"vertices":3,"damping":0.85,"tolerance":0.001,"max_pushes":7,"max_phase_budget":32,"batch_rows":2,"verb":"decide","phase":4}F
D
?>
<
:argentea_delta_4abca23dff90451b980f2e4eb81e7158_08_apply_3(