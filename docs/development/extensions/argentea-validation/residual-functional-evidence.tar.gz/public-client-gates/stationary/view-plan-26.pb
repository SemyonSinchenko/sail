
�
s�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
.type.googleapis.com/nutmeg.v2.ArgenteaDeltaApi�{"version":2,"algorithm":"pagerank_delta","operation_id":"a5480f87-da8b-45a1-a632-b45a9b975d99","snapshot_id":"12f57f95-ee57-4fbd-b093-26e4bd14be4c","generation":1,"partitions":5,"vertices":3,"damping":0.85,"tolerance":1e-12,"max_pushes":7,"max_phase_budget":32,"batch_rows":2,"verb":"apply","phase":12}H
F
r@
>
<argentea_delta_3681f64e98304652ae0b3bb832529c17_25_decide_12(