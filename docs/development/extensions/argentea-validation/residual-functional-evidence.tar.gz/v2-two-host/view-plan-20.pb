
�
c�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
.type.googleapis.com/nutmeg.v2.ArgenteaDeltaApi�{"version":2,"algorithm":"pagerank_delta","operation_id":"284a08ef-5f70-4833-a527-858d4ea006ef","snapshot_id":"acad7e62-c0f5-4e6b-893e-d79dd8a8d6fa","generation":1,"partitions":5,"vertices":3,"damping":0.85,"tolerance":0.001,"max_pushes":7,"max_phase_budget":32,"batch_rows":2,"verb":"apply","phase":9}G
E
b?
=
;argentea_delta_7a13b06edd8a40eaa6285058f4acd056_19_decide_9(