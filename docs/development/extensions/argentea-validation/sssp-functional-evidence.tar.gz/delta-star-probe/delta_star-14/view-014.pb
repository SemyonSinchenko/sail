
�
O�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":14,"source":-5,"delta":4.0,"partitions":3,"vertices":8,"max_phase_budget":128,"batch_rows":2,"generation":1,"operation_id":"4e77aa4e-57dc-44b7-801e-8e89bff54573","snapshot_id":"c5b7e690-1f4b-42ec-ad1a-896187811dfa","verb":"apply","phase":6}G
E
N?
=
;argentea_phase_ea02c36dca924c1f9348692d8bf14fda_13_decide_6(