
�
+�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":0,"source":-5,"delta":4.0,"partitions":5,"vertices":8,"max_phase_budget":128,"batch_rows":2,"generation":1,"operation_id":"9d559221-e1a9-4225-a0f2-eb8cc85ed3bf","snapshot_id":"b753324b-30c6-4b14-abbd-b4e1892a0e3a","verb":"apply","phase":0}G
E
*?
=
;argentea_phase_8cc605d0c06d41be9a4195be70096fce_01_decide_0(