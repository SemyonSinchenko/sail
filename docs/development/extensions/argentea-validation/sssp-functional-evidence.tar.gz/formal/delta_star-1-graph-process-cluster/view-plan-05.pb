
�
4�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":1,"source":-5,"delta":4.0,"partitions":5,"vertices":8,"max_phase_budget":128,"batch_rows":2,"generation":1,"operation_id":"8f1cb11a-a952-4640-a335-735af1da3168","snapshot_id":"826c8450-0a78-41eb-929d-97f8e05bf28e","verb":"result","phase":2}F
D
3>
<
:argentea_phase_7adbd28795f144d594c459100c4349a6_04_apply_1(