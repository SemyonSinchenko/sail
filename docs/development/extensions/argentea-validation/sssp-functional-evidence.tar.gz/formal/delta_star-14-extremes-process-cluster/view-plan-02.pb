
�
+�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":14,"source":9223372036854775807,"delta":4.0,"partitions":5,"vertices":3,"max_phase_budget":128,"batch_rows":2,"generation":1,"operation_id":"5aabe4b1-89de-4be2-bf40-050f4e453be7","snapshot_id":"e6be3abf-209d-4ff6-8822-ace5ed4ae396","verb":"apply","phase":0}G
E
*?
=
;argentea_phase_1cece9dee4fe430289247a21e76bdf59_01_decide_0(