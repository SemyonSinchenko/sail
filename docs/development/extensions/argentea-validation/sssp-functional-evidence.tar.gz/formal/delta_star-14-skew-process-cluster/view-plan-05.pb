
�
4�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_delta_star","max_rounds":14,"source":-5,"delta":4.0,"partitions":5,"vertices":5,"max_phase_budget":128,"batch_rows":2,"generation":1,"operation_id":"11d91ba4-783c-48d8-adbc-6e12292f3660","snapshot_id":"364c32ed-55ed-4df7-81a9-30ac12bc2c80","verb":"decide","phase":2}F
D
3>
<
:argentea_phase_199bd4af600b412b80fbc35d705f82e2_04_apply_1(