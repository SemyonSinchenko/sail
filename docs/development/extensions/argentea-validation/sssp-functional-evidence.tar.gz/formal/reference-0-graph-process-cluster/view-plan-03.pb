
�
.�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_reference","max_rounds":0,"source":-5,"delta":4.0,"partitions":5,"vertices":8,"max_phase_budget":128,"batch_rows":2,"generation":1,"operation_id":"acaa73ec-5ad5-4cf2-bdd4-2d80f5a45cb3","snapshot_id":"08f2b10a-efb7-45c0-a6c6-11cbb1e37986","verb":"result","phase":1}F
D
->
<
:argentea_phase_909bad43653246359397c060e6828bdd_02_apply_0(