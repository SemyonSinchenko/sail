
�
1�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_reference","max_rounds":14,"source":9223372036854775807,"delta":4.0,"partitions":5,"vertices":3,"max_phase_budget":128,"batch_rows":2,"generation":1,"operation_id":"7ef2d12e-b48c-47c0-b27d-8eebc65154da","snapshot_id":"64b6868b-396a-4fef-b988-c19d554fec5b","verb":"apply","phase":1}G
E
0?
=
;argentea_phase_6a7b9efa31c14297a9c7e5443d87e268_03_decide_1(