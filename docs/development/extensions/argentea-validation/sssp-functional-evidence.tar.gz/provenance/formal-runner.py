import pathlib,subprocess,json,datetime,sys
root=pathlib.Path('/tmp/sail-argentea-wcc-integration-work')
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();assert sha=='00ebb7ac96eefcb66d52c4364104e95579eacd4e';assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
output=pathlib.Path('/tmp/sail-argentea-sssp-00ebb-arm-gates');output.mkdir(exist_ok=False)
record=dict(source=sha,cases=[])
cases=[('reference',62,'graph','process-cluster',False),('delta_star',62,'graph','process-cluster',False),('reference',14,'extremes','process-cluster',False),('delta_star',14,'extremes','process-cluster',False),('delta_star',14,'skew','process-cluster',False),('reference',14,'isolates','process-cluster',False),('reference',0,'graph','process-cluster',True),('delta_star',0,'graph','process-cluster',True),('delta_star',1,'graph','process-cluster',True),('reference',14,'graph','local',False)]
for method,rounds,case,mode,cap in cases:
 name=f'{method}-{rounds}-{case}-{mode}';cmd=['/tmp/sail-argentea-sssp-arm-venv/bin/python','examples/extensions/argentea/python/qualify_sssp.py','--mode',mode,'--method',method,'--max-rounds',str(rounds),'--case',case,'--sail-binary','/tmp/sail-argentea-artifacts/sail-arm64-d9c6381a0eff','--runtime-source-sha','d9c6381a0effe07ab89ddb87739a0b2003b9664b','--native-source-sha',sha,'--output',str(output/name)]
 if cap:cmd.append('--expect-cap')
 item=dict(name=name,command=cmd,started=datetime.datetime.now(datetime.timezone.utc).isoformat());record['cases'].append(item)
 with (output/(name+'.log')).open('w') as f:run=subprocess.run(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT)
 item.update(returncode=run.returncode,finished=datetime.datetime.now(datetime.timezone.utc).isoformat());p=output/name/'receipt.json'
 if p.exists():item['outcome']=json.loads(p.read_text())['outcome']
 (output/'summary.json').write_text(json.dumps(record,indent=2)+'\n');print(name,item.get('outcome','missing'),run.returncode,flush=True)
 if run.returncode:sys.exit(run.returncode)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==sha
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
record['outcome']='passed';(output/'summary.json').write_text(json.dumps(record,indent=2)+'\n')
