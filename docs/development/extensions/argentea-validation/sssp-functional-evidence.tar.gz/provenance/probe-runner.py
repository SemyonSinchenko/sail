import sys,pathlib,json,datetime,subprocess,hashlib,traceback
from types import SimpleNamespace
root=pathlib.Path('/tmp/sail-argentea-wcc-integration-work')
for p in ['examples/extensions/argentea/python','examples/extensions/benchmarks','examples/extensions/scripts']:
 sys.path.insert(0,str(root/p))
from argentea_sssp_client import ArgenteaSssp
from argentea_runtime import local_server
from argentea_readiness import wait_for_workers
from argentea_evidence import parse_log
from argentea_resource_evidence import live_pids
from qualify_resources import wait_empty
from runtime import group_exists,native_package_identity
from pyspark.sql.connect.session import SparkSession
from pyspark.sql.connect.client.retries import DefaultPolicy
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert sha.startswith('7c2770130') and not subprocess.check_output(['git','status','--porcelain'],cwd=root)
method=sys.argv[1];rounds=int(sys.argv[2]);base=pathlib.Path(f'/tmp/sail-argentea-sssp-7c277-live-{method}-{rounds}');base.mkdir(exist_ok=False)
ids=[-5,0,1,6,10,11,20,21];edges=[(-5,0,12.0),(-5,1,1.0),(-5,1,1.0),(1,0,1.0),(0,6,0.0),(1,6,1.0),(6,10,0.25),(10,10,0.0),(20,21,1.0),(0,1,0.0)]
expected={-5:(0.0,0,-5),0:(2.0,2,1),1:(1.0,1,-5),6:(2.0,2,1),10:(2.25,3,6),11:(None,None,None),20:(None,None,None),21:(None,None,None)}
for method,rounds in [(method,rounds)]:
 out=base/f'{method}-{rounds}';out.mkdir()
 r=dict(source=sha,host_source='d9c6381a0effe07ab89ddb87739a0b2003b9664b',started=datetime.datetime.now(datetime.timezone.utc).isoformat(),method=method,max_rounds=rounds,outcome='running',cleanup_errors=[],native_package=native_package_identity())
 args=SimpleNamespace(output=out,sail_binary=pathlib.Path('/tmp/sail-argentea-artifacts/sail-arm64-d9c6381a0eff'),mode='process-cluster',partitions=3,threads=2,worker_task_slots=512,sail_pool_bytes=2<<30,native_quota=256<<20)
 try:
  with local_server(args,r['cleanup_errors']) as (endpoint,pid):
   r['driver_pid']=pid
   spark=SparkSession.builder.remote(endpoint).create();spark.client.set_retry_policies([DefaultPolicy(max_retries=0)])
   try:
    wait_for_workers(spark,evidence=r)
    def observe(event):
     r['request']=event['request'];r['native_phase_count']=event['native_phase_count'];r['views']=[x['alias'] for x in event['view_registrations']]
     for i,x in enumerate(event['view_registrations']):(out/f'view-{i:03d}.pb').write_bytes(x['plan_bytes'])
    with ArgenteaSssp(spark,observer=observe).sssp(spark.createDataFrame([(v,) for v in ids],'id long'),spark.createDataFrame(edges,'src long,dst long,weight double'),source=-5,delta=4.0,method=method,max_rounds=rounds,partitions=3,batch_rows=2) as result:
     r['rows']=[x.asDict() for x in result.native_frame.collect()]
     assert len(r['rows'])==8 and {x['id']:(x['distance'],x['hops'],x['parent']) for x in r['rows']}==expected
     assert len({x['worker_id'] for x in r['rows']})==2
     assert all(x['pid']!=pid for x in r['rows'])
     assert all(not spark.catalog.tableExists(x) for x in r['views'])
     r['rounds']=result.rounds
   finally:spark.stop()
   r['staging']=wait_empty(out/'staging')
  records,_=parse_log((out/'server.log').read_text());r['native_receipts']=records
  r['process_cleanup']=live_pids([r['driver_pid'],*[x['pid'] for x in records]])
  assert not any(x['alive'] for x in r['process_cleanup']) and not group_exists(r['driver_pid'])
  assert not r['cleanup_errors']
  r['outcome']='answers-and-cleanup-passed-awaiting-independent-stage-audit'
 except BaseException as e:
  r['outcome']='failed';r['error']=repr(e);r['traceback']=traceback.format_exc()
 finally:
  r['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'receipt.json').write_text(json.dumps(r,indent=2,default=str)+'\n');print(method,rounds,r['outcome'],r.get('error',''),flush=True)
 if r['outcome']=='failed':sys.exit(1)
