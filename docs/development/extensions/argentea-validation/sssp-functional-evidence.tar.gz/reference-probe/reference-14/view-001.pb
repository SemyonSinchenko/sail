
�
(�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
-type.googleapis.com/nutmeg.v5.ArgenteaSsspApi�{"version":5,"algorithm":"sssp_reference","max_rounds":14,"source":-5,"delta":4.0,"partitions":3,"vertices":8,"max_phase_budget":128,"batch_rows":2,"generation":1,"operation_id":"3656aa6c-bf0f-4f5d-994a-e0cafdaef024","snapshot_id":"1bd5081a-3102-4dd3-90e8-15ce89fee102","verb":"decide","phase":0}E
C
'=
;
9argentea_phase_ed19bc7b70f6467e99f8d9160a60fd8a_00_init_0(