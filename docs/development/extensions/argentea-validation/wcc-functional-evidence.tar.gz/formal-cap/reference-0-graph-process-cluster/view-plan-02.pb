
�
+�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_reference","max_rounds":0,"seed":42,"partitions":5,"vertices":8,"max_phase_budget":128,"batch_rows":2,"generation":1,"operation_id":"b1e3ff37-4c9d-4b27-b60e-cec507e9e9a7","snapshot_id":"c5dbfe58-8785-4bcb-9ddb-50869befeaf1","verb":"apply","phase":0}G
E
*?
=
;argentea_phase_b10ae3bbec0b40f592ec857f76af9813_01_decide_0(