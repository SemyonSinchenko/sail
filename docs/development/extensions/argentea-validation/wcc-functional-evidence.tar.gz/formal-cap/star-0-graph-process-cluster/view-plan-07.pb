
�
:�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_star","max_rounds":0,"seed":42,"partitions":5,"vertices":8,"max_phase_budget":128,"batch_rows":2,"generation":1,"operation_id":"67f77287-83d0-433a-8c11-982a06698218","snapshot_id":"e88bcf11-8da5-44de-bc79-baf4a083b621","verb":"decide","phase":3}F
D
9>
<
:argentea_phase_b266dde8c6964c84b129475e3861d445_06_apply_2(