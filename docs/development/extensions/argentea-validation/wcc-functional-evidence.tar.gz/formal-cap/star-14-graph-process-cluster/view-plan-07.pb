
�
:�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_star","max_rounds":14,"seed":42,"partitions":5,"vertices":8,"max_phase_budget":128,"batch_rows":2,"generation":1,"operation_id":"836872c0-1dd9-4725-9d9f-bc4ff34a1b48","snapshot_id":"249651aa-cbc7-4f15-a0f1-f5dd21178344","verb":"decide","phase":3}F
D
9>
<
:argentea_phase_26eac3b592824e9c8422588b89d014ba_06_apply_2(