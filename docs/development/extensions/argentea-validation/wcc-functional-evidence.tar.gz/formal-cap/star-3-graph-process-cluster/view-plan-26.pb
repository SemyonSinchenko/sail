
�
s�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_star","max_rounds":3,"seed":42,"partitions":5,"vertices":8,"max_phase_budget":128,"batch_rows":2,"generation":1,"operation_id":"b85c9c80-68c0-48f9-aed0-fa926a065322","snapshot_id":"d0a5eff4-049e-4816-bd98-f25124b07234","verb":"apply","phase":12}H
F
r@
>
<argentea_phase_a4f7f5ca4f434fba9412df5bcaab8ab9_25_decide_12(