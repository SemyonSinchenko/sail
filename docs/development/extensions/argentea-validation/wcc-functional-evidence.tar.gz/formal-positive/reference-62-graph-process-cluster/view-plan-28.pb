
�
y�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_reference","max_rounds":62,"seed":42,"partitions":5,"vertices":8,"max_phase_budget":128,"batch_rows":2,"generation":1,"operation_id":"5e5b192e-ca66-46e9-b6b7-8118ba935439","snapshot_id":"c4a149ba-c9af-43fa-a21d-e60d07bd8283","verb":"apply","phase":13}H
F
x@
>
<argentea_phase_3b45e370775c449cab50944670faaede_27_decide_13(