
�
;�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_star","max_rounds":0,"seed":42,"partitions":5,"vertices":4,"max_phase_budget":128,"batch_rows":2,"generation":1,"operation_id":"2937e74e-c4a0-4c13-85de-49fd3dadb46a","snapshot_id":"998f32aa-8687-4dd6-9357-78e088ba8891","verb":"decide","phase":3}F
D
:>
<
:argentea_phase_06c0d4428f4448b7a2dc405949cdd7ea_06_apply_2(