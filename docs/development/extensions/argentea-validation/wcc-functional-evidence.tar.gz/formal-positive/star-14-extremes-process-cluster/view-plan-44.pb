
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_star","max_rounds":14,"seed":42,"partitions":5,"vertices":3,"max_phase_budget":128,"batch_rows":2,"generation":1,"operation_id":"bfad8979-6a7f-4b66-ab5e-34c0580bce4e","snapshot_id":"8378b3a6-f360-4cbc-a52b-e9ad3589c8d6","verb":"apply","phase":21}I
G
�@
>
<argentea_phase_48f6652ab4f34787a46a473f935e6a72_43_decide_21(