
�
��>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_star","max_rounds":19,"seed":42,"partitions":5,"vertices":8,"max_phase_budget":128,"batch_rows":2,"generation":1,"operation_id":"27545480-819d-460a-b587-789f01107502","snapshot_id":"c8cba87e-5072-4115-bcff-4ca6dbdad01d","verb":"decide","phase":30}H
F
�?
=
;argentea_phase_a9736472fd104d3584a9b93f34bc77c2_60_apply_29(