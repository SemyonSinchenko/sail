
�
+�>�
:type.googleapis.com/sail.extension.v1.SailExtensionRequest�
,type.googleapis.com/nutmeg.v4.ArgenteaWccApi�{"version":4,"algorithm":"wcc_star","max_rounds":19,"seed":42,"partitions":3,"vertices":8,"max_phase_budget":128,"batch_rows":2,"generation":1,"operation_id":"d6576e95-16a3-426c-8245-6afd34558a1b","snapshot_id":"287e4cc5-847a-4391-80fd-4b7600617fea","verb":"apply","phase":0}G
E
*?
=
;argentea_phase_2e5bb16e81e74afd9e753440e549335d_01_decide_0(