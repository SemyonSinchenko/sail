# Review evidence bundle

This is a redacted derivative of recorded evidence, including failed candidates.
It is not an independent rerun or a claim that an old gate covers a newer commit.
Read each receipt's source revision and scope before using its verdict.

Verify after extraction with `shasum -a 256 -c SHA256SUMS`.
`manifest.json` maps original and exported hashes and discloses exclusions.
Historical absolute paths are retained in redacted form for provenance; navigate
using the manifest paths. Binaries and wheels are omitted; their recorded hashes
remain available. Credential-pattern detection is supplementary to manual review.
