use std::mem::{align_of, offset_of, size_of};
use datafusion_ffi::{
    execution::FFI_TaskContext,
    execution::task_ctx_provider::FFI_TaskContextProvider,
    execution_plan::FFI_ExecutionPlan,
    record_batch_stream::FFI_RecordBatchStream,
    table_provider::FFI_TableProvider,
    udf::FFI_ScalarUDF,
};
macro_rules! layout {
    ($t:ty, $($field:ident),*) => {
        print!("\"{}\":{{\"size\":{},\"alignment\":{},\"offsets\":{{", stringify!($t), size_of::<$t>(), align_of::<$t>());
        let fields = [$(format!("\"{}\":{}", stringify!($field), offset_of!($t, $field))),*];
        print!("{}}}}}", fields.join(","));
    }
}
fn main() {
    print!("{{\"datafusion_ffi_major\":{},\"layouts\":{{", datafusion_ffi::version());
    layout!(FFI_ScalarUDF, name, aliases, return_field_from_args, invoke_with_args, release, private_data, library_marker_id, with_updated_config);
    print!(",");
    layout!(FFI_TableProvider, statistics, logical_codec, version, library_marker_id);
    print!(",");
    layout!(FFI_ExecutionPlan, properties, execute, release, version, private_data, library_marker_id);
    print!(",");
    layout!(FFI_RecordBatchStream, poll_next, schema, release, private_data);
    print!(",");
    layout!(FFI_TaskContextProvider, task_ctx, clone, release, private_data, library_marker_id);
    print!(",\"FFI_TaskContext\":{{\"size\":{},\"alignment\":{}}}", size_of::<FFI_TaskContext>(), align_of::<FFI_TaskContext>());
    println!("}}}}");
}
