import hashlib,json,re,subprocess
from pathlib import Path
from datetime import datetime,timezone
repo=Path('/Users/REDACTED/src/sail-extensions-poc');root=repo/'target/extensions-abi-review'
def read(p):return json.loads(p.read_text())
rows=[];total=0;skips=0
for platform,relative in [('macOS-arm64','mac-compiler-compatibility'),('Linux-x86_64','linux/compatibility')]:
 directory=root/relative;r=read(directory/'receipt.json')
 assert r['status']=='passed' and r['wheels_unchanged']
 for host in r['hosts']:
  runs=[]
  for run in host['runs']:
   log=(directory/run['log']).read_text();passed=int(re.findall(r'(\d+) passed',log)[-1]);skip=re.findall(r'(\d+) skipped',log);skip=int(skip[-1]) if skip else 0
   assert run['exit_code']==0 and (passed,skip)==((64,1) if run['mode']=='local' else (65,0))
   total+=passed;skips+=skip;runs.append(dict(mode=run['mode'],passed=passed,skipped=skip,exit_code=0))
  rows.append(dict(platform=platform,case=host['case'],source_commit=host['source_commit'],rustc=host['rustc'],datafusion=host.get('datafusion','55.1.0'),datafusion_ffi=host.get('datafusion_ffi','55.1.0'),arrow=host.get('arrow','59.3.0'),binary_sha256=host['binary_sha256'],wheel_sha256={name:record['wheel_sha256'] for name,record in r['wheels'].items()},runs=runs,receipt='abi/'+relative+'/receipt.json',classification='diagnostic only' if host['case']=='ffi-diagnostic' else 'qualified artifact combination'))
mixed=read(root/'mac-mixed-compilers/receipt.json');assert mixed['status']=='passed' and mixed['wheels_unchanged']
mixed_rows=[]
for run in mixed['runs']:
 log=(root/'mac-mixed-compilers'/run['log']).read_text();passed=int(re.findall(r'(\d+) passed',log)[-1]);assert passed==65 and run['exit_code']==0;total+=passed
 mixed_rows.append(dict(platform='macOS-arm64',driver={k:run['driver'][k] for k in ['source_commit','rustc','binary_sha256']},worker={k:run['worker'][k] for k in ['source_commit','rustc','binary_sha256']},mode='process-cluster',passed=65,receipt='abi/mac-mixed-compilers/receipt.json'))
boundaries=[]
for platform,path in [('macOS-arm64','mac-boundaries-release'),('Linux-x86_64','linux/boundaries-release')]:
 r=read(root/path/'receipt.json');assert r['status']=='passed' and r['wheels_unchanged'] and r['binary_unchanged']
 assert len(r['probes'])==17 and all(p['exit_code']==0 and not p['timed_out'] for p in r['probes'])
 assert r['harness_sha256']==hashlib.sha256((repo/'examples/extensions/scripts/check_abi_boundaries.py').read_bytes()).hexdigest()
 boundaries.append(dict(platform=platform,passed=17,receipt='abi/'+path+'/receipt.json'))
assert len(rows)==6 and len(mixed_rows)==2 and total==1294 and skips==6
result=dict(recorded_utc=datetime.now(timezone.utc).isoformat(),scope='Exact unchanged-wheel artifact combinations; FFI downgrade diagnostic is not production support',extension_compiler='1.97.1',rows=rows,mixed_compiler_workers=mixed_rows,boundary_probes=boundaries,integration_passed=total,integration_skipped=skips,whole_engine_downgrade=dict(source_commit='fa34dd697ff9926e7bcdd1da1a28f7c705a00922',datafusion='55.0.0',outcome='build_incompatible',exit_code=101,reason='CastExpr::has_explicit_metadata missing',log='abi/mac-df55-build.log'),newer_datafusion_patch=dict(outcome='unavailable',evidence='abi/available-versions.json'))
(repo/'docs/development/extensions/abi-compatibility-matrix.json').write_text(json.dumps(result,indent=2)+'\n')
lines=['| Platform / host case | Local | Actor cluster | Process cluster |','| --- | --- | --- | --- |']
for row in rows:lines.append(f"| {row['platform']} / {row['case']} | 64 passed, 1 skip | 65 passed | 65 passed |")
lines += ['', 'These six rows contribute 1,164 integration passes and six expected skips.', 'The two mixed-compiler process runs below add 130 passes, for **1,294 integration', 'passes and six expected skips** in this round. The diagnostic FFI row is reported', 'separately from production qualification even though its assertions pass.']
p=repo/'docs/development/extensions/abi-review.md';s=p.read_text().replace('PENDING_MATRIX','\n'.join(lines));p.write_text(s)
print('PASS matrix: 1,294 integration passes, 6 expected skips, 34 boundary probes')
