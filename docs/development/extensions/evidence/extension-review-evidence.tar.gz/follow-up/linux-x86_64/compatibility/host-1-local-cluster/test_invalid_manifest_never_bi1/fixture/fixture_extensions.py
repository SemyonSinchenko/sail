
import json
from pathlib import Path

SPECIFICATIONS = json.loads('[{"manifest": {"name": "loader-fixture", "version": "1", "api_version": 2, "datafusion_version": "55.1.0", "arrow_version": "59.3.0", "placement": "driver", "relation_types": []}}]')
EVENTS = Path('/targets/linux-gates/review-evidence/compatibility/host-1-local-cluster/test_invalid_manifest_never_bi1/fixture/events.jsonl')

def record(event, index):
    with EVENTS.open("a") as output:
        output.write(json.dumps(dict(event=event, index=index)) + "\n")

class NeverReadCapsule:
    def __init__(self, index):
        self.index = index
    def __datafusion_scalar_udf__(self):
        record("capsule", self.index)
        raise RuntimeError("native capsule must not be inspected")

class BoundFixture:
    def __init__(self, specification, index, session):
        self.specification, self.index = specification, index
        self.native_owner = None
        self.functions = []
        if specification.get("scalars") == "sedona_point":
            from sail_sedona import extension
            self.native_owner = extension.bind(session)
            self.functions = [f for f in self.native_owner.scalar_udfs() if f.name() == "st_point"]
            assert len(self.functions) == 1
        elif specification.get("scalars") == "forbidden_capsule":
            self.functions = [NeverReadCapsule(index)]
    def scalar_udfs(self):
        return self.functions
    def plan_relation(self, *args):
        record("plan_relation", self.index)
        raise RuntimeError("relation planning must not happen after a rejected load")

class Extension:
    def __init__(self, specification, index):
        self.specification, self.index = specification, index
    def manifest(self):
        return self.specification["manifest"]
    def bind(self, session):
        record("bind", self.index)
        return BoundFixture(self.specification, self.index, session)

extension_0 = Extension(SPECIFICATIONS[0], 0)
