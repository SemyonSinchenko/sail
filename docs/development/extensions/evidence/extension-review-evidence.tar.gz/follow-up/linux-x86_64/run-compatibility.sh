#!/bin/bash
set -euo pipefail
root=/targets/linux-gates
old=de8e670989edb8ed5343764c52d0d002b6b6cd63
new=bf97367dd231de2535ad9b04b415fd2619bc4696
python="$root/venv-$old/bin/python"
# The caller starts this only after the immutable candidate gate succeeds.
"$python" - <<'PY'
from pathlib import Path
import hashlib,json
root=Path('/targets/linux-gates')
old='de8e670989edb8ed5343764c52d0d002b6b6cd63';new='bf97367dd231de2535ad9b04b415fd2619bc4696'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
rows=[]
for commit,p in [(old,root/f'target-{old}/host/debug/sail'),(new,root/'review-target/host/debug/sail')]:
 rows.append(dict(source_commit=commit,binary=str(p),binary_sha256=sha(p)))
(root/'review-evidence/hosts.json').write_text(json.dumps(rows,indent=2)+'\n')
PY
"$python" /targets/review-harness/examples/extensions/scripts/check_compatibility.py \
 --hosts "$root/review-evidence/hosts.json" \
 --wheel "$root/target-$old/wheels/sail_nutmeg-0.1.0-cp312-cp312-manylinux_2_34_x86_64.whl" \
 --wheel "$root/target-$old/wheels/sail_sedona_extension-0.1.0-cp312-cp312-manylinux_2_34_x86_64.whl" \
 --output "$root/review-evidence/compatibility"
