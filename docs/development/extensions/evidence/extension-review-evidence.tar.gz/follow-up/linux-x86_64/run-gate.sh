#!/bin/bash
set -euo pipefail
export PATH=/root/.cargo/bin:/usr/local/cargo/bin:$PATH
candidate=bf97367dd231de2535ad9b04b415fd2619bc4696
root=/targets/linux-gates
mkdir -p "$root/review-evidence"
git --git-dir="$root/repository.git" fetch /work/review-candidate.bundle refs/review-candidates/resource-domain
git --git-dir="$root/repository.git" worktree add --detach "$root/$candidate" "$candidate"
mkdir -p "$root/review-target"
cp -a --reflink=auto "$root/target-de8e670989edb8ed5343764c52d0d002b6b6cd63/host" "$root/review-target/host"
cd "$root/$candidate"
export CARGO_TARGET_DIR="$root/review-target/host" CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_BUILD_JOBS=16
export PYO3_PYTHON="$root/venv-de8e670989edb8ed5343764c52d0d002b6b6cd63/bin/python"
export PYTHONHOME=$($PYO3_PYTHON -c 'import sys; print(sys.base_prefix)')
export PYTHONPATH=$($PYO3_PYTHON -c 'import sysconfig; print(sysconfig.get_paths()["purelib"])')
export LD_LIBRARY_PATH=$($PYO3_PYTHON -c 'import sysconfig; print(sysconfig.get_config_var("LIBDIR"))')
{ date -u; uname -a; free -b; nproc; df -h .; cat /sys/fs/cgroup/memory.max /sys/fs/cgroup/memory.swap.max /sys/fs/cgroup/cpu.max; } > "$root/review-evidence/envelope.txt"
cargo +nightly-2026-05-28 fmt --all -- --check
cargo test --locked -p sail-session --lib
cargo clippy --locked -p sail-session --all-targets -- -D warnings
cargo build --locked -p sail-cli
[[ $(git rev-parse HEAD) == "$candidate" ]]
[[ -z $(git status --porcelain) ]]
printf 'review-resource-domain: PASSED Linux session tests, clippy and host build at %s\n' "$candidate"
