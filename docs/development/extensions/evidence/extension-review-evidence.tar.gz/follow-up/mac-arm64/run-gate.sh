#!/bin/bash
set -euo pipefail
cd /Users/REDACTED/src/sail-extensions-review-gate
export CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_BUILD_JOBS=4
export CARGO_TARGET_DIR="$PWD/target/review/host"
export PYO3_PYTHON=/Users/REDACTED/src/sail-extensions-datafusion-gate/.venv/bin/python
export DYLD_LIBRARY_PATH=$($PYO3_PYTHON -c 'import sysconfig; print(sysconfig.get_config_var("LIBDIR"))')
export PYTHONHOME=$($PYO3_PYTHON -c 'import sys; print(sys.base_prefix)')
export PYTHONPATH=$($PYO3_PYTHON -c 'import sysconfig; print(sysconfig.get_paths()["purelib"])')
sha=$(git rev-parse HEAD)
df -h .
cargo +nightly-2026-05-28 fmt --all -- --check
cargo test --locked -p sail-session --lib
cargo clippy --locked -p sail-session --all-targets -- -D warnings
cargo build --locked -p sail-cli
[[ $(git rev-parse HEAD) == "$sha" ]]
[[ -z $(git status --porcelain) ]]
printf 'review-resource-domain: PASSED session tests, clippy and host build at %s\n' "$sha"
