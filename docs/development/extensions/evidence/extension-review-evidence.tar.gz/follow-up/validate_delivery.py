"""Validate the exact resource-domain candidate and both compatibility matrices."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parent
CANDIDATE = 'bf97367dd231de2535ad9b04b415fd2619bc4696'
BASELINE = 'de8e670989edb8ed5343764c52d0d002b6b6cd63'


def validate():
    results=[]
    sources=[]
    for platform in ['mac-arm64', 'linux-x86_64']:
        folder=ROOT/platform
        gate=json.loads((folder/'gate-receipt.json').read_text())
        assert gate['source_commit']==CANDIDATE and not gate['source_dirty']
        assert gate['session_tests_passed']==35
        log=(folder/'gate.log').read_bytes()
        assert hashlib.sha256(log).hexdigest()==gate['log_sha256']
        assert f'host build at {CANDIDATE}'.encode() in log
        matrix=json.loads((folder/'compatibility/receipt.json').read_text())
        assert matrix['status']=='passed' and matrix['wheels_unchanged']
        assert {h['source_commit'] for h in matrix['hosts']}=={BASELINE,CANDIDATE}
        assert len({h['binary_sha256'] for h in matrix['hosts']})==2
        sources.append((matrix['harness_sha256'],matrix['test_sources']))
        for host in matrix['hosts']:
            assert {r['mode'] for r in host['runs']}=={'local','local-cluster','process-cluster'}
            for run in host['runs']:
                assert run['exit_code']==0
                text=(folder/'compatibility'/run['log']).read_text()
                expected='64 passed, 1 skipped' if run['mode']=='local' else '65 passed'
                assert expected in text,(platform,host['source_commit'],run['mode'])
                results.append(dict(platform=platform,source_commit=host['source_commit'],
                                    mode=run['mode'],result=expected))
    assert sources[0][0]==sources[1][0], 'Platforms must run identical harness'
    mac, linux = sources[0][1], sources[1][1]
    assert all(linux.get(k)==v for k,v in mac.items()), 'Every executed Python fixture must match'
    extras=set(linux)-set(mac)
    # macOS tar added binary AppleDouble xattr sidecars. Pytest ignores these
    # dotfiles; do not mislabel them as executed Python source. Their magic and
    # hashes are independently retained in the transfer metadata receipt.
    sidecars=json.loads((ROOT/'linux-x86_64/appledouble.json').read_text())
    assert extras==set(sidecars)
    for name in extras:
        assert Path(name).name.startswith('._')
        counterpart=str(Path(name).with_name(Path(name).name[2:]))
        assert counterpart in mac
        assert sidecars[name]['magic_hex']=='00051607'
        assert sidecars[name]['sha256']==linux[name]
    return results


if __name__=='__main__':
    rows=validate()
    print(f'PASS: {CANDIDATE}; two platform gates, {len(rows)} compatibility cells; 776 passes and 4 expected skips')
