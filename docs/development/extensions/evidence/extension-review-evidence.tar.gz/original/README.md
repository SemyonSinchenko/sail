# Sail extension proof of concept evidence

Published [branch](https://github.com/querygraph/sail/tree/work/extensions-datafusion-graphs) at exact qualified commit [`de8e670989edb8ed5343764c52d0d002b6b6cd63`](https://github.com/querygraph/sail/commit/de8e670989edb8ed5343764c52d0d002b6b6cd63).

**All three qualifications passed. The branch was pushed, its remote SHA was verified, and the source checkout is clean.** See the [publication record](publication.json) and [source/evidence validation](publication-check.json).

Published documents: [DataFusion graph implementation plan](https://github.com/querygraph/sail/blob/de8e670989edb8ed5343764c52d0d002b6b6cd63/docs/development/extensions/datafusion-graph-plan.md), [extension implementation plan](https://github.com/querygraph/sail/blob/de8e670989edb8ed5343764c52d0d002b6b6cd63/docs/development/extensions/implementation-plan.md), [review](https://github.com/querygraph/sail/blob/de8e670989edb8ed5343764c52d0d002b6b6cd63/docs/development/extensions/implementation-review.md), and [review resolution](https://github.com/querygraph/sail/blob/de8e670989edb8ed5343764c52d0d002b6b6cd63/docs/development/extensions/implementation-review-resolution.md).

The machine-readable [evidence index](evidence-index.json) records exact paths, hashes, outcomes and scope. All timestamps are generated when their records are written.

## Qualification status

| Gate | Status | Evidence |
| --- | --- | --- |
| macOS arm64 complete gate | Passed | [Receipt](mac-arm64-de8e67098/receipt.json), [verdict log](mac-arm64-de8e67098/verify.log), [exit/source checks](mac-arm64-de8e67098/run-status.json), [artifact hashes](mac-arm64-de8e67098/export.json). |
| Linux x86_64 complete gate | Passed | [Receipt](linux-x86_64-de8e67098/receipt.json), [verdict log](linux-x86_64-de8e67098/gate.log), [artifact/source verification](linux-x86_64-de8e67098/export-verification.json). |
| macOS x86_64 build and real two-host execution | Passed | [Receipt](two-host-de8e67098/receipt.json), [build provenance](mac-x86-de8e67098/provenance.json), [full driver/worker log](two-host-de8e67098/server-and-workers.log). |

Each complete platform gate passed 651 Rust tests: 586 host library tests, 4 Sedona tests, 5 Nutmeg tests, 55 vendor unit tests and 1 isolated allocation-admission integration test, plus full host clippy. Each release stress fixture passed once idle and ten times with all logical CPUs busy: ten logical CPUs on macOS arm64 and 36 in the Linux guest. Each platform also passed 3 Python client tests and 5 launcher/parser tests, then 64 integration cases with one expected skip in local mode, 65 in actor mode and 65 with separate process workers. All 121 recorded arm64 Sail PIDs were absent after cleanup; the Linux task container had no remaining Sail, Cargo, rustc, stress-load or Python processes.

## Real two-host result

review-host-a hosted the driver and one worker at `192.0.2.1`; review-host-b hosted a worker at `192.0.2.2`. All three inventories report the exact candidate and `source_dirty=false`. Executable and installed native package identities match on every process host. The [provenance record](mac-x86-de8e67098/provenance.json) verifies local/remote binary and wheel hashes, immutable harness hashes and post-run source status.

The run checked 17 Sedona geometries after a worker shuffle, ordinary graph degree and two-hop relational queries, spatially filtered input to native staging, a five-node/four-edge native graph, native degree results through a shuffle, graph table scans, and graph deletion. Worker 1 on review-host-b completed 81 tasks; worker 2 on review-host-a completed 70. Thirty stages have successful tasks on both workers. These are direct task-status observations. The task-table snapshot retains all 158 rows, including six nonterminal rows in its final job 16; the successful-worker claims use the completed-task log records.

Cleanup verified that driver PID 3220, review-host-a worker PID 3561 and review-host-b worker PID 87254 were absent. Five launcher/parser unit tests passed. The [host boundary](mac-x86-de8e67098/host-boundary.json) records native arm64 review-host-a using Rosetta (`sysctl.proc_translated=1`) and native x86_64 review-host-b. This is functional qualification, with no performance claim.

## Artifacts and replay

- [Exact macOS x86_64 Sail binary](mac-x86-de8e67098/sail), [repaired wheels](mac-x86-de8e67098/wheels/), [GEOS wheel dependency audit](mac-x86-de8e67098/sedona-native-dependencies.json), and [portable Python linkage](mac-x86-de8e67098/portable-linkage.log).
- [Two-host configuration](two-host-de8e67098.json) and [snapshotted harness](two-host-de8e67098/harness/). Replay with the command in [evidence-index.json](evidence-index.json), choosing a new output directory; the harness refuses an existing evidence directory.
- The frozen checkout `/Users/REDACTED/src/sail-extensions-datafusion-gate` contains `examples/extensions/scripts/build.sh` and `verify.sh`. Each complete gate has its own detached source and private target directory.
- [Linux environment contract](/Users/REDACTED/src/sail-extensions-datafusion-gate/docs/development/extensions/linux-environment.md), [Docker/Colima setup](linux-x86_64-de8e67098/setup.log), [QEMU setup and profile records](linux-x86_64-de8e67098/environment/), [pre-gate resource envelope](linux-x86_64-de8e67098/envelope-before.log), and [post-gate envelope](linux-x86_64-de8e67098/envelope-after.log).
- [Environment cleanup](environment-cleanup.json): the task container and isolated `sail-gate` QEMU profile are stopped. The default Colima profile remained running with 12 CPUs and 48 GiB configured; it was left untouched. No pruning or deletion was performed.

## Retained failures and review

Candidate `d7143e0993e358542be3ce73082bd08ddf915159` was rejected after a scalar-list geometry descriptor failure and a geometry `coalesce(Binary, NULL)` failure. Its [ARM logs and exact live probe](failed-candidates/d7143e099/mac-arm64/), [Linux failure and setup records](failed-candidates/d7143e099/linux-x86_64/), and [macOS x86 artifacts and boundary](mac-x86-d7143e0/CANDIDATE-BOUNDARY.txt) remain available. The replacement repairs the subject, keeps the failing assertions, and adds scalar/array empty-input and literal/nonconstant NULL coverage. Development correction checks passed 322 function tests, 12 plan tests, both affected crates' clippy, and 19 geometry cases each in local and process modes. Their logs remain in `/Users/REDACTED/src/sail-extensions-poc/target/extensions-datafusion-development/`.

The original detailed review and WKB/native dependency replays remain in `/Users/REDACTED/src/sail-extensions-poc/target/extensions-distributed-poc/review/`. Failed-candidate evidence is not counted as a passing qualification.

## Scope

GraphTables compose as ordinary Sail/DataFusion relations, with distributed scans, filters, joins and aggregates. Native Nutmeg staging and CSR algorithm kernels remain driver operations. This delivery does not claim distributed native CSR kernels.

Participating host/native reservations and declared work are governed by finite admission. This is not an RSS ceiling or complete accounting of every Python, Arrow or allocator allocation. Workers retain exact installed native package identity checks; the two-host result uses identical x86_64 artifacts and does not establish arbitrary mixed-architecture extension compatibility.
