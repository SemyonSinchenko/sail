#!/usr/bin/env bash
set -euo pipefail
export PATH="$HOME/.cargo/bin:/usr/local/bin:$PATH"
context=colima-sail-gate
sha=d7143e0993e358542be3ce73082bd08ddf915159
container=sail-extension-candidate-d7143e0
base=/Users/REDACTED/src/sail-extensions-gates/final-linux-d7143e0
source=/targets/linux-gates/$sha
target=/targets/linux-gates/target-$sha
venv=/targets/linux-gates/venv-$sha
image_id=$(docker --context "$context" image inspect sail-extensions-gate:d7143e0 --format '{{.Id}}')
printf '%s\n' "$image_id" > "$base/image-id.txt"
date -u +%Y-%m-%dT%H:%M:%SZ > "$base/start-time.txt"
docker --context "$context" stop sail-extension-development > "$base/development-stop.log"
docker --context "$context" run --detach --init --name "$container" --cpus 36 --memory 72g --memory-swap 72g \
  --label sail.extensions.purpose=immutable-gate --label sail.extensions.candidate="$sha" \
  --mount type=volume,source=sail-extension-targets,target=/targets \
  --mount type=volume,source=sail-extension-cargo-registry,target=/usr/local/cargo/registry \
  --workdir "$source" \
  --env CARGO_INCREMENTAL=0 --env CARGO_PROFILE_DEV_DEBUG=0 --env CARGO_BUILD_JOBS=18 \
  --env RUSTUP_TOOLCHAIN=1.97.1 --env SAIL_EXTENSION_FMT_TOOLCHAIN=nightly-2026-05-28 \
  --env SAIL_EXTENSION_TARGET="$target" --env SAIL_EXTENSION_VENV="$venv" \
  --env PYO3_PYTHON="$venv/bin/python" --env SAIL_GATE_IMAGE_ID="$image_id" \
  --env SAIL_GATE_VM_PROFILE=review-host-b/colima/sail-gate/qemu \
  "$image_id" sleep infinity > "$base/container-id.txt"
docker --context "$context" inspect "$container" > "$base/container-inspect.json"
docker --context "$context" exec "$container" bash -ceu '
date -u +%Y-%m-%dT%H:%M:%SZ
git rev-parse HEAD
git status --porcelain
if git symbolic-ref -q HEAD; then exit 1; fi
grep -E "MemTotal|SwapTotal" /proc/meminfo
nproc
for field in memory.max memory.swap.max cpu.max; do printf "%s=" "$field"; cat "/sys/fs/cgroup/$field"; done
df -h /targets
rustc --version
rustup run nightly-2026-05-28 rustfmt --version
test -e /usr/include/google/protobuf/any.proto
' > "$base/envelope-before.log"
docker --context "$context" exec "$container" bash -ceu '
test "$(git rev-parse HEAD)" = d7143e0993e358542be3ce73082bd08ddf915159
bash examples/extensions/scripts/build.sh &&
bash examples/extensions/scripts/verify.sh
' > "$base/gate.log" 2>&1
date -u +%Y-%m-%dT%H:%M:%SZ > "$base/finish-time.txt"
docker --context "$context" cp "$container:$target/receipt.json" "$base/receipt.json"
for file in cancellation-stress.json snapshot-stress.json sedona-native-dependencies.json; do
  docker --context "$context" cp "$container:$target/$file" "$base/$file"
done
docker --context "$context" exec "$container" bash -ceu '
git rev-parse HEAD
git status --porcelain
for field in memory.current memory.peak memory.events; do printf "%s=" "$field"; cat "/sys/fs/cgroup/$field"; done
df -h /targets
' > "$base/envelope-after.log"
