import datetime
import hashlib
import json
from pathlib import Path
import sys

repository = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(repository / "examples/extensions/tests"))
from conftest import start_server
from pyspark.sql.connect.session import SparkSession
from pyspark.sql.connect.client.retries import DefaultPolicy

evidence = Path(__file__).resolve().parent
binary = evidence / "sail"
queries = {
    "dynamic_geometry_null": "SELECT ST_AsText(coalesce(ST_Point(CAST(id AS DOUBLE), 2.0), NULL)) AS wkt FROM range(3)",
    "literal_geometry_null": "SELECT ST_AsText(coalesce(ST_Point(1.0, 2.0), NULL)) AS wkt",
    "plain_binary_null_control": "SELECT hex(coalesce(unhex('0102'), NULL)) AS value",
    "two_geometry_arms_control": "SELECT ST_AsText(coalesce(ST_Point(CAST(id AS DOUBLE), 2.0), ST_Point(9.0, 2.0))) AS wkt FROM range(3)",
}
with binary.open("rb") as stream:
    binary_hash = hashlib.file_digest(stream, "sha256").hexdigest()
results = {
    "commit": "d7143e0993e358542be3ce73082bd08ddf915159",
    "binary": str(binary), "binary_sha256": binary_hash, "mode": "local", "queries": {},
}
with start_server(str(binary), evidence / "geometry-null-server", mode="local") as endpoint:
    spark = SparkSession.builder.remote(endpoint).create()
    spark.client.set_retry_policies([DefaultPolicy(max_retries=1, initial_backoff=100, max_backoff=100, jitter=0)])
    try:
        for name, sql in queries.items():
            try:
                rows = [row.asDict(recursive=True) for row in spark.sql(sql).collect()]
                outcome = {"sql": sql, "status": "success", "rows": rows}
            except Exception as error:
                outcome = {"sql": sql, "status": "error", "type": type(error).__name__, "message": str(error)}
            results["queries"][name] = outcome
            print(json.dumps({name: outcome}), flush=True)
    finally:
        spark.stop()
results["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
(evidence / "geometry-null-probe.json").write_text(json.dumps(results, indent=2) + "\n")
