#!/usr/bin/env bash
set -euo pipefail
export PATH="$HOME/.cargo/bin:/usr/local/bin:$PATH"
context=colima-sail-gate
container=sail-extension-candidate-de8e67098
sha=de8e670989edb8ed5343764c52d0d002b6b6cd63
target=/targets/linux-gates/target-$sha
base=/Users/REDACTED/src/sail-extensions-gates/final-linux-de8e67098
test -f "$base/receipt.json"
docker --context "$context" exec -i "$container" python3 - > "$base/source-identity.json" <<'PY'
from datetime import datetime, timezone
import hashlib, json, os, pathlib, subprocess
root=pathlib.Path.cwd()
def git(*args):
    return subprocess.check_output(["git", *args], text=True).strip()
files=git("ls-files", "examples/extensions/scripts", "examples/extensions/tests",
          "examples/extensions/nutmeg/tests", "examples/extensions/nutmeg/scripts",
          "examples/extensions/vendor/nutmeg-graph/tests").splitlines()
result={
    "observed_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    "sail_commit": git("rev-parse", "HEAD"),
    "source_tree": git("rev-parse", "HEAD^{tree}"),
    "tracked_status": git("status", "--porcelain"),
    "detached_head": subprocess.run(["git","symbolic-ref","-q","HEAD"], stdout=subprocess.DEVNULL).returncode != 0,
    "harness_files_sha256": {name: hashlib.sha256((root/name).read_bytes()).hexdigest() for name in files},
}
print(json.dumps(result, indent=2))
PY
mkdir -p "$base/pytest" "$base/environment"
docker --context "$context" exec "$container" bash -ceu '
cd "$SAIL_EXTENSION_TARGET"
find pytest-local pytest-local-cluster pytest-process-cluster -type f \( -name "*.log" -o -name "*audit*.jsonl" -o -name "*.json" \) -print0 | tar --null -T - -cf -
' | tar -xf - -C "$base/pytest"
for file in guest-resources.txt container-resources.txt export-state.txt import-state.txt default-colima-before.yaml; do
    cp "/Users/REDACTED/src/sail-extensions-gates/qemu-migration/$file" "$base/environment/$file"
done
cp /Users/REDACTED/src/sail-extensions-gates/final-linux-d7143e0/Dockerfile "$base/environment/Dockerfile"
cp /Users/REDACTED/src/sail-extensions-gates/final-linux-d7143e0/image-build.log "$base/environment/image-build.log"
date -u +%Y-%m-%dT%H:%M:%SZ > "$base/export-time.txt"
mkdir -p "$base/artifacts/wheels"
docker --context "$context" cp "$container:$target/wheels/." "$base/artifacts/wheels/"
docker --context "$context" cp "$container:$target/host/debug/sail" "$base/artifacts/sail"
for file in cancellation-stress.build.log snapshot-stress.build.log; do
    docker --context "$context" cp "$container:$target/$file" "$base/$file"
done
date -u +%Y-%m-%dT%H:%M:%SZ > "$base/environment/profiles-observed-at-utc.txt"
colima list --json > "$base/environment/colima-profiles-at-export.json"
