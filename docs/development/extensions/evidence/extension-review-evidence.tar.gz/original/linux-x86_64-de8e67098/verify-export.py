from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess

BASE = Path(__file__).resolve().parent
REPO = Path("/Users/REDACTED/src/sail-extensions-poc")
SHA = "de8e670989edb8ed5343764c52d0d002b6b6cd63"
TREE = "64c851dbf585f430002589c78ac4693aa9b26d3c"
IMAGE = "sha256:9b75d8d8a14b8b93d251e52b1c8a5936c5720e495bf563b86ba93e00f34acf76"

def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()

def git_file_digest(name):
    content = subprocess.check_output(["git", "show", f"{SHA}:{name}"], cwd=REPO)
    return hashlib.sha256(content).hexdigest()

receipt = json.loads((BASE / "receipt.json").read_text())
source = json.loads((BASE / "source-identity.json").read_text())
assert receipt["sail_commit"] == source["sail_commit"] == SHA
assert source["source_tree"] == TREE
assert source["detached_head"] and not source["tracked_status"]
assert receipt["resource_envelope"]["container_image"] == IMAGE
assert receipt["resource_envelope"]["cgroup_v2"]["memory.max"] == "77309411328"
assert receipt["cargo_build_jobs"] == "18"
assert digest(BASE / "artifacts/sail") == receipt["host_binary_sha256"]
wheel_hashes = {p.name: digest(p) for p in (BASE / "artifacts/wheels").glob("*.whl")}
assert wheel_hashes == receipt["wheels"]
for name, expected in receipt["source_locks"].items():
    assert git_file_digest(name) == expected, name
for name, expected in source["harness_files_sha256"].items():
    assert git_file_digest(name) == expected, name
for name in ("cancellation-stress", "snapshot-stress"):
    report = json.loads((BASE / f"{name}.json").read_text())
    assert report["head_before"] == report["head_after"] == SHA
    assert report["unchanged"] and report["source_before"] == report["source_after"]
    assert report["build_exit_code"] == 0 and report["logical_cpus"] == 36
    assert len(report["runs"]) == 11
    assert all(run["exit_code"] == 0 for run in report["runs"])
log = (BASE / "gate.log").read_text()
verdict = f"extensions-poc: PASSED local and distributed native extension gates at {SHA}"
assert verdict in log
assert sum(map(int, re.findall(r"test result: ok\. (\d+) passed", log))) == 651
assert re.findall(r"^(64|65) passed", log, re.MULTILINE) == ["64", "65", "65"]
assert all(item["worker_pid"] != item["driver_pid"] for item in receipt["worker_processes"])
assert "No Sail, Cargo, rustc, yes, or Python processes remain" in (BASE / "process-cleanup.log").read_text()
result = {
    "verified_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    "outcome": "exported artifacts match exact-candidate receipt and source objects",
    "sail_commit": SHA, "source_tree": TREE, "host_binary_sha256": receipt["host_binary_sha256"],
    "wheel_sha256": wheel_hashes, "rust_tests_passed": 651,
    "stress_runs_passed": 22, "live_tests_passed_by_mode": {"local": 64, "local-cluster": 65, "process-cluster": 65},
    "local_worker_only_skips": 1, "verdict": verdict,
}
(BASE / "export-verification.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
