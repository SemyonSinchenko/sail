#!/usr/bin/env bash
set -uo pipefail
cd /Users/REDACTED/src/sail-extensions-datafusion-gate
export CARGO_INCREMENTAL=0 CARGO_BUILD_JOBS=6
export SAIL_EXTENSION_FMT_TOOLCHAIN=nightly
export SAIL_EXTENSION_PYTHON=/Users/REDACTED/src/sail-extensions-poc/.venvs/extensions-datafusion/bin/python
export SAIL_EXTENSION_TARGET=/Users/REDACTED/src/sail-extensions-datafusion-gate/target/extensions-poc
export SAIL_EXTENSION_VENV=/Users/REDACTED/src/sail-extensions-datafusion-gate/.venv
expected=de8e670989edb8ed5343764c52d0d002b6b6cd63
"$SAIL_EXTENSION_PYTHON" - "$expected" "$SAIL_EXTENSION_TARGET/run-start.json" <<'PY'
import datetime, json, pathlib, platform, subprocess, sys
expected, path = sys.argv[1:]
head = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
assert head == expected
assert not subprocess.check_output(["git", "status", "--porcelain"], text=True).strip()
pathlib.Path(path).write_text(json.dumps({"started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "commit": head, "host": platform.node(), "platform": platform.platform(), "machine": platform.machine(), "jobs": 6, "cache_seed": "independent APFS clone copies of stopped development caches; build and verify run in own target", "format_toolchain": "nightly; rustfmt 1.9.0-nightly (57d06900fd 2026-05-27), manifest date 2026-05-28"}, indent=2) + "\n")
PY
preflight=$?
if [[ "$preflight" -ne 0 ]]; then exit "$preflight"; fi
bash examples/extensions/scripts/build.sh > "$SAIL_EXTENSION_TARGET/build.log" 2>&1 && \
    bash examples/extensions/scripts/verify.sh > "$SAIL_EXTENSION_TARGET/verify.log" 2>&1
verdict=$?
"$SAIL_EXTENSION_PYTHON" - "$expected" "$verdict" "$SAIL_EXTENSION_TARGET/run-status.json" <<'PY'
import datetime, json, pathlib, subprocess, sys
expected, status, path = sys.argv[1:]
head = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
dirty = subprocess.check_output(["git", "status", "--porcelain"], text=True)
pathlib.Path(path).write_text(json.dumps({"finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "expected_commit": expected, "head": head, "status": int(status), "tracked_state": dirty, "head_matches": head == expected}, indent=2) + "\n")
PY
exit "$verdict"
