#!/usr/bin/env python3
"""Check immutable gate evidence and the source tree before branch publication."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
SHA = "de8e670989edb8ed5343764c52d0d002b6b6cd63"
TREE = "64c851dbf585f430002589c78ac4693aa9b26d3c"
BASE = "18d7f6aa019846e01a10a6e426a76bc4e7e0b347"
LOCKS = {"Cargo.lock", "examples/extensions/sedona/Cargo.lock",
         "examples/extensions/nutmeg/Cargo.lock", "examples/extensions/vendor/nutmeg-graph/Cargo.lock",
         "examples/extensions/requirements.lock"}
STRESS_TESTS = {"cancellation_stress": "tests::dropped_blocked_stream_cancels_and_keeps_exported_batch_valid",
                "snapshot_stress": "graph_tables::tests::separately_planned_concurrent_reads_share_one_revision_cache"}


def git(*args, env=None):
    return subprocess.check_output(["git", *args], cwd=REPO, env=env)


def read(path):
    return json.loads(path.read_text())


def file_hash(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


platforms = {}
for directory, log_name in [
    ("mac-arm64-de8e67098", "verify.log"),
    ("linux-x86_64-de8e67098", "gate.log"),
]:
    folder = ROOT / directory
    receipt = read(folder / "receipt.json")
    assert receipt["sail_commit"] == SHA, directory
    assert receipt["outcome"] == "passed local and distributed native extension gates", directory
    assert receipt["modes"] == ["local", "local-cluster", "process-cluster"], directory
    if directory.startswith("linux"):
        assert receipt["machine"] == "x86_64" and receipt["platform"].startswith("Linux")
        envelope = receipt["resource_envelope"]
        assert envelope["virtual_machine_profile"] == "review-host-b/colima/sail-gate/qemu"
        assert envelope["container_image"] == "sha256:9b75d8d8a14b8b93d251e52b1c8a5936c5720e495bf563b86ba93e00f34acf76"
        assert envelope["cgroup_v2"]["memory.max"] == "77309411328"
        assert receipt["logical_cpus"] == 36
    else:
        assert receipt["machine"] == "arm64" and receipt["platform"].startswith("macOS")
    assert set(receipt["source_locks"]) == LOCKS
    assert len(receipt["wheels"]) == 2
    assert sum(name.startswith("sail_nutmeg-") for name in receipt["wheels"]) == 1
    assert sum(name.startswith("sail_sedona_extension-") for name in receipt["wheels"]) == 1
    assert file_hash(folder / "artifacts/sail") == receipt["host_binary_sha256"]
    for name, digest in receipt["wheels"].items():
        assert file_hash(folder / "artifacts/wheels" / name) == digest
    for name, digest in receipt["source_locks"].items():
        assert hashlib.sha256(git("show", f"{SHA}:{name}")).hexdigest() == digest
    verdict = f"extensions-poc: PASSED local and distributed native extension gates at {SHA}"
    assert verdict in (folder / log_name).read_text(), directory
    for name in ["cancellation_stress", "snapshot_stress"]:
        stress = receipt[name]
        assert stress["head_before"] == stress["head_after"] == SHA
        assert stress["unchanged"] and stress["source_before"] == stress["source_after"]
        assert stress["build_profile"] == "release" and not stress["prebuilt_binary"]
        assert stress["build_exit_code"] == 0 and stress["command"][1] == STRESS_TESTS[name]
        assert len(stress["runs"]) == 11 and all(row.get("exit_code") == 0 for row in stress["runs"])
        assert all("1 passed" in row["stdout"] and "0 failed" in row["stdout"] for row in stress["runs"])
        assert Counter(row["mode"] for row in stress["runs"]) == {"unsaturated": 1, "one_yes_per_logical_cpu": 10}
    assert receipt["worker_processes"]
    assert all(row["driver_pid"] != row["worker_pid"] for row in receipt["worker_processes"])
    platforms[directory] = {"receipt": str(folder / "receipt.json"), "verdict": verdict}

arm_status = read(ROOT / "mac-arm64-de8e67098/run-status.json")
assert arm_status["status"] == 0 and arm_status["head_matches"]
assert arm_status["head"] == arm_status["expected_commit"] == SHA and not arm_status["tracked_state"]
linux_source = read(ROOT / "linux-x86_64-de8e67098/source-identity.json")
assert linux_source["sail_commit"] == SHA and linux_source["source_tree"] == TREE
assert linux_source["detached_head"] and not linux_source["tracked_status"]
assert linux_source["harness_files_sha256"]
for name, digest in linux_source["harness_files_sha256"].items():
    assert hashlib.sha256(git("show", f"{SHA}:{name}")).hexdigest() == digest

two = read(ROOT / "two-host-de8e67098/receipt.json")
assert two["outcome"] == "passed"
inventories = two["inventories"]
assert len(inventories) == 3 and len({row["host"] for row in inventories}) == 2
assert all(row["source_commit"] == SHA and row["source_dirty"] is False for row in inventories)
assert len({row["binary_sha256"] for row in inventories}) == 1
assert file_hash(ROOT / "mac-x86-de8e67098/sail") == inventories[0]["binary_sha256"]
assert all(row["packages"] == inventories[0]["packages"] for row in inventories)
assert {"sedona", "nutmeg"}.issubset(inventories[0]["packages"])
provenance = read(ROOT / "mac-x86-de8e67098/provenance.json")
assert provenance["source_commit"] == SHA and provenance["qualification"]["outcome"] == "passed"
assert provenance["qualification"]["receipt_sha256"] == file_hash(ROOT / "two-host-de8e67098/receipt.json")
assert provenance["build"]["log_sha256"] == file_hash(ROOT / "mac-x86-de8e67098/build.log")
for location in ["local", "remote"]:
    built = provenance["after_build"][location]
    assert built["source_commit"] == SHA and built["source_status"] == ""
    assert built["binary_sha256"] == inventories[0]["binary_sha256"]
    for name, digest in built["wheels_sha256"].items():
        assert file_hash(ROOT / "mac-x86-de8e67098/wheels" / name) == digest
for name, digest in two["harness_sha256"].items():
    expected = hashlib.sha256(git("show", f"{SHA}:examples/extensions/scripts/{name}")).hexdigest()
    assert digest == expected == hashlib.sha256((ROOT / "two-host-de8e67098/harness" / name).read_bytes()).hexdigest()
required_workers = {row["worker_id"] for row in two["checks"]["worker_endpoints"]}
completed = Counter(row["worker_id"] for row in two["completed_worker_tasks"])
assert len(required_workers) == 2 and required_workers == set(completed)
assert len({row["host"] for row in two["checks"]["worker_endpoints"]}) == 2
assert set(two["process_cleanup"]) == {row["host"] for row in inventories}
assert sum(len(rows) for rows in two["process_cleanup"].values()) == 3
assert all(rows and all(row["pid"] > 0 and not row["alive"] for row in rows) for rows in two["process_cleanup"].values())

assert git("rev-parse", "HEAD").decode().strip() in {BASE, SHA}
assert git("branch", "--show-current").decode().strip() == "work/extensions-datafusion-graphs"
subprocess.run(["git", "diff", "--cached", "--exit-code"], cwd=REPO, check=True)
with tempfile.TemporaryDirectory(prefix="sail-publication-index-") as directory:
    env = dict(os.environ, GIT_INDEX_FILE=str(Path(directory) / "index"))
    git("read-tree", BASE, env=env)
    git("add", "-A", env=env)
    git("diff", "--cached", "--check", env=env)
    assert git("write-tree", env=env).decode().strip() == TREE

report = {"checked_utc": datetime.now(timezone.utc).isoformat(), "candidate": SHA, "tree": TREE,
          "platforms": platforms, "completed_tasks_by_worker": dict(completed),
          "outcome": "source and gate evidence match; eligible for publication"}
(ROOT / "publication-check.json").write_text(json.dumps(report, indent=2) + "\n")
print(f"sail-delivery: PASS source and all gate evidence at {SHA}")
