#!/usr/bin/env bash
set -euo pipefail
sha=$1
binary=$2
repo="/tmp/sail-portable-graphs-${sha:0:8}"
output=${3:-"/Users/REDACTED/src/sail-extensions-poc/target/extensions-portable-graphs/review-host-a-${sha:0:8}"}
python=/Users/REDACTED/src/sail-extensions-poc/.venvs/extensions-x86-final-de8e67098/bin/python
mkdir "$output"
cd "$repo"
[[ "$(git rev-parse HEAD)" == "$sha" ]]
[[ -z "$(git status --porcelain)" ]]
export PYTHONPATH="$repo/examples/extensions/graph-algorithms/src"
for mode in local process-cluster; do
    "$python" -m pytest examples/extensions/tests --sail-binary "$binary" \
        --execution-mode "$mode" --basetemp "$output/pytest-$mode" -q > "$output/integration-$mode.log" 2>&1
    "$python" examples/extensions/scripts/test_graph_algorithms.py --sail-binary "$binary" \
        --execution-mode "$mode" --output "$output/package-$mode" > "$output/package-$mode.log" 2>&1
done
"$python" -m unittest discover -s examples/extensions/scripts/tests -v > "$output/launcher.log" 2>&1
[[ "$(git rev-parse HEAD)" == "$sha" ]]
[[ -z "$(git status --porcelain)" ]]
printf 'portable-graphs review-host-a macOS/Rosetta PASS %s\n' "$sha" | tee "$output/verdict.txt"
