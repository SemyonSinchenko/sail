# Development controls

Final qualification is recorded in the 70b0d1ca receipts. Other files retain earlier observations:

- bd0e64a8 Rust host builds passed; session tests failed to compile because a test called SQL APIs with the SQL feature disabled. The test was rewritten using DataFrame/UDF APIs.
- Initial real-protocol Python runs exposed the Row.count accessor collision (six package failures and one utility failure). The client now reads the named field by index.
- The debug-log negative control deliberately used the pre-fix bd0e64a8 executable. It failed by detecting the run token in Connect logging.
- The 5e040e1d distributed listing test failed on both Linux and review-host-a because its four-partition write produced one file. The independent listing probe retained that one-file observation. The final fixture writes two independent outputs and preserves its truncation assertion.
- A development run combined the 70b0d1ca Python tests with the older ee4ed882 executable. Its suites passed, but the temporary coordinator script was edited while running and ended with a shell syntax error. No aggregate verdict from that run is used. Final review-host-a evidence uses the separately rebuilt 30184639 executable and an unchanged coordinator script.

Recorded UTC: 2026-09-27T17:42:37.868906+00:00
