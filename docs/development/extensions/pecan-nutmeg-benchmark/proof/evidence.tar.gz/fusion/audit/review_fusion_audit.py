"""Reconstruct contemporaneous fusion comparisons from retained cell receipts."""
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import statistics

BASE = Path(__file__).resolve().parent
REPO = BASE.parent.parent
AUDIT = BASE / "fusion-audit.json"
EVIDENCE = REPO / "target/extensions-pecan-benchmark/export/export-fusion-matrix-3fd69787"
SUMMARY = REPO / "target/extensions-pecan-benchmark/export/fusion-matrix-3fd69787-summary/summary.json"


def read(path):
    return json.loads(path.read_text())


def stats(values):
    present = [v for v in values if v is not None]
    return None if not present else dict(samples=len(present), minimum=min(present),
                                        median=statistics.median(present), maximum=max(present))


def display(value, scale=1):
    if value is None:
        return "unavailable"
    return f"{value['median']/scale:.3f} [{value['minimum']/scale:.3f}–{value['maximum']/scale:.3f}]"


def main():
    audit, summary = read(AUDIT), read(SUMMARY)
    assert audit["audit_outcome"] == "passed" and not audit["issues"]
    grouped = defaultdict(lambda: defaultdict(list))
    boundaries, caches, outputs = Counter(), Counter(), Counter()
    for cell in audit["cells"]:
        receipt = read(EVIDENCE / "cells" / cell["cell_id"] / "artifacts/receipt.json")
        assert receipt["outcome"] == cell["outcome"] == "passed"
        key = tuple(cell[k] for k in ("suite", "dataset", "mode", "engine"))
        memory = cell["memory"].get("execution_peaks") or {}
        grouped[key][cell["variant"]].append(dict(
            cell_id=cell["cell_id"], repeat=cell["repeat"],
            seconds=receipt["end_to_end_seconds"], pss_bytes=memory.get("pss_bytes"),
            execution_samples=cell["memory"]["execution_samples"],
        ))
        boundaries[receipt["boundary"]] += 1
        caches[receipt["cache_boundary"]] += 1
        outputs[receipt["output_action_boundary"]] += 1
    comparisons = []
    for key, variants in sorted(grouped.items()):
        assert set(variants) == {"optimized", "fused"}
        row = dict(zip(("suite", "dataset", "mode", "engine"), key))
        for variant, values in variants.items():
            row[variant] = {metric: stats([v[metric] for v in values])
                            for metric in ("seconds", "pss_bytes", "execution_samples")}
            row[variant]["cells"] = values
            published = next(g for g in summary["groups"]
                             if all(g[k] == row[k] for k in ("suite", "dataset", "mode", "engine"))
                             and g["variant"] == variant)
            assert row[variant]["seconds"] == published["metrics"]["seconds"]
            assert row[variant]["pss_bytes"] == published["metrics"]["execution_pss_bytes"]
        for metric in ("seconds", "pss_bytes"):
            old, new = row["optimized"][metric], row["fused"][metric]
            row[f"fused_over_unfused_{metric}"] = new["median"] / old["median"] if old and new else None
            row[f"ranges_overlap_{metric}"] = (
                new["minimum"] <= old["maximum"] and old["minimum"] <= new["maximum"]
            ) if old and new else None
        comparisons.append(row)
    raw = [c for c in audit["cells"] if c["raw"]["coverage"] == "raw_full_vector"]
    absent = [c["cell_id"] for c in audit["cells"] if c["memory"]["pss_samples"] == 0]
    traces = []
    for trace in audit["cross_path_contractions"]:
        initial = defaultdict(set)
        for cell in audit["cells"]:
            if cell["dataset"] == trace["dataset"]:
                initial[cell["variant"]].add(trace["initial_counts"][cell["cell_id"]])
        traces.append(dict(dataset=trace["dataset"], cells=len(trace["compared_cells"]),
                           rounds=trace["rounds"], first_edges_by_variant={k: sorted(v) for k,v in initial.items()},
                           all_later_common_trace_fields_identical=True))
    review = dict(
        recorded_utc=datetime.now(timezone.utc).isoformat(),
        audit_sha256=hashlib.sha256(AUDIT.read_bytes()).hexdigest(),
        auditor_sha256=audit["auditor_sha256"], sources=audit["sources"],
        outcomes=audit["outcomes"], comparisons=comparisons,
        raw_coverage=audit["raw_coverage"], raw_cells=[dict(cell_id=c["cell_id"], **c["raw"]) for c in raw],
        reconstructed_memory_samples=audit["reconstructed_samples"],
        cells_without_execution_pss=absent, sample_coverage=audit["sample_coverage"],
        contractions=traces, native_widths=audit["native_widths"],
        boundaries=dict(boundaries), cache_boundaries=dict(caches), output_boundaries=dict(outputs),
        steal=audit["steal_observations"], cleanup=audit["post_stop_cleanup"],
        exit_codes=dict(Counter(c["orchestration"]["exit_code"] for c in audit["cells"])),
        limitations=[
            "Six 100k process-worker repeat-1 outputs have independent full-Parquet verification; the other 72 are receipt-only.",
            "The native fused chain trial has no execution RSS/PSS sample; unavailable is not zero memory.",
            "Ratios divide contemporaneous group medians, not paired-trial ratios or causal effect estimates.",
            "There are three sparse repetitions per group and one chain diagnostic per method; overlap is descriptive, not a significance test.",
            "All whole-VM steal observations are zero; that does not measure scheduling delay outside the VM.",
            "PSS sampling can miss peaks, and cgroup page-cache ownership makes its warm-cache peak a different memory boundary.",
            "Representative-map parity is established by implementation tests; exported benchmark traces compare coefficients/counts, and the selected full outputs verify the final partitions.",
        ],
    )
    (BASE / "fusion-audit-review.json").write_text(json.dumps(review, indent=2) + "\n")
    lines = ["# Independent fusion evidence review", "", f"Recorded {review['recorded_utc']}.", "",
             "All 78 trials pass, with no auditor issues or warnings. The exact recorded summarizer and independent receipt reconstruction agree on every median and range. No original outcome is replaced.", "",
             "## Contemporaneous comparisons", "",
             "Values are median [minimum–maximum]. PSS is MiB. Ratios are fused/unfused group medians. Sparse groups have three repeats; chain diagnostics have one.", "",
             "| Suite | Dataset | Path | Unfused seconds | Fused seconds | Time ratio | Unfused PSS | Fused PSS | PSS ratio |", 
             "| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |"]
    names = {"nutmeg-native": "Banda", "nutmeg-datafusion": "Grenada", "pecan": "Pecan"}
    for row in comparisons:
        pr = row["fused_over_unfused_pss_bytes"]
        lines.append(f"| {row['suite']} | {row['dataset']} | {names[row['engine']]} | "
                     f"{display(row['optimized']['seconds'])} | {display(row['fused']['seconds'])} | "
                     f"{row['fused_over_unfused_seconds']:.4f} | {display(row['optimized']['pss_bytes'], 2**20)} | "
                     f"{display(row['fused']['pss_bytes'], 2**20)} | {pr:.4f} |" if pr is not None else
                     f"| {row['suite']} | {row['dataset']} | {names[row['engine']]} | "
                     f"{display(row['optimized']['seconds'])} | {display(row['fused']['seconds'])} | "
                     f"{row['fused_over_unfused_seconds']:.4f} | {display(row['optimized']['pss_bytes'], 2**20)} | unavailable | unavailable |")
    lines += ["", "All fifteen fused medians are lower in elapsed time. This does not establish a general benefit: several native time ranges overlap, and four observed PSS medians increase (one is the single chain trial). At 1m, both relational PSS ranges rise entirely above their unfused ranges. All sparse and local outcomes, including these higher-memory cases, remain in the tables.", "",
              "## Integrity, correctness and trace coverage", "",
              f"Harness `{audit['sources']['harness_source_sha']}`, native `{audit['sources']['native_source_sha']}`, runtime `{audit['sources']['runtime_source_sha']}`.", "",
              f"All {audit['unique_verified_files']} distinct delivered files were hashed ({audit['checked_files']} file checks). Binary SHA-256 is `{audit['binary_sha256'][0]}`; native installed-file identity is `{audit['native_installed_file_identity'][0]}`. All 78 cell limits agree with the frozen configuration: eight CPU units, cpuset 0–7, 32 GiB aggregate, 16 GiB Sail pool per process, 8 GiB driver/local native allowance, 32 task slots per worker and requested native concurrency eight.", "",
              "The six delivered 100k repeat-1 result sets cover all three entry paths and both variants. Every one has 100,000 unique vertex IDs, 5,093 independently recomputed connected components and zero membership mismatches. Verification uses union-find over the actual delivered edge Parquet; it imports no tested algorithm. The other 72 final vectors were not copied locally, so their correctness is recorded server validation, not an independent raw-vector audit.", "",
              "All 78 contraction traces have the expected SplitMix64 coefficient stream. For each dataset, every later common contracted-graph count agrees across paths, variants, modes and repeats. Counts do not prove all intermediate representative maps; the implementation regression tests cover that stronger property.", "",
              "| Dataset | Cells | Rounds | Unfused first edges | Fused first edges |", "| --- | ---: | ---: | ---: | ---: |"]
    for trace in traces:
        lines.append(f"| {trace['dataset']} | {trace['cells']} | {trace['rounds']} | {trace['first_edges_by_variant']['optimized']} | {trace['first_edges_by_variant']['fused']} |")
    lines += ["", "Actual native kernel widths are three for 10k, eight for 100k/1m, and one for chain-512, with requested concurrency eight in every native trial. Both native variants follow the same width policy.", "",
              "## Sampling, timing and cleanup", "",
              "All 5,147 samples were rebuilt from their process entries, including phase maxima and summaries. There are 77 cells with execution PSS samples and one without. Native fused execution sample counts range 0–107, native unfused 1–114; relational counts range 22–110. The longest execution scan is 0.087394 seconds, additional to the 50 ms wait. The fused native chain takes about 42 ms and has no execution memory sample; its memory is not imputed from startup, verification, cgroup or the unfused trial.", "",
              "The timer includes lazy graph evaluation, input validation, graph conversion/staging where applicable, contractions/back-expansion, internal writes, per-iteration instrumentation and the final caller-owned output write. Independent correctness, status reads/file hashing and cleanup occur after the timer. Native execution occurs inside the output action; output-action time is not export-only. PSS is the sum over the cell's private-PID-namespace processes. Cgroup through-result peaks include earlier startup/cache charges and have a distinct boundary.", "",
              "All 78 containers exited zero, were removed, and had no recorded OOM, outer timeout, transport or cleanup error. The exact-source post-stop snapshot contains all 78 cell directories and zero remaining staging regular files. All 78 VM-wide steal observations are 0.0; this says nothing about unmeasured host scheduling delay.", "",
              "This supplement retains contemporaneous unfused controls from the same native wheel. Earlier primary/constrained outcomes remain separate; no failed historical trial was erased or recast as a fusion pass.", "",
              "## Limits", ""]
    lines.extend(f"- {value}" for value in review["limitations"])
    (BASE / "fusion-audit-review.md").write_text("\n".join(lines) + "\n")
    print(json.dumps({"comparisons": len(comparisons), "raw_full_vectors": len(raw),
                      "missing_execution_pss": absent, "review": str(BASE / 'fusion-audit-review.md')}))


if __name__ == "__main__":
    main()
