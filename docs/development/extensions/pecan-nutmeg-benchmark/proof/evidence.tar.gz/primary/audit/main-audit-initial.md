# Independent main evidence audit

Recorded 2026-09-27T20:38:14.889095+00:00. Audit verdict: **passed**.

150 planned cells; outcomes: 148 passed, 2 nonconverged.

Original trial outcomes are retained unchanged. An audit failure is a separate evidence-integrity finding, not a rewritten benchmark outcome.

## Identity and coverage

- harness_source_sha: `3c1fd28c8745864ca7426f13f42ef251269cb103`.
- runtime_source_sha: `70b0d1cab2cab945d4dbaf6842ee0e38c8aa1822`.
- native_source_sha: `4e6100f0320fb952e9926b867193ec1768edfcda`.

Performed 1150 inventory checks across 1010 unique files; reconstructed 20480 raw memory samples.
Raw correctness coverage: 16 raw_full_vector, 134 receipt_only.

Raw-vector checks read actual Parquet and independently recompute PageRank fixed-point residuals/full-vector errors and WCC components from input edges. Receipt-only checks validate recorded results and hashes; they are not a new calculation from omitted graph rows.

## Findings

No audit integrity defects found.

## Coverage limits

- `matrix`: no independent post-stop cleanup snapshot; error-cell cleanup coverage may be limited

## Every planned outcome

| Sequence | Cell | Outcome | Correctness audit | Execution samples |
| --- | --- | --- | --- | ---: |
| 1 | `distributed-r1-sparse-100000-nutmeg-datafusion-wcc-reference` | passed | raw_full_vector | 19 |
| 2 | `distributed-r1-sparse-1000000-nutmeg-native-pagerank-optimized` | passed | raw_full_vector | 161 |
| 3 | `distributed-r1-sparse-10000-nutmeg-native-wcc-reference` | passed | receipt_only | 2 |
| 4 | `distributed-r1-sparse-10000-pecan-pagerank-optimized` | passed | receipt_only | 147 |
| 5 | `distributed-r1-sparse-1000000-nutmeg-datafusion-pagerank-reference` | passed | receipt_only | 539 |
| 6 | `distributed-r1-sparse-1000000-nutmeg-datafusion-pagerank-optimized` | passed | receipt_only | 678 |
| 7 | `distributed-r1-sparse-100000-nutmeg-native-pagerank-reference` | passed | raw_full_vector | 14 |
| 8 | `distributed-r1-sparse-100000-nutmeg-datafusion-wcc-optimized` | passed | raw_full_vector | 47 |
| 9 | `distributed-r1-sparse-100000-nutmeg-native-pagerank-optimized` | passed | raw_full_vector | 20 |
| 10 | `distributed-r1-sparse-1000000-pecan-pagerank-optimized` | passed | receipt_only | 693 |
| 11 | `distributed-r1-sparse-100000-nutmeg-native-wcc-optimized` | passed | raw_full_vector | 12 |
| 12 | `distributed-r1-sparse-10000-nutmeg-datafusion-wcc-reference` | passed | receipt_only | 12 |
| 13 | `distributed-r1-sparse-1000000-nutmeg-native-pagerank-reference` | passed | raw_full_vector | 98 |
| 14 | `distributed-r1-sparse-100000-nutmeg-native-wcc-reference` | passed | raw_full_vector | 9 |
| 15 | `distributed-r1-sparse-100000-pecan-pagerank-optimized` | passed | raw_full_vector | 199 |
| 16 | `distributed-r1-sparse-1000000-pecan-wcc-optimized` | passed | receipt_only | 105 |
| 17 | `distributed-r1-sparse-1000000-nutmeg-datafusion-wcc-reference` | passed | receipt_only | 88 |
| 18 | `distributed-r1-sparse-10000-pecan-pagerank-reference` | passed | receipt_only | 106 |
| 19 | `distributed-r1-sparse-10000-nutmeg-datafusion-pagerank-reference` | passed | receipt_only | 107 |
| 20 | `distributed-r1-sparse-1000000-pecan-pagerank-reference` | passed | receipt_only | 537 |
| 21 | `distributed-r1-sparse-100000-pecan-wcc-reference` | passed | raw_full_vector | 18 |
| 22 | `distributed-r1-sparse-1000000-pecan-wcc-reference` | passed | receipt_only | 86 |
| 23 | `distributed-r1-sparse-10000-nutmeg-native-pagerank-optimized` | passed | receipt_only | 4 |
| 24 | `distributed-r1-sparse-1000000-nutmeg-native-wcc-reference` | passed | raw_full_vector | 92 |
| 25 | `distributed-r1-sparse-10000-nutmeg-datafusion-pagerank-optimized` | passed | receipt_only | 148 |
| 26 | `distributed-r1-sparse-10000-pecan-wcc-optimized` | passed | receipt_only | 31 |
| 27 | `distributed-r1-sparse-100000-nutmeg-datafusion-pagerank-optimized` | passed | raw_full_vector | 200 |
| 28 | `distributed-r1-sparse-10000-nutmeg-datafusion-wcc-optimized` | passed | receipt_only | 30 |
| 29 | `distributed-r1-sparse-100000-pecan-pagerank-reference` | passed | raw_full_vector | 150 |
| 30 | `distributed-r1-sparse-1000000-nutmeg-datafusion-wcc-optimized` | passed | receipt_only | 105 |
| 31 | `distributed-r1-sparse-10000-pecan-wcc-reference` | passed | receipt_only | 11 |
| 32 | `distributed-r1-sparse-10000-nutmeg-native-pagerank-reference` | passed | receipt_only | 3 |
| 33 | `distributed-r1-sparse-10000-nutmeg-native-wcc-optimized` | passed | receipt_only | 2 |
| 34 | `distributed-r1-sparse-100000-nutmeg-datafusion-pagerank-reference` | passed | raw_full_vector | 149 |
| 35 | `distributed-r1-sparse-1000000-nutmeg-native-wcc-optimized` | passed | raw_full_vector | 112 |
| 36 | `distributed-r1-sparse-100000-pecan-wcc-optimized` | passed | raw_full_vector | 48 |
| 37 | `distributed-r2-sparse-100000-nutmeg-datafusion-wcc-optimized` | passed | receipt_only | 51 |
| 38 | `distributed-r2-sparse-10000-nutmeg-native-wcc-reference` | passed | receipt_only | 2 |
| 39 | `distributed-r2-sparse-10000-nutmeg-datafusion-wcc-optimized` | passed | receipt_only | 31 |
| 40 | `distributed-r2-sparse-100000-nutmeg-datafusion-pagerank-optimized` | passed | receipt_only | 202 |
| 41 | `distributed-r2-sparse-1000000-nutmeg-datafusion-pagerank-optimized` | passed | receipt_only | 665 |
| 42 | `distributed-r2-sparse-100000-pecan-wcc-reference` | passed | receipt_only | 17 |
| 43 | `distributed-r2-sparse-100000-nutmeg-native-pagerank-reference` | passed | receipt_only | 13 |
| 44 | `distributed-r2-sparse-1000000-nutmeg-native-pagerank-reference` | passed | receipt_only | 99 |
| 45 | `distributed-r2-sparse-1000000-nutmeg-datafusion-wcc-reference` | passed | receipt_only | 87 |
| 46 | `distributed-r2-sparse-1000000-pecan-pagerank-optimized` | passed | receipt_only | 675 |
| 47 | `distributed-r2-sparse-10000-nutmeg-datafusion-pagerank-optimized` | passed | receipt_only | 148 |
| 48 | `distributed-r2-sparse-1000000-nutmeg-native-wcc-optimized` | passed | receipt_only | 112 |
| 49 | `distributed-r2-sparse-100000-pecan-pagerank-optimized` | passed | receipt_only | 201 |
| 50 | `distributed-r2-sparse-1000000-nutmeg-native-pagerank-optimized` | passed | receipt_only | 160 |
| 51 | `distributed-r2-sparse-100000-nutmeg-datafusion-pagerank-reference` | passed | receipt_only | 147 |
| 52 | `distributed-r2-sparse-1000000-nutmeg-datafusion-pagerank-reference` | passed | receipt_only | 548 |
| 53 | `distributed-r2-sparse-100000-nutmeg-native-pagerank-optimized` | passed | receipt_only | 20 |
| 54 | `distributed-r2-sparse-1000000-pecan-pagerank-reference` | passed | receipt_only | 543 |
| 55 | `distributed-r2-sparse-100000-nutmeg-native-wcc-reference` | passed | receipt_only | 9 |
| 56 | `distributed-r2-sparse-1000000-pecan-wcc-reference` | passed | receipt_only | 85 |
| 57 | `distributed-r2-sparse-100000-pecan-wcc-optimized` | passed | receipt_only | 47 |
| 58 | `distributed-r2-sparse-10000-nutmeg-native-pagerank-optimized` | passed | receipt_only | 4 |
| 59 | `distributed-r2-sparse-10000-pecan-pagerank-reference` | passed | receipt_only | 105 |
| 60 | `distributed-r2-sparse-10000-nutmeg-datafusion-wcc-reference` | passed | receipt_only | 12 |
| 61 | `distributed-r2-sparse-100000-nutmeg-native-wcc-optimized` | passed | receipt_only | 13 |
| 62 | `distributed-r2-sparse-10000-nutmeg-datafusion-pagerank-reference` | passed | receipt_only | 103 |
| 63 | `distributed-r2-sparse-10000-nutmeg-native-pagerank-reference` | passed | receipt_only | 3 |
| 64 | `distributed-r2-sparse-10000-pecan-pagerank-optimized` | passed | receipt_only | 150 |
| 65 | `distributed-r2-sparse-100000-pecan-pagerank-reference` | passed | receipt_only | 148 |
| 66 | `distributed-r2-sparse-1000000-nutmeg-native-wcc-reference` | passed | receipt_only | 91 |
| 67 | `distributed-r2-sparse-100000-nutmeg-datafusion-wcc-reference` | passed | receipt_only | 19 |
| 68 | `distributed-r2-sparse-10000-pecan-wcc-reference` | passed | receipt_only | 12 |
| 69 | `distributed-r2-sparse-10000-pecan-wcc-optimized` | passed | receipt_only | 32 |
| 70 | `distributed-r2-sparse-1000000-nutmeg-datafusion-wcc-optimized` | passed | receipt_only | 106 |
| 71 | `distributed-r2-sparse-1000000-pecan-wcc-optimized` | passed | receipt_only | 106 |
| 72 | `distributed-r2-sparse-10000-nutmeg-native-wcc-optimized` | passed | receipt_only | 2 |
| 73 | `distributed-r3-sparse-100000-nutmeg-native-pagerank-optimized` | passed | receipt_only | 20 |
| 74 | `distributed-r3-sparse-100000-nutmeg-datafusion-wcc-reference` | passed | receipt_only | 18 |
| 75 | `distributed-r3-sparse-1000000-nutmeg-datafusion-pagerank-reference` | passed | receipt_only | 542 |
| 76 | `distributed-r3-sparse-100000-nutmeg-datafusion-wcc-optimized` | passed | receipt_only | 47 |
| 77 | `distributed-r3-sparse-1000000-nutmeg-datafusion-wcc-optimized` | passed | receipt_only | 104 |
| 78 | `distributed-r3-sparse-1000000-nutmeg-native-wcc-reference` | passed | receipt_only | 92 |
| 79 | `distributed-r3-sparse-1000000-nutmeg-datafusion-pagerank-optimized` | passed | receipt_only | 671 |
| 80 | `distributed-r3-sparse-10000-nutmeg-datafusion-wcc-reference` | passed | receipt_only | 12 |
| 81 | `distributed-r3-sparse-10000-pecan-pagerank-optimized` | passed | receipt_only | 144 |
| 82 | `distributed-r3-sparse-100000-pecan-pagerank-optimized` | passed | receipt_only | 197 |
| 83 | `distributed-r3-sparse-10000-nutmeg-datafusion-pagerank-optimized` | passed | receipt_only | 147 |
| 84 | `distributed-r3-sparse-100000-pecan-wcc-reference` | passed | receipt_only | 17 |
| 85 | `distributed-r3-sparse-100000-nutmeg-datafusion-pagerank-optimized` | passed | receipt_only | 197 |
| 86 | `distributed-r3-sparse-1000000-pecan-wcc-reference` | passed | receipt_only | 86 |
| 87 | `distributed-r3-sparse-1000000-nutmeg-native-pagerank-reference` | passed | receipt_only | 98 |
| 88 | `distributed-r3-sparse-10000-pecan-wcc-optimized` | passed | receipt_only | 30 |
| 89 | `distributed-r3-sparse-10000-pecan-wcc-reference` | passed | receipt_only | 11 |
| 90 | `distributed-r3-sparse-1000000-nutmeg-datafusion-wcc-reference` | passed | receipt_only | 85 |
| 91 | `distributed-r3-sparse-100000-nutmeg-native-wcc-reference` | passed | receipt_only | 10 |
| 92 | `distributed-r3-sparse-10000-nutmeg-datafusion-wcc-optimized` | passed | receipt_only | 31 |
| 93 | `distributed-r3-sparse-10000-nutmeg-native-pagerank-optimized` | passed | receipt_only | 3 |
| 94 | `distributed-r3-sparse-1000000-pecan-wcc-optimized` | passed | receipt_only | 106 |
| 95 | `distributed-r3-sparse-10000-nutmeg-datafusion-pagerank-reference` | passed | receipt_only | 104 |
| 96 | `distributed-r3-sparse-1000000-pecan-pagerank-optimized` | passed | receipt_only | 663 |
| 97 | `distributed-r3-sparse-100000-nutmeg-datafusion-pagerank-reference` | passed | receipt_only | 150 |
| 98 | `distributed-r3-sparse-100000-pecan-wcc-optimized` | passed | receipt_only | 48 |
| 99 | `distributed-r3-sparse-1000000-nutmeg-native-wcc-optimized` | passed | receipt_only | 110 |
| 100 | `distributed-r3-sparse-10000-nutmeg-native-wcc-reference` | passed | receipt_only | 2 |
| 101 | `distributed-r3-sparse-1000000-pecan-pagerank-reference` | passed | receipt_only | 509 |
| 102 | `distributed-r3-sparse-100000-nutmeg-native-pagerank-reference` | passed | receipt_only | 14 |
| 103 | `distributed-r3-sparse-10000-pecan-pagerank-reference` | passed | receipt_only | 104 |
| 104 | `distributed-r3-sparse-10000-nutmeg-native-wcc-optimized` | passed | receipt_only | 2 |
| 105 | `distributed-r3-sparse-1000000-nutmeg-native-pagerank-optimized` | passed | receipt_only | 156 |
| 106 | `distributed-r3-sparse-100000-pecan-pagerank-reference` | passed | receipt_only | 147 |
| 107 | `distributed-r3-sparse-10000-nutmeg-native-pagerank-reference` | passed | receipt_only | 3 |
| 108 | `distributed-r3-sparse-100000-nutmeg-native-wcc-optimized` | passed | receipt_only | 12 |
| 109 | `local-r1-sparse-100000-nutmeg-datafusion-pagerank-reference` | passed | receipt_only | 120 |
| 110 | `local-r1-sparse-100000-pecan-wcc-reference` | passed | receipt_only | 14 |
| 111 | `local-r1-sparse-100000-nutmeg-datafusion-wcc-reference` | passed | receipt_only | 16 |
| 112 | `local-r1-sparse-100000-pecan-pagerank-reference` | passed | receipt_only | 119 |
| 113 | `local-r1-sparse-100000-pecan-pagerank-optimized` | passed | receipt_only | 162 |
| 114 | `local-r1-sparse-100000-nutmeg-native-pagerank-reference` | passed | receipt_only | 14 |
| 115 | `local-r1-sparse-100000-nutmeg-native-wcc-optimized` | passed | receipt_only | 14 |
| 116 | `local-r1-sparse-100000-pecan-wcc-optimized` | passed | receipt_only | 42 |
| 117 | `local-r1-sparse-100000-nutmeg-datafusion-pagerank-optimized` | passed | receipt_only | 161 |
| 118 | `local-r1-sparse-100000-nutmeg-datafusion-wcc-optimized` | passed | receipt_only | 42 |
| 119 | `local-r1-sparse-100000-nutmeg-native-pagerank-optimized` | passed | receipt_only | 19 |
| 120 | `local-r1-sparse-100000-nutmeg-native-wcc-reference` | passed | receipt_only | 9 |
| 121 | `local-r2-sparse-100000-nutmeg-native-pagerank-reference` | passed | receipt_only | 13 |
| 122 | `local-r2-sparse-100000-nutmeg-datafusion-pagerank-optimized` | passed | receipt_only | 155 |
| 123 | `local-r2-sparse-100000-nutmeg-native-wcc-reference` | passed | receipt_only | 9 |
| 124 | `local-r2-sparse-100000-nutmeg-datafusion-pagerank-reference` | passed | receipt_only | 112 |
| 125 | `local-r2-sparse-100000-nutmeg-datafusion-wcc-optimized` | passed | receipt_only | 41 |
| 126 | `local-r2-sparse-100000-pecan-wcc-optimized` | passed | receipt_only | 40 |
| 127 | `local-r2-sparse-100000-nutmeg-datafusion-wcc-reference` | passed | receipt_only | 13 |
| 128 | `local-r2-sparse-100000-pecan-pagerank-reference` | passed | receipt_only | 112 |
| 129 | `local-r2-sparse-100000-nutmeg-native-pagerank-optimized` | passed | receipt_only | 20 |
| 130 | `local-r2-sparse-100000-pecan-pagerank-optimized` | passed | receipt_only | 156 |
| 131 | `local-r2-sparse-100000-pecan-wcc-reference` | passed | receipt_only | 12 |
| 132 | `local-r2-sparse-100000-nutmeg-native-wcc-optimized` | passed | receipt_only | 13 |
| 133 | `local-r3-sparse-100000-nutmeg-native-wcc-reference` | passed | receipt_only | 9 |
| 134 | `local-r3-sparse-100000-nutmeg-native-pagerank-reference` | passed | receipt_only | 14 |
| 135 | `local-r3-sparse-100000-pecan-pagerank-reference` | passed | receipt_only | 126 |
| 136 | `local-r3-sparse-100000-nutmeg-datafusion-pagerank-optimized` | passed | receipt_only | 167 |
| 137 | `local-r3-sparse-100000-pecan-pagerank-optimized` | passed | receipt_only | 165 |
| 138 | `local-r3-sparse-100000-pecan-wcc-optimized` | passed | receipt_only | 43 |
| 139 | `local-r3-sparse-100000-pecan-wcc-reference` | passed | receipt_only | 13 |
| 140 | `local-r3-sparse-100000-nutmeg-native-pagerank-optimized` | passed | receipt_only | 20 |
| 141 | `local-r3-sparse-100000-nutmeg-datafusion-pagerank-reference` | passed | receipt_only | 122 |
| 142 | `local-r3-sparse-100000-nutmeg-datafusion-wcc-optimized` | passed | receipt_only | 40 |
| 143 | `local-r3-sparse-100000-nutmeg-native-wcc-optimized` | passed | receipt_only | 12 |
| 144 | `local-r3-sparse-100000-nutmeg-datafusion-wcc-reference` | passed | receipt_only | 14 |
| 145 | `chain-diagnostic-r1-chain-512-nutmeg-datafusion-wcc-reference` | nonconverged | receipt_only | 127 |
| 146 | `chain-diagnostic-r1-chain-512-pecan-wcc-optimized` | passed | receipt_only | 40 |
| 147 | `chain-diagnostic-r1-chain-512-nutmeg-datafusion-wcc-optimized` | passed | receipt_only | 39 |
| 148 | `chain-diagnostic-r1-chain-512-nutmeg-native-wcc-reference` | passed | receipt_only | 1 |
| 149 | `chain-diagnostic-r1-chain-512-nutmeg-native-wcc-optimized` | passed | receipt_only | 1 |
| 150 | `chain-diagnostic-r1-chain-512-pecan-wcc-reference` | nonconverged | receipt_only | 121 |

RSS/PSS are sampled execution-phase totals; short peaks may be missed. RSS can double-count shared mappings; PSS apportions them. Cgroup peaks include cache and lifetime activity and are not interchangeable with PSS or native admission accounting. No elapsed-time or memory ranking is inferred by this audit.

Cross-path WCC trace comparisons check coefficients, active vertices and contracted edges; only the first raw-edge input count may differ for fused plans. Floating PageRank frontier traces are recorded without requiring equality across different reduction orders.
