from pyspark.sql.connect.session import SparkSession
from pyspark.sql.connect import functions as F
from pyspark_pecan import GraphAlgorithms, GraphUtils
from sail_nutmeg import Nutmeg

spark = SparkSession.builder.remote('sc://127.0.0.1:50051').create()
try:
    utils = GraphUtils(spark)
    assert {'fs', 'owned_runs_v1', 'axpb'} <= utils.capabilities
    vertices = spark.createDataFrame([(0,), (1,), (2,), (3,), (9,)], 'id long')
    edges = spark.createDataFrame([(0, 1), (1, 2), (2, 0), (2, 3)], 'src long, dst long')
    graph = GraphAlgorithms(spark)

    def relational(name, nodes, links):
        for method in ('power', 'delta'):
            with graph.pagerank(nodes, links, method=method, tolerance=1e-8,
                                max_iterations=1000, partitions=4) as result:
                print(name, 'PageRank', method, result.iterations)
                result.frame.orderBy('id').show()
        for method in ('min_label', 'randomized', 'randomized_fused'):
            with graph.wcc(nodes, links, method=method, seed=42,
                           max_iterations=100, partitions=4) as result:
                print(name, 'WCC', method, result.iterations)
                result.frame.orderBy('id').show()

    relational('Pecan', vertices, edges)
    nm = Nutmeg(spark)
    tables = nm.tables(vertices, edges, node_id='id', source='src', target='dst')
    relational('Grenada', tables.nodes.select(F.col('node_id').alias('id')),
               tables.edges.select(F.col('source').alias('src'), F.col('target').alias('dst')))

    nm.stage('tutorial', vertices.select(F.col('id').cast('string').alias('node_id')),
             edges.select(F.col('src').cast('string').alias('source'),
                          F.col('dst').cast('string').alias('target')))
    try:
        for kernel in ('pagerank', 'pagerankDelta'):
            print('Banda', kernel)
            nm.run('tutorial', kernel, damping=0.85, tolerance=1e-8,
                   maxIterations=1000, precision='f64', orientation='outgoing',
                   concurrency=4).orderBy('nodeId').show()
        for kernel in ('wcc', 'wccRandomized', 'wccRandomizedFused'):
            options = dict(maxIterations=100, seed=42) if kernel != 'wcc' else {}
            print('Banda', kernel)
            nm.run('tutorial', kernel, concurrency=4, **options).orderBy('nodeId').show()
    finally:
        nm.drop('tutorial')
finally:
    spark.stop()
