# All PageRank and WCC methods

Cells show median [minimum, maximum] for passed trials only; n is the available sample count for that metric. Counts retain every outcome.

RSS/PSS are sampled execution-phase process totals. Cgroup peak is the lifetime peak through result delivery, before verification. Memory is MiB.


## qualification / sparse-100000 / process-cluster / wcc

| Path | Variant | Outcomes | Seconds | PSS MiB | RSS MiB | Cgroup MiB |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| Grenada | fused | passed: 1 | 2.661 [2.661, 2.661] (n=1) | 1245.170 [1245.170, 1245.170] (n=1) | 1383.422 [1383.422, 1383.422] (n=1) | 1194.559 [1194.559, 1194.559] (n=1) |
| Banda | fused | passed: 1 | 0.799 [0.799, 0.799] (n=1) | 747.854 [747.854, 747.854] (n=1) | 873.367 [873.367, 873.367] (n=1) | 664.398 [664.398, 664.398] (n=1) |
| Pecan | fused | passed: 1 | 2.630 [2.630, 2.630] (n=1) | 1270.873 [1270.873, 1270.873] (n=1) | 1408.738 [1408.738, 1408.738] (n=1) | 1226.793 [1226.793, 1226.793] (n=1) |

## qualification / sparse-1000000 / process-cluster / wcc

| Path | Variant | Outcomes | Seconds | PSS MiB | RSS MiB | Cgroup MiB |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| Grenada | fused | passed: 1 | 7.698 [7.698, 7.698] (n=1) | 2065.486 [2065.486, 2065.486] (n=1) | 2198.996 [2198.996, 2198.996] (n=1) | 2148.535 [2148.535, 2148.535] (n=1) |
| Banda | fused | passed: 1 | 7.551 [7.551, 7.551] (n=1) | 1889.369 [1889.369, 1889.369] (n=1) | 2014.742 [2014.742, 2014.742] (n=1) | 1851.902 [1851.902, 1851.902] (n=1) |
| Pecan | fused | passed: 1 | 7.410 [7.410, 7.410] (n=1) | 2062.819 [2062.819, 2062.819] (n=1) | 2200.121 [2200.121, 2200.121] (n=1) | 2194.977 [2194.977, 2194.977] (n=1) |
