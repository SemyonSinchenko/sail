# All PageRank and WCC methods

Cells show median [minimum, maximum] for passed trials only; n is the available sample count for that metric. Counts retain every outcome.

RSS/PSS are sampled execution-phase process totals. Cgroup peak is the lifetime peak through result delivery, before verification. Memory is MiB.


## native-cap / sparse-128 / process-cluster / pagerank

| Path | Variant | Outcomes | Seconds | PSS MiB | RSS MiB | Cgroup MiB |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| Banda | optimized | nonconverged: 1 | unavailable | unavailable | unavailable | unavailable |

## native-cap / sparse-128 / process-cluster / wcc

| Path | Variant | Outcomes | Seconds | PSS MiB | RSS MiB | Cgroup MiB |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| Banda | optimized | nonconverged: 1 | unavailable | unavailable | unavailable | unavailable |

## native-large / sparse-1000000 / process-cluster / pagerank

| Path | Variant | Outcomes | Seconds | PSS MiB | RSS MiB | Cgroup MiB |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| Banda | optimized | passed: 1 | 12.069 [12.069, 12.069] (n=1) | 1996.132 [1996.132, 1996.132] (n=1) | 2121.809 [2121.809, 2121.809] (n=1) | 1963.785 [1963.785, 1963.785] (n=1) |
| Banda | reference | passed: 1 | 7.260 [7.260, 7.260] (n=1) | 1788.189 [1788.189, 1788.189] (n=1) | 1913.039 [1913.039, 1913.039] (n=1) | 1802.801 [1802.801, 1802.801] (n=1) |

## native-large / sparse-1000000 / process-cluster / wcc

| Path | Variant | Outcomes | Seconds | PSS MiB | RSS MiB | Cgroup MiB |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| Banda | optimized | passed: 1 | 8.251 [8.251, 8.251] (n=1) | 1921.475 [1921.475, 1921.475] (n=1) | 2047.914 [2047.914, 2047.914] (n=1) | 1878.082 [1878.082, 1878.082] (n=1) |
| Banda | reference | passed: 1 | 6.724 [6.724, 6.724] (n=1) | 1722.936 [1722.936, 1722.936] (n=1) | 1846.656 [1846.656, 1846.656] (n=1) | 1680.551 [1680.551, 1680.551] (n=1) |

## qualification / sparse-100000 / process-cluster / pagerank

| Path | Variant | Outcomes | Seconds | PSS MiB | RSS MiB | Cgroup MiB |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| Grenada | optimized | passed: 1 | 16.468 [16.468, 16.468] (n=1) | 2719.346 [2719.346, 2719.346] (n=1) | 2860.762 [2860.762, 2860.762] (n=1) | 2870.492 [2870.492, 2870.492] (n=1) |
| Grenada | reference | passed: 1 | 12.001 [12.001, 12.001] (n=1) | 2150.615 [2150.615, 2150.615] (n=1) | 2288.547 [2288.547, 2288.547] (n=1) | 2205.730 [2205.730, 2205.730] (n=1) |
| Banda | optimized | passed: 1 | 1.390 [1.390, 1.390] (n=1) | 769.588 [769.588, 769.588] (n=1) | 895.781 [895.781, 895.781] (n=1) | 684.879 [684.879, 684.879] (n=1) |
| Banda | reference | passed: 1 | 0.897 [0.897, 0.897] (n=1) | 739.025 [739.025, 739.025] (n=1) | 864.590 [864.590, 864.590] (n=1) | 661.629 [661.629, 661.629] (n=1) |
| Pecan | optimized | passed: 1 | 16.438 [16.438, 16.438] (n=1) | 2731.394 [2731.394, 2731.394] (n=1) | 2869.938 [2869.938, 2869.938] (n=1) | 2882.332 [2882.332, 2882.332] (n=1) |
| Pecan | reference | passed: 1 | 11.798 [11.798, 11.798] (n=1) | 2291.128 [2291.128, 2291.128] (n=1) | 2428.383 [2428.383, 2428.383] (n=1) | 2392.598 [2392.598, 2392.598] (n=1) |

## qualification / sparse-100000 / process-cluster / wcc

| Path | Variant | Outcomes | Seconds | PSS MiB | RSS MiB | Cgroup MiB |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| Grenada | optimized | passed: 1 | 3.692 [3.692, 3.692] (n=1) | 1364.151 [1364.151, 1364.151] (n=1) | 1500.809 [1500.809, 1500.809] (n=1) | 1267.848 [1267.848, 1267.848] (n=1) |
| Grenada | reference | passed: 1 | 1.357 [1.357, 1.357] (n=1) | 1357.456 [1357.456, 1357.456] (n=1) | 1495.527 [1495.527, 1495.527] (n=1) | 1257.875 [1257.875, 1257.875] (n=1) |
| Banda | optimized | passed: 1 | 0.852 [0.852, 0.852] (n=1) | 723.257 [723.257, 723.257] (n=1) | 849.570 [849.570, 849.570] (n=1) | 630.254 [630.254, 630.254] (n=1) |
| Banda | reference | passed: 1 | 0.667 [0.667, 0.667] (n=1) | 760.338 [760.338, 760.338] (n=1) | 883.215 [883.215, 883.215] (n=1) | 623.715 [623.715, 623.715] (n=1) |
| Pecan | optimized | passed: 1 | 3.681 [3.681, 3.681] (n=1) | 1359.393 [1359.393, 1359.393] (n=1) | 1496.312 [1496.312, 1496.312] (n=1) | 1282.430 [1282.430, 1282.430] (n=1) |
| Pecan | reference | passed: 1 | 1.362 [1.362, 1.362] (n=1) | 1351.796 [1351.796, 1351.796] (n=1) | 1485.949 [1485.949, 1485.949] (n=1) | 1251.496 [1251.496, 1251.496] (n=1) |

## relational-large / sparse-1000000 / process-cluster / wcc

| Path | Variant | Outcomes | Seconds | PSS MiB | RSS MiB | Cgroup MiB |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| Grenada | optimized | passed: 1 | 9.283 [9.283, 9.283] (n=1) | 1656.588 [1656.588, 1656.588] (n=1) | 1788.172 [1788.172, 1788.172] (n=1) | 1788.965 [1788.965, 1788.965] (n=1) |
| Pecan | optimized | passed: 1 | 9.201 [9.201, 9.201] (n=1) | 1645.096 [1645.096, 1645.096] (n=1) | 1780.270 [1780.270, 1780.270] (n=1) | 1779.254 [1779.254, 1779.254] (n=1) |
