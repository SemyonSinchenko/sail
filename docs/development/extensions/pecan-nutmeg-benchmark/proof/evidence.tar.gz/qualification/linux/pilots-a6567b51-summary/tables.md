# All PageRank and WCC methods

Cells show median [minimum, maximum] for passed trials only; n is the available sample count for that metric. Counts retain every outcome.

RSS/PSS are sampled execution-phase process totals. Cgroup peak is the lifetime peak through result delivery, before verification. Memory is MiB.


## pagerank-cap / sparse-128 / process-cluster / pagerank

| Path | Variant | Outcomes | Seconds | PSS MiB | RSS MiB | Cgroup MiB |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| Banda | optimized | nonconverged: 1 | unavailable | unavailable | unavailable | unavailable |

## qualification / sparse-128 / process-cluster / pagerank

| Path | Variant | Outcomes | Seconds | PSS MiB | RSS MiB | Cgroup MiB |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| Grenada | optimized | passed: 1 | 3.426 [3.426, 3.426] (n=1) | 804.952 [804.952, 804.952] (n=1) | 942.977 [942.977, 942.977] (n=1) | 702.918 [702.918, 702.918] (n=1) |
| Grenada | reference | passed: 1 | 2.514 [2.514, 2.514] (n=1) | 789.146 [789.146, 789.146] (n=1) | 926.477 [926.477, 926.477] (n=1) | 673.297 [673.297, 673.297] (n=1) |
| Banda | optimized | passed: 1 | 0.045 [0.045, 0.045] (n=1) | 434.696 [434.696, 434.696] (n=1) | 549.250 [549.250, 549.250] (n=1) | 324.312 [324.312, 324.312] (n=1) |
| Banda | reference | passed: 1 | 0.044 [0.044, 0.044] (n=1) | 392.904 [392.904, 392.904] (n=1) | 499.902 [499.902, 499.902] (n=1) | 310.215 [310.215, 310.215] (n=1) |
| Pecan | optimized | passed: 1 | 3.427 [3.427, 3.427] (n=1) | 814.357 [814.357, 814.357] (n=1) | 951.789 [951.789, 951.789] (n=1) | 693.301 [693.301, 693.301] (n=1) |
| Pecan | reference | passed: 1 | 2.500 [2.500, 2.500] (n=1) | 785.675 [785.675, 785.675] (n=1) | 926.891 [926.891, 926.891] (n=1) | 665.812 [665.812, 665.812] (n=1) |

## qualification / sparse-128 / process-cluster / wcc

| Path | Variant | Outcomes | Seconds | PSS MiB | RSS MiB | Cgroup MiB |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| Grenada | optimized | passed: 1 | 1.510 [1.510, 1.510] (n=1) | 770.705 [770.705, 770.705] (n=1) | 907.488 [907.488, 907.488] (n=1) | 612.930 [612.930, 612.930] (n=1) |
| Grenada | reference | passed: 1 | 0.631 [0.631, 0.631] (n=1) | 642.823 [642.823, 642.823] (n=1) | 776.109 [776.109, 776.109] (n=1) | 514.855 [514.855, 514.855] (n=1) |
| Banda | optimized | passed: 1 | 0.048 [0.048, 0.048] (n=1) | 421.900 [421.900, 421.900] (n=1) | 534.984 [534.984, 534.984] (n=1) | 299.332 [299.332, 299.332] (n=1) |
| Banda | reference | passed: 1 | 0.046 [0.046, 0.046] (n=1) | 419.652 [419.652, 419.652] (n=1) | 533.215 [533.215, 533.215] (n=1) | 313.691 [313.691, 313.691] (n=1) |
| Pecan | optimized | passed: 1 | 1.480 [1.480, 1.480] (n=1) | 754.007 [754.007, 754.007] (n=1) | 888.828 [888.828, 888.828] (n=1) | 607.531 [607.531, 607.531] (n=1) |
| Pecan | reference | passed: 1 | 0.583 [0.583, 0.583] (n=1) | 635.889 [635.889, 635.889] (n=1) | 769.574 [769.574, 769.574] (n=1) | 482.227 [482.227, 482.227] (n=1) |

## wcc-cap / chain-512 / process-cluster / wcc

| Path | Variant | Outcomes | Seconds | PSS MiB | RSS MiB | Cgroup MiB |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| Banda | optimized | nonconverged: 1 | unavailable | unavailable | unavailable | unavailable |
