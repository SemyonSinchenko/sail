# Independent control evidence audit

Recorded 2026-09-27T20:44:20.008698+00:00. Audit verdict: **passed**.

14 planned cells; outcomes: 12 passed, 2 nonconverged.

Original trial outcomes are retained unchanged. An audit failure is a separate evidence-integrity finding, not a rewritten benchmark outcome.

## Identity and coverage

- harness_source_sha: `a6567b511a2ef1d99688f644134effb8461594f8`.
- runtime_source_sha: `70b0d1cab2cab945d4dbaf6842ee0e38c8aa1822`.
- native_source_sha: `4e6100f0320fb952e9926b867193ec1768edfcda`.

Performed 15 inventory checks across 15 unique files; reconstructed 541 raw memory samples.
Raw correctness coverage: 13 raw_full_vector, 1 receipt_only.

Raw-vector checks read actual Parquet and independently recompute PageRank fixed-point residuals/full-vector errors and WCC components from input edges. Receipt-only checks validate recorded results and hashes; they are not a new calculation from omitted graph rows.

## Findings

No audit integrity defects found.

## Coverage limits

- `matrix`: no safe export manifest; verifying receipt and dataset inventories directly
- `pagerank-cap-r1-sparse-128-nutmeg-native-pagerank-optimized`: raw result exists without a receipt inventory
- `matrix`: no independent post-stop cleanup snapshot; error-cell cleanup coverage may be limited

## Every planned outcome

| Sequence | Cell | Outcome | Correctness audit | Execution samples |
| --- | --- | --- | --- | ---: |
| 1 | `qualification-r1-sparse-128-nutmeg-datafusion-wcc-reference` | passed | raw_full_vector | 9 |
| 2 | `qualification-r1-sparse-128-nutmeg-native-wcc-reference` | passed | raw_full_vector | 1 |
| 3 | `qualification-r1-sparse-128-nutmeg-native-pagerank-reference` | passed | raw_full_vector | 1 |
| 4 | `qualification-r1-sparse-128-pecan-wcc-reference` | passed | raw_full_vector | 8 |
| 5 | `qualification-r1-sparse-128-nutmeg-datafusion-pagerank-optimized` | passed | raw_full_vector | 47 |
| 6 | `qualification-r1-sparse-128-nutmeg-datafusion-wcc-optimized` | passed | raw_full_vector | 20 |
| 7 | `qualification-r1-sparse-128-pecan-pagerank-reference` | passed | raw_full_vector | 35 |
| 8 | `qualification-r1-sparse-128-nutmeg-datafusion-pagerank-reference` | passed | raw_full_vector | 34 |
| 9 | `qualification-r1-sparse-128-pecan-pagerank-optimized` | passed | raw_full_vector | 47 |
| 10 | `qualification-r1-sparse-128-nutmeg-native-pagerank-optimized` | passed | raw_full_vector | 1 |
| 11 | `qualification-r1-sparse-128-nutmeg-native-wcc-optimized` | passed | raw_full_vector | 1 |
| 12 | `qualification-r1-sparse-128-pecan-wcc-optimized` | passed | raw_full_vector | 21 |
| 13 | `wcc-cap-r1-chain-512-nutmeg-native-wcc-optimized` | nonconverged | receipt_only | 1 |
| 14 | `pagerank-cap-r1-sparse-128-nutmeg-native-pagerank-optimized` | nonconverged | raw_full_vector | 1 |

## Sampling and contraction detail

| Path | Algorithm | Variant | Execution sample count: min / median / max |
| --- | --- | --- | --- |
| nutmeg-datafusion | pagerank | optimized | 47 / 47 / 47 |
| nutmeg-datafusion | pagerank | reference | 34 / 34 / 34 |
| nutmeg-datafusion | wcc | optimized | 20 / 20 / 20 |
| nutmeg-datafusion | wcc | reference | 9 / 9 / 9 |
| nutmeg-native | pagerank | optimized | 1 / 1.0 / 1 |
| nutmeg-native | pagerank | reference | 1 / 1 / 1 |
| nutmeg-native | wcc | optimized | 1 / 1.0 / 1 |
| nutmeg-native | wcc | reference | 1 / 1 / 1 |
| pecan | pagerank | optimized | 47 / 47 / 47 |
| pecan | pagerank | reference | 35 / 35 / 35 |
| pecan | wcc | optimized | 21 / 21 / 21 |
| pecan | wcc | reference | 8 / 8 / 8 |

Recorded whole-VM steal fractions: `{"observations": 14, "minimum": 0.0, "median": 0.0, "maximum": 0.0}`.

- `sparse-128`: 4 identical contraction rounds across 3 successful cells, excluding the first raw-edge input count.

Native advanced widths are recorded per dataset in the JSON. Native reference actual widths are not exported by these kernels and must not be inferred from requested concurrency.

Post-stop cleanup snapshot: `null`.


RSS/PSS are sampled execution-phase totals; short peaks may be missed. RSS can double-count shared mappings; PSS apportions them. Cgroup peaks include cache and lifetime activity and are not interchangeable with PSS or native admission accounting. No elapsed-time or memory ranking is inferred by this audit.

Cross-path WCC trace comparisons check coefficients, active vertices and contracted edges; only the first raw-edge input count may differ for fused plans. Floating PageRank frontier traces are recorded without requiring equality across different reduction orders.
