# Independent control evidence audit

Recorded 2026-09-27T20:19:41.351265+00:00. Audit verdict: **passed**.

150 planned cells; outcomes: 16 passed, 4 error, 130 not_run.

Original trial outcomes are retained unchanged. An audit failure is a separate evidence-integrity finding, not a rewritten benchmark outcome.

## Identity and coverage

- harness_source_sha: `a6567b511a2ef1d99688f644134effb8461594f8`.
- runtime_source_sha: `70b0d1cab2cab945d4dbaf6842ee0e38c8aa1822`.
- native_source_sha: `4e6100f0320fb952e9926b867193ec1768edfcda`.

Performed 142 inventory checks across 142 unique files; reconstructed 3659 raw memory samples.
Raw correctness coverage: 20 receipt_only, 130 no_receipt.

Raw-vector checks read actual Parquet and independently recompute PageRank fixed-point residuals/full-vector errors and WCC components from input edges. Receipt-only checks validate recorded results and hashes; they are not a new calculation from omitted graph rows.

## Findings

No audit integrity defects found.

## Every planned outcome

| Sequence | Cell | Outcome | Correctness audit | Execution samples |
| --- | --- | --- | --- | ---: |
| 1 | `distributed-r1-sparse-100000-nutmeg-datafusion-wcc-reference` | passed | receipt_only | 18 |
| 2 | `distributed-r1-sparse-1000000-nutmeg-native-pagerank-optimized` | error | receipt_only | 14 |
| 3 | `distributed-r1-sparse-10000-nutmeg-native-wcc-reference` | passed | receipt_only | 2 |
| 4 | `distributed-r1-sparse-10000-pecan-pagerank-optimized` | passed | receipt_only | 146 |
| 5 | `distributed-r1-sparse-1000000-nutmeg-datafusion-pagerank-reference` | passed | receipt_only | 510 |
| 6 | `distributed-r1-sparse-1000000-nutmeg-datafusion-pagerank-optimized` | passed | receipt_only | 640 |
| 7 | `distributed-r1-sparse-100000-nutmeg-native-pagerank-reference` | passed | receipt_only | 13 |
| 8 | `distributed-r1-sparse-100000-nutmeg-datafusion-wcc-optimized` | error | receipt_only | 8 |
| 9 | `distributed-r1-sparse-100000-nutmeg-native-pagerank-optimized` | passed | receipt_only | 20 |
| 10 | `distributed-r1-sparse-1000000-pecan-pagerank-optimized` | passed | receipt_only | 637 |
| 11 | `distributed-r1-sparse-100000-nutmeg-native-wcc-optimized` | passed | receipt_only | 13 |
| 12 | `distributed-r1-sparse-10000-nutmeg-datafusion-wcc-reference` | passed | receipt_only | 12 |
| 13 | `distributed-r1-sparse-1000000-nutmeg-native-pagerank-reference` | error | receipt_only | 14 |
| 14 | `distributed-r1-sparse-100000-nutmeg-native-wcc-reference` | passed | receipt_only | 9 |
| 15 | `distributed-r1-sparse-100000-pecan-pagerank-optimized` | passed | receipt_only | 204 |
| 16 | `distributed-r1-sparse-1000000-pecan-wcc-optimized` | error | receipt_only | 27 |
| 17 | `distributed-r1-sparse-1000000-nutmeg-datafusion-wcc-reference` | passed | receipt_only | 88 |
| 18 | `distributed-r1-sparse-10000-pecan-pagerank-reference` | passed | receipt_only | 106 |
| 19 | `distributed-r1-sparse-10000-nutmeg-datafusion-pagerank-reference` | passed | receipt_only | 105 |
| 20 | `distributed-r1-sparse-1000000-pecan-pagerank-reference` | passed | receipt_only | 557 |
| 21 | `distributed-r1-sparse-100000-pecan-wcc-reference` | not_run | no receipt | unavailable |
| 22 | `distributed-r1-sparse-1000000-pecan-wcc-reference` | not_run | no receipt | unavailable |
| 23 | `distributed-r1-sparse-10000-nutmeg-native-pagerank-optimized` | not_run | no receipt | unavailable |
| 24 | `distributed-r1-sparse-1000000-nutmeg-native-wcc-reference` | not_run | no receipt | unavailable |
| 25 | `distributed-r1-sparse-10000-nutmeg-datafusion-pagerank-optimized` | not_run | no receipt | unavailable |
| 26 | `distributed-r1-sparse-10000-pecan-wcc-optimized` | not_run | no receipt | unavailable |
| 27 | `distributed-r1-sparse-100000-nutmeg-datafusion-pagerank-optimized` | not_run | no receipt | unavailable |
| 28 | `distributed-r1-sparse-10000-nutmeg-datafusion-wcc-optimized` | not_run | no receipt | unavailable |
| 29 | `distributed-r1-sparse-100000-pecan-pagerank-reference` | not_run | no receipt | unavailable |
| 30 | `distributed-r1-sparse-1000000-nutmeg-datafusion-wcc-optimized` | not_run | no receipt | unavailable |
| 31 | `distributed-r1-sparse-10000-pecan-wcc-reference` | not_run | no receipt | unavailable |
| 32 | `distributed-r1-sparse-10000-nutmeg-native-pagerank-reference` | not_run | no receipt | unavailable |
| 33 | `distributed-r1-sparse-10000-nutmeg-native-wcc-optimized` | not_run | no receipt | unavailable |
| 34 | `distributed-r1-sparse-100000-nutmeg-datafusion-pagerank-reference` | not_run | no receipt | unavailable |
| 35 | `distributed-r1-sparse-1000000-nutmeg-native-wcc-optimized` | not_run | no receipt | unavailable |
| 36 | `distributed-r1-sparse-100000-pecan-wcc-optimized` | not_run | no receipt | unavailable |
| 37 | `distributed-r2-sparse-100000-nutmeg-datafusion-wcc-optimized` | not_run | no receipt | unavailable |
| 38 | `distributed-r2-sparse-10000-nutmeg-native-wcc-reference` | not_run | no receipt | unavailable |
| 39 | `distributed-r2-sparse-10000-nutmeg-datafusion-wcc-optimized` | not_run | no receipt | unavailable |
| 40 | `distributed-r2-sparse-100000-nutmeg-datafusion-pagerank-optimized` | not_run | no receipt | unavailable |
| 41 | `distributed-r2-sparse-1000000-nutmeg-datafusion-pagerank-optimized` | not_run | no receipt | unavailable |
| 42 | `distributed-r2-sparse-100000-pecan-wcc-reference` | not_run | no receipt | unavailable |
| 43 | `distributed-r2-sparse-100000-nutmeg-native-pagerank-reference` | not_run | no receipt | unavailable |
| 44 | `distributed-r2-sparse-1000000-nutmeg-native-pagerank-reference` | not_run | no receipt | unavailable |
| 45 | `distributed-r2-sparse-1000000-nutmeg-datafusion-wcc-reference` | not_run | no receipt | unavailable |
| 46 | `distributed-r2-sparse-1000000-pecan-pagerank-optimized` | not_run | no receipt | unavailable |
| 47 | `distributed-r2-sparse-10000-nutmeg-datafusion-pagerank-optimized` | not_run | no receipt | unavailable |
| 48 | `distributed-r2-sparse-1000000-nutmeg-native-wcc-optimized` | not_run | no receipt | unavailable |
| 49 | `distributed-r2-sparse-100000-pecan-pagerank-optimized` | not_run | no receipt | unavailable |
| 50 | `distributed-r2-sparse-1000000-nutmeg-native-pagerank-optimized` | not_run | no receipt | unavailable |
| 51 | `distributed-r2-sparse-100000-nutmeg-datafusion-pagerank-reference` | not_run | no receipt | unavailable |
| 52 | `distributed-r2-sparse-1000000-nutmeg-datafusion-pagerank-reference` | not_run | no receipt | unavailable |
| 53 | `distributed-r2-sparse-100000-nutmeg-native-pagerank-optimized` | not_run | no receipt | unavailable |
| 54 | `distributed-r2-sparse-1000000-pecan-pagerank-reference` | not_run | no receipt | unavailable |
| 55 | `distributed-r2-sparse-100000-nutmeg-native-wcc-reference` | not_run | no receipt | unavailable |
| 56 | `distributed-r2-sparse-1000000-pecan-wcc-reference` | not_run | no receipt | unavailable |
| 57 | `distributed-r2-sparse-100000-pecan-wcc-optimized` | not_run | no receipt | unavailable |
| 58 | `distributed-r2-sparse-10000-nutmeg-native-pagerank-optimized` | not_run | no receipt | unavailable |
| 59 | `distributed-r2-sparse-10000-pecan-pagerank-reference` | not_run | no receipt | unavailable |
| 60 | `distributed-r2-sparse-10000-nutmeg-datafusion-wcc-reference` | not_run | no receipt | unavailable |
| 61 | `distributed-r2-sparse-100000-nutmeg-native-wcc-optimized` | not_run | no receipt | unavailable |
| 62 | `distributed-r2-sparse-10000-nutmeg-datafusion-pagerank-reference` | not_run | no receipt | unavailable |
| 63 | `distributed-r2-sparse-10000-nutmeg-native-pagerank-reference` | not_run | no receipt | unavailable |
| 64 | `distributed-r2-sparse-10000-pecan-pagerank-optimized` | not_run | no receipt | unavailable |
| 65 | `distributed-r2-sparse-100000-pecan-pagerank-reference` | not_run | no receipt | unavailable |
| 66 | `distributed-r2-sparse-1000000-nutmeg-native-wcc-reference` | not_run | no receipt | unavailable |
| 67 | `distributed-r2-sparse-100000-nutmeg-datafusion-wcc-reference` | not_run | no receipt | unavailable |
| 68 | `distributed-r2-sparse-10000-pecan-wcc-reference` | not_run | no receipt | unavailable |
| 69 | `distributed-r2-sparse-10000-pecan-wcc-optimized` | not_run | no receipt | unavailable |
| 70 | `distributed-r2-sparse-1000000-nutmeg-datafusion-wcc-optimized` | not_run | no receipt | unavailable |
| 71 | `distributed-r2-sparse-1000000-pecan-wcc-optimized` | not_run | no receipt | unavailable |
| 72 | `distributed-r2-sparse-10000-nutmeg-native-wcc-optimized` | not_run | no receipt | unavailable |
| 73 | `distributed-r3-sparse-100000-nutmeg-native-pagerank-optimized` | not_run | no receipt | unavailable |
| 74 | `distributed-r3-sparse-100000-nutmeg-datafusion-wcc-reference` | not_run | no receipt | unavailable |
| 75 | `distributed-r3-sparse-1000000-nutmeg-datafusion-pagerank-reference` | not_run | no receipt | unavailable |
| 76 | `distributed-r3-sparse-100000-nutmeg-datafusion-wcc-optimized` | not_run | no receipt | unavailable |
| 77 | `distributed-r3-sparse-1000000-nutmeg-datafusion-wcc-optimized` | not_run | no receipt | unavailable |
| 78 | `distributed-r3-sparse-1000000-nutmeg-native-wcc-reference` | not_run | no receipt | unavailable |
| 79 | `distributed-r3-sparse-1000000-nutmeg-datafusion-pagerank-optimized` | not_run | no receipt | unavailable |
| 80 | `distributed-r3-sparse-10000-nutmeg-datafusion-wcc-reference` | not_run | no receipt | unavailable |
| 81 | `distributed-r3-sparse-10000-pecan-pagerank-optimized` | not_run | no receipt | unavailable |
| 82 | `distributed-r3-sparse-100000-pecan-pagerank-optimized` | not_run | no receipt | unavailable |
| 83 | `distributed-r3-sparse-10000-nutmeg-datafusion-pagerank-optimized` | not_run | no receipt | unavailable |
| 84 | `distributed-r3-sparse-100000-pecan-wcc-reference` | not_run | no receipt | unavailable |
| 85 | `distributed-r3-sparse-100000-nutmeg-datafusion-pagerank-optimized` | not_run | no receipt | unavailable |
| 86 | `distributed-r3-sparse-1000000-pecan-wcc-reference` | not_run | no receipt | unavailable |
| 87 | `distributed-r3-sparse-1000000-nutmeg-native-pagerank-reference` | not_run | no receipt | unavailable |
| 88 | `distributed-r3-sparse-10000-pecan-wcc-optimized` | not_run | no receipt | unavailable |
| 89 | `distributed-r3-sparse-10000-pecan-wcc-reference` | not_run | no receipt | unavailable |
| 90 | `distributed-r3-sparse-1000000-nutmeg-datafusion-wcc-reference` | not_run | no receipt | unavailable |
| 91 | `distributed-r3-sparse-100000-nutmeg-native-wcc-reference` | not_run | no receipt | unavailable |
| 92 | `distributed-r3-sparse-10000-nutmeg-datafusion-wcc-optimized` | not_run | no receipt | unavailable |
| 93 | `distributed-r3-sparse-10000-nutmeg-native-pagerank-optimized` | not_run | no receipt | unavailable |
| 94 | `distributed-r3-sparse-1000000-pecan-wcc-optimized` | not_run | no receipt | unavailable |
| 95 | `distributed-r3-sparse-10000-nutmeg-datafusion-pagerank-reference` | not_run | no receipt | unavailable |
| 96 | `distributed-r3-sparse-1000000-pecan-pagerank-optimized` | not_run | no receipt | unavailable |
| 97 | `distributed-r3-sparse-100000-nutmeg-datafusion-pagerank-reference` | not_run | no receipt | unavailable |
| 98 | `distributed-r3-sparse-100000-pecan-wcc-optimized` | not_run | no receipt | unavailable |
| 99 | `distributed-r3-sparse-1000000-nutmeg-native-wcc-optimized` | not_run | no receipt | unavailable |
| 100 | `distributed-r3-sparse-10000-nutmeg-native-wcc-reference` | not_run | no receipt | unavailable |
| 101 | `distributed-r3-sparse-1000000-pecan-pagerank-reference` | not_run | no receipt | unavailable |
| 102 | `distributed-r3-sparse-100000-nutmeg-native-pagerank-reference` | not_run | no receipt | unavailable |
| 103 | `distributed-r3-sparse-10000-pecan-pagerank-reference` | not_run | no receipt | unavailable |
| 104 | `distributed-r3-sparse-10000-nutmeg-native-wcc-optimized` | not_run | no receipt | unavailable |
| 105 | `distributed-r3-sparse-1000000-nutmeg-native-pagerank-optimized` | not_run | no receipt | unavailable |
| 106 | `distributed-r3-sparse-100000-pecan-pagerank-reference` | not_run | no receipt | unavailable |
| 107 | `distributed-r3-sparse-10000-nutmeg-native-pagerank-reference` | not_run | no receipt | unavailable |
| 108 | `distributed-r3-sparse-100000-nutmeg-native-wcc-optimized` | not_run | no receipt | unavailable |
| 109 | `local-r1-sparse-100000-nutmeg-datafusion-pagerank-reference` | not_run | no receipt | unavailable |
| 110 | `local-r1-sparse-100000-pecan-wcc-reference` | not_run | no receipt | unavailable |
| 111 | `local-r1-sparse-100000-nutmeg-datafusion-wcc-reference` | not_run | no receipt | unavailable |
| 112 | `local-r1-sparse-100000-pecan-pagerank-reference` | not_run | no receipt | unavailable |
| 113 | `local-r1-sparse-100000-pecan-pagerank-optimized` | not_run | no receipt | unavailable |
| 114 | `local-r1-sparse-100000-nutmeg-native-pagerank-reference` | not_run | no receipt | unavailable |
| 115 | `local-r1-sparse-100000-nutmeg-native-wcc-optimized` | not_run | no receipt | unavailable |
| 116 | `local-r1-sparse-100000-pecan-wcc-optimized` | not_run | no receipt | unavailable |
| 117 | `local-r1-sparse-100000-nutmeg-datafusion-pagerank-optimized` | not_run | no receipt | unavailable |
| 118 | `local-r1-sparse-100000-nutmeg-datafusion-wcc-optimized` | not_run | no receipt | unavailable |
| 119 | `local-r1-sparse-100000-nutmeg-native-pagerank-optimized` | not_run | no receipt | unavailable |
| 120 | `local-r1-sparse-100000-nutmeg-native-wcc-reference` | not_run | no receipt | unavailable |
| 121 | `local-r2-sparse-100000-nutmeg-native-pagerank-reference` | not_run | no receipt | unavailable |
| 122 | `local-r2-sparse-100000-nutmeg-datafusion-pagerank-optimized` | not_run | no receipt | unavailable |
| 123 | `local-r2-sparse-100000-nutmeg-native-wcc-reference` | not_run | no receipt | unavailable |
| 124 | `local-r2-sparse-100000-nutmeg-datafusion-pagerank-reference` | not_run | no receipt | unavailable |
| 125 | `local-r2-sparse-100000-nutmeg-datafusion-wcc-optimized` | not_run | no receipt | unavailable |
| 126 | `local-r2-sparse-100000-pecan-wcc-optimized` | not_run | no receipt | unavailable |
| 127 | `local-r2-sparse-100000-nutmeg-datafusion-wcc-reference` | not_run | no receipt | unavailable |
| 128 | `local-r2-sparse-100000-pecan-pagerank-reference` | not_run | no receipt | unavailable |
| 129 | `local-r2-sparse-100000-nutmeg-native-pagerank-optimized` | not_run | no receipt | unavailable |
| 130 | `local-r2-sparse-100000-pecan-pagerank-optimized` | not_run | no receipt | unavailable |
| 131 | `local-r2-sparse-100000-pecan-wcc-reference` | not_run | no receipt | unavailable |
| 132 | `local-r2-sparse-100000-nutmeg-native-wcc-optimized` | not_run | no receipt | unavailable |
| 133 | `local-r3-sparse-100000-nutmeg-native-wcc-reference` | not_run | no receipt | unavailable |
| 134 | `local-r3-sparse-100000-nutmeg-native-pagerank-reference` | not_run | no receipt | unavailable |
| 135 | `local-r3-sparse-100000-pecan-pagerank-reference` | not_run | no receipt | unavailable |
| 136 | `local-r3-sparse-100000-nutmeg-datafusion-pagerank-optimized` | not_run | no receipt | unavailable |
| 137 | `local-r3-sparse-100000-pecan-pagerank-optimized` | not_run | no receipt | unavailable |
| 138 | `local-r3-sparse-100000-pecan-wcc-optimized` | not_run | no receipt | unavailable |
| 139 | `local-r3-sparse-100000-pecan-wcc-reference` | not_run | no receipt | unavailable |
| 140 | `local-r3-sparse-100000-nutmeg-native-pagerank-optimized` | not_run | no receipt | unavailable |
| 141 | `local-r3-sparse-100000-nutmeg-datafusion-pagerank-reference` | not_run | no receipt | unavailable |
| 142 | `local-r3-sparse-100000-nutmeg-datafusion-wcc-optimized` | not_run | no receipt | unavailable |
| 143 | `local-r3-sparse-100000-nutmeg-native-wcc-optimized` | not_run | no receipt | unavailable |
| 144 | `local-r3-sparse-100000-nutmeg-datafusion-wcc-reference` | not_run | no receipt | unavailable |
| 145 | `chain-diagnostic-r1-chain-512-nutmeg-datafusion-wcc-reference` | not_run | no receipt | unavailable |
| 146 | `chain-diagnostic-r1-chain-512-pecan-wcc-optimized` | not_run | no receipt | unavailable |
| 147 | `chain-diagnostic-r1-chain-512-nutmeg-datafusion-wcc-optimized` | not_run | no receipt | unavailable |
| 148 | `chain-diagnostic-r1-chain-512-nutmeg-native-wcc-reference` | not_run | no receipt | unavailable |
| 149 | `chain-diagnostic-r1-chain-512-nutmeg-native-wcc-optimized` | not_run | no receipt | unavailable |
| 150 | `chain-diagnostic-r1-chain-512-pecan-wcc-reference` | not_run | no receipt | unavailable |

RSS/PSS are sampled execution-phase totals; short peaks may be missed. RSS can double-count shared mappings; PSS apportions them. Cgroup peaks include cache and lifetime activity and are not interchangeable with PSS or native admission accounting. No elapsed-time or memory ranking is inferred by this audit.

Cross-path WCC trace comparisons check coefficients, active vertices and contracted edges; only the first raw-edge input count may differ for fused plans. Floating PageRank frontier traces are recorded without requiring equality across different reduction orders.
