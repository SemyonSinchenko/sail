from pathlib import Path
from collections import defaultdict
from datetime import datetime,timezone
from statistics import median
import hashlib,json,re,shutil
root=Path('/Users/alexy/src/sail-extensions-poc');target=root/'target/pecan-benchmark'
report=target/'report-draft.md';snapshot=target/'report-primary-reviewed-input.md';shutil.copy2(report,snapshot);text=snapshot.read_text()
evidence=root/'target/extensions-pecan-benchmark/export/export-matrix-3c1fd28c'
summary=json.loads((root/'target/extensions-pecan-benchmark/export/matrix-3c1fd28c-summary/summary.json').read_text())
by_group=defaultdict(list)
for path in (evidence/'cells').glob('*/summary.json'):
 cell=json.loads(path.read_text());receipt=json.loads((path.parent/'artifacts/receipt.json').read_text())
 by_group[(cell['suite'],cell['dataset'],cell['algorithm'],cell['engine'],cell['variant'])].append((cell,receipt))
issues=[];checked=[]
names={'Pecan':'pecan','Banda':'nutmeg-native','Grenada':'nutmeg-datafusion'}
variants={'reference':'reference','advanced':'optimized'}
def check(condition,message):
 if not condition:issues.append(message)
def rows_after(header):
 lines=text.splitlines();index=lines.index(header)+2;result=[]
 while index<len(lines) and lines[index].startswith('|'):
  result.append([value.strip() for value in lines[index].strip('|').split('|')]);index+=1
 return result
header='| Algorithm | Path | Method | Passes | Seconds | PSS MiB | RSS MiB | Cgroup MiB |'
rows=rows_after(header);check(len(rows)==12,'primary table must retain all12 path/method rows')
for row in rows:
 algorithm,path,method,passes,*observed=row;key=('distributed','sparse-100000',algorithm.lower(),names[path],variants[method]);trials=by_group[key]
 check(passes==f'{sum(c["outcome"]=="passed" for c,r in trials)}/{len(trials)}',f'pass count differs:{key}')
 for metric,value in zip(('seconds','pss_bytes','rss_bytes','cgroup'),observed):
  numbers=[]
  for cell,receipt in trials:
   check(cell['outcome']=='passed',f'unfinished row enters primary table:{key}')
   number=receipt['end_to_end_seconds'] if metric=='seconds' else float(receipt['cgroup_execution_after']['memory.peak'])/2**20 if metric=='cgroup' else receipt['memory']['phase_peaks']['execute'][metric]/2**20
   numbers.append(number)
  expected=f'{median(numbers):.2f} [{min(numbers):.2f}, {max(numbers):.2f}]'
  check(value==expected,f'{key} {metric}: got{value}, expected{expected}')
 checked.append(dict(group=key,primary_metrics=4,precision_decimals=2))
rows=rows_after('| Path | Method | Outcome | Time boundary | Seconds | PSS MiB |');check(len(rows)==6,'chain table must retain six outcomes')
for row in rows:
 path,method,outcome,boundary,seconds,pss=row;key=('chain-diagnostic','chain-512','wcc',names[path],variants[method]);[(cell,receipt)]=by_group[key]
 check(outcome==cell['outcome'],f'chain outcome differs:{key}')
 expected_time=receipt.get('end_to_end_seconds',receipt.get('elapsed_until_error_seconds'))
 check(seconds==f'{expected_time:.3f}',f'chain time differs:{key}')
 check(pss==f'{receipt["memory"]["phase_peaks"]["execute"]["pss_bytes"]/2**20:.3f}',f'chain PSS differs:{key}')
 check(boundary==('completed output' if outcome=='passed' else 'until failure/cap'),f'chain time boundary differs:{key}')
 checked.append(dict(group=key,chain_metrics=2,precision_decimals=3))
counts=rows_after('| Vertices | Directed edges | Components | Isolates | Dangling vertices |')
for row in counts:
 values=[int(v.replace(',','')) for v in row];n=values[0]
 manifest=json.loads((evidence/f'datasets/sparse-{n}/dataset/manifest.json').read_text())
 check(values==[manifest['counts'][key] for key in ('vertices','edges','components','isolates','dangling')],f'fixture counts differ:{n}')
# Iterations and message counts are checked for every mode/repeat/path, not just
# the reference rows selected for the report table.
for size,reference,delta,contractions in [(100000,57,59,9),(1000000,59,62,11)]:
 for key,trials in by_group.items():
  if key[1]!=f'sparse-{size}':continue
  for cell,receipt in trials:
   expected=reference if cell['variant']=='reference' else delta
   if cell['algorithm']=='pagerank':
    check(receipt['correctness']['min_iterations']==receipt['correctness']['max_iterations']==expected,f'PR iteration claim differs:{cell["cell_id"]}')
   elif cell['engine']!='nutmeg-native':
    check(receipt['algorithm_iterations']==(4 if cell['variant']=='reference' else contractions),f'WCC round claim differs:{cell["cell_id"]}')
for key,trials in by_group.items():
 if key[0]!='chain-diagnostic' and key[-1]=='optimized':
  old=by_group[key[:-1]+('reference',)]
  check(median(r['end_to_end_seconds'] for c,r in trials)>median(r['end_to_end_seconds'] for c,r in old),f'advanced slower median claim false:{key}')
raw=json.loads((target/'main-audit.json').read_text())
for dataset,total in [('sparse-100000',45820538),('sparse-1000000',477240350)]:
 for cell in raw['cells']:
  if cell['dataset']==dataset and cell['algorithm']=='pagerank' and cell['variant']=='optimized':
   check(cell['trace']['frontier_messages']==total,f'frontier message claim differs:{cell["cell_id"]}')
for engine,variant,pss,time in [('pecan','optimized','1,673.33','9.47'),('pecan','reference','2,258.26','8.51'),('nutmeg-native','optimized','1,918.85','8.44'),('nutmeg-native','reference','1,762.25','6.81')]:
 trials=by_group[('distributed','sparse-1000000','wcc',engine,variant)]
 check(f'{median(r["memory"]["phase_peaks"]["execute"]["pss_bytes"] for c,r in trials)/2**20:,.2f}'==pss,f'1m PSS claim differs:{engine}/{variant}')
 check(f'{median(r["end_to_end_seconds"] for c,r in trials):.2f}'==time,f'1m time claim differs:{engine}/{variant}')
result={'recorded_utc':datetime.now(timezone.utc).isoformat(),'reviewed_document':str(snapshot),'document_sha256':hashlib.sha256(snapshot.read_bytes()).hexdigest(),
        'primary_table_rows_checked':12,'chain_rows_checked':6,'fixture_rows_checked':3,
        'sparse_advanced_reference_median_pairs_checked':24,'numeric_issues':issues,'checked_tables':checked,
        'outcome':'passed' if not issues else 'failed'}
(target/'report-primary-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
