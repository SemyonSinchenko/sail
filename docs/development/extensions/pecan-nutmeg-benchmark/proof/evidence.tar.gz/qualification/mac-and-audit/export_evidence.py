"""Build a public proof bundle from explicitly selected task evidence roots."""
import argparse, gzip, hashlib, io, json, tarfile
from datetime import datetime, timezone
from pathlib import Path

def sha(p):
 h=hashlib.sha256()
 with p.open("rb") as f:
  for block in iter(lambda:f.read(1024*1024),b""): h.update(block)
 return h.hexdigest()

def main():
 ap=argparse.ArgumentParser()
 ap.add_argument("--selection",type=Path,required=True)
 ap.add_argument("--output",type=Path,required=True)
 args=ap.parse_args()
 selection=json.loads(args.selection.read_text())
 args.output.mkdir(parents=True,exist_ok=False)
 files=[]; omitted=[]
 for item in selection:
  root=Path(item["source"])
  assert root.exists(),root
  paths=sorted(root.rglob("*")) if root.is_dir() else [root]
  for p in paths:
   if not p.is_file(): continue
   assert not p.is_symlink(),p
   rel=(Path(item["destination"])/p.relative_to(root)) if root.is_dir() else Path(item["destination"])
   entry={"path":str(rel),"source":str(p),"bytes":p.stat().st_size,"sha256":sha(p)}
   if p.suffix in {".parquet",".so",".whl",".dylib"} or "__pycache__" in p.parts:
    omitted.append(entry)
   else: files.append(entry)
 assert len({e["path"] for e in files})==len(files)
 manifest={"generated_utc":datetime.now(timezone.utc).isoformat(),"included":files,"omitted_binary_artifacts":omitted,
  "boundary":"Original evidence bytes preserved. Result and dataset Parquet files, installed binaries and wheels omitted; hashes retained when present in selected roots. Source, generator, full validation receipts and logs accompany measurements."}
 raw=(json.dumps(manifest,indent=2)+"\n").encode()
 (args.output/"manifest.json").write_bytes(raw)
 archive=args.output/"evidence.tar.gz"
 with archive.open("wb") as out, gzip.GzipFile(fileobj=out,mode="wb",mtime=0) as gz, tarfile.open(fileobj=gz,mode="w") as tar:
  for e in files:
   p=Path(e["source"]); assert sha(p)==e["sha256"]
   info=tar.gettarinfo(str(p),arcname=e["path"]);info.uid=info.gid=0;info.uname=info.gname="";info.mtime=0
   with p.open("rb") as f: tar.addfile(info,f)
  info=tarfile.TarInfo("manifest.json");info.size=len(raw);info.mtime=0;tar.addfile(info,io.BytesIO(raw))
 with tarfile.open(archive,"r:gz") as tar:
  for e in files:
   assert hashlib.sha256(tar.extractfile(e["path"]).read()).hexdigest()==e["sha256"]
 receipt={"generated_utc":datetime.now(timezone.utc).isoformat(),"archive_sha256":sha(archive),"archive_bytes":archive.stat().st_size,
  "included_files":len(files),"omitted_files":len(omitted),"hash_verification":"passed"}
 (args.output/"bundle.json").write_text(json.dumps(receipt,indent=2)+"\n")
 print(json.dumps(receipt))
if __name__=="__main__":main()
