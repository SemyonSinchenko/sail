from datetime import datetime, timezone
import hashlib, importlib.util, json, os
from pathlib import Path
import platform, re, shutil, subprocess, sys, time

REPO = Path('/tmp/sail-pecan-fusion-9d7155aa')
SHA = '9d7155aa2302d9dda4e93e48ee3fd81aac1ee637'
ROOT = Path('/Users/alexy/src/sail-extensions-poc/target/pecan-benchmark')
GATES = ROOT / 'gates-mac-fusion-9d7155aa'
TUTORIAL = ROOT / 'tutorial-mac-fusion-9d7155aa'
PYTHON = '/Users/alexy/src/sail-extensions-poc/.venvs/extensions-x86-final-de8e67098/bin/python'
BINARY = '/Users/alexy/src/sail-extensions-poc/target/extensions-portable-graphs/artifacts/sail-mac-x86-70b0d1ca-built'
RUNTIME_SHA = '70b0d1cab2cab945d4dbaf6842ee0e38c8aa1822'
NATIVE_SHA = 'de8e670989edb8ed5343764c52d0d002b6b6cd63'

def utc(): return datetime.now(timezone.utc).isoformat()
def command(*args): return subprocess.check_output(args, cwd=REPO, text=True).strip()
def state(): return {'sha': command('git', 'rev-parse', 'HEAD'), 'status_porcelain': command('git', 'status', '--porcelain'), 'free_disk_bytes': shutil.disk_usage(REPO).free}
def assert_source(value): assert value['sha'] == SHA and value['status_porcelain'] == '', value

def procs():
    lines = command('ps', '-axo', 'pid=,ppid=,pgid=,command=').splitlines()
    return [line for line in lines if BINARY in line and not any(x in line for x in ('/bin/zsh -', 'run-mac-fusion'))]

def write(path, value):
    temp = path.with_suffix('.json.tmp')
    temp.write_text(json.dumps(value, indent=2) + '\n')
    temp.replace(path)

GATES.mkdir(parents=True, exist_ok=False)
TUTORIAL.mkdir(parents=True, exist_ok=False)
sys.path.insert(0, str(REPO / 'examples/extensions/benchmarks'))
import runtime
before = state(); assert_source(before)
common = dict(source_sha=SHA, checkout=str(REPO), python=PYTHON, platform=platform.platform(), machine=platform.machine(), host=platform.node(), runtime_binary=BINARY, runtime_source_sha=RUNTIME_SHA, runtime_binary_sha256=runtime.sha256(BINARY), native_source_sha=NATIVE_SHA, installed_native_identity=runtime.native_package_identity(), package_versions=runtime.package_versions(), interpretation='macOS functional relational checks on preserved Sail runtime and installed old native wheel; no new Banda native kernel or benchmark timing qualification', started_utc=utc(), source_before=before, baseline_runtime_processes=procs())
assert common['runtime_binary_sha256'] == '3018463966771e0b2118effc82de5bf80037f46bb8b4c06ca889bdb52e4c32cf'
gate_receipt = dict(common, runs=[])
tutorial_receipt = dict(common, runs=[])
write(GATES / 'receipt.json', gate_receipt)
write(TUTORIAL / 'receipt.json', tutorial_receipt)
env = dict(os.environ, PYTHONPATH=str(REPO / 'examples/extensions/graph-algorithms/src'))

def run(name, argv, root, receipt):
    start = state(); assert_source(start)
    row = dict(name=name, command=argv, started_utc=utc(), source_before=start, log=f'{name}.log')
    receipt['runs'].append(row); write(root / 'receipt.json', receipt)
    print(f'{utc()} START {name}', flush=True)
    t0=time.monotonic()
    with (root / row['log']).open('w') as log:
        result = subprocess.run(argv, cwd=REPO, env=env, stdout=log, stderr=subprocess.STDOUT)
    row.update(returncode=result.returncode, finished_utc=utc(), wall_seconds=time.monotonic()-t0, source_after=state())
    assert_source(row['source_after'])
    lines=(root / row['log']).read_text().splitlines()
    row['log_tail']=lines[-4:]
    write(root / 'receipt.json', receipt)
    print(f'{utc()} END {name}: returncode={result.returncode}; ' + ' / '.join(lines[-2:]), flush=True)
    if result.returncode: raise RuntimeError(f'{name} failed; retained {root / row["log"]}')
    return row

try:
    row=run('benchmark-launcher', [PYTHON, '-m', 'pytest', '-q', 'examples/extensions/benchmarks', 'examples/extensions/scripts/tests'], GATES, gate_receipt)
    text=(GATES / row['log']).read_text()
    assert re.search(r'\b95 passed\b', text), text[-1000:]
    row['passed']=95
    for mode in ('local', 'process-cluster'):
        row=run(mode, [PYTHON, 'examples/extensions/scripts/test_graph_algorithms.py', '--sail-binary', BINARY, '--execution-mode', mode, '--output', str(GATES / mode)], GATES, gate_receipt)
        text=(GATES / row['log']).read_text()
        assert re.search(r'\b84 passed\b', text), text[-1000:]
        row.update(passed=84, staging_files_after_shutdown=[str(p.relative_to(GATES / mode)) for p in (GATES / mode / 'staging').rglob('*') if p.is_file()])
        assert not row['staging_files_after_shutdown'], row
    gate_receipt.update(finished_utc=utc(), source_after=state(), runtime_processes_after=procs(), outcome='passed')
    assert_source(gate_receipt['source_after'])
    assert gate_receipt['runtime_processes_after'] == common['baseline_runtime_processes'], gate_receipt['runtime_processes_after']
    write(GATES / 'receipt.json', gate_receipt)
    for mode in ('local', 'process-cluster'):
        for engine in ('pecan', 'nutmeg-datafusion'):
            name=f'{mode}-{engine}'
            row=run(name, [PYTHON, 'examples/extensions/benchmarks/tutorial_methods.py', '--sail-binary', BINARY, '--runtime-source-sha', RUNTIME_SHA, '--native-source-sha', NATIVE_SHA, '--mode', mode, '--engine', engine, '--output', str(TUTORIAL / name)], TUTORIAL, tutorial_receipt)
            summary=json.loads((TUTORIAL / name / 'tutorial-summary.json').read_text())
            assert summary['outcome'] == 'passed' and summary['planned_cells'] == 5 and len(summary['cells']) == 5, summary
            row['cells']=[dict(engine=c['engine'], algorithm=c['algorithm'], variant=c['variant'], outcome=c['outcome'], returncode=c['returncode'], receipt=f'{name}/{c["receipt"]}') for c in summary['cells']]
            for cell in summary['cells']:
                assert cell['outcome'] == 'passed' and cell['returncode'] == 0, cell
                detail=json.loads((TUTORIAL / name / cell['receipt']).read_text())
                assert detail['outcome'] == 'passed' and not detail['cleanup_errors'] and not detail['staging_files_after_shutdown'], detail
            row['staging_files_after_shutdown']=[str(p.relative_to(TUTORIAL / name)) for p in (TUTORIAL / name).glob('*/staging/**/*') if p.is_file()]
            assert not row['staging_files_after_shutdown'], row
            write(TUTORIAL / 'receipt.json', tutorial_receipt)
    tutorial_receipt.update(finished_utc=utc(), source_after=state(), runtime_processes_after=procs(), outcome='passed', passed_cells=sum(len(r['cells']) for r in tutorial_receipt['runs']))
    assert_source(tutorial_receipt['source_after'])
    assert tutorial_receipt['runtime_processes_after'] == common['baseline_runtime_processes'], tutorial_receipt['runtime_processes_after']
    write(TUTORIAL / 'receipt.json', tutorial_receipt)
    print(f'{utc()} PASSED: 95 benchmark/launcher, 84 local, 84 process-cluster, 20 tutorial calls; clean source and no retained runtime processes', flush=True)
except BaseException as error:
    target=gate_receipt if gate_receipt.get('outcome') != 'passed' else tutorial_receipt
    root=GATES if target is gate_receipt else TUTORIAL
    target.update(outcome='failed', finished_utc=utc(), error=repr(error), source_after=state(), runtime_processes_after=procs())
    write(root / 'receipt.json', target)
    raise
