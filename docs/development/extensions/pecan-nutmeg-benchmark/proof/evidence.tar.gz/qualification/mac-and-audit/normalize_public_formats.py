from pathlib import Path
from datetime import datetime,timezone
import csv,io,json,hashlib,xml.etree.ElementTree as ET
base=Path('docs/development/extensions/pecan-nutmeg-benchmark');changes=[]
for phase,original in [('primary','matrix-3c1fd28c-summary'),('fusion','fusion-matrix-3fd69787-summary'),('constrained','constrained-a6567b51-summary')]:
 p=base/phase/'cells.csv'
 before=(Path('target/extensions-pecan-benchmark/export')/original/'cells.csv').read_bytes();after=before.replace(b'\r\n',b'\n')
 assert list(csv.reader(io.StringIO(before.decode())))==list(csv.reader(io.StringIO(after.decode())))
 p.write_bytes(after);changes.append(dict(path=str(p),before_sha256=hashlib.sha256(before).hexdigest(),after_sha256=hashlib.sha256(after).hexdigest(),check='CSV rows identical; public CRLF normalized to LF; original source unchanged'))
for p in sorted((base/'figures').glob('*.svg')):
 before=p.read_bytes();after=('\n'.join(line.rstrip() for line in before.decode().splitlines())+'\n').encode()
 def primitives(raw):return [(e.tag, {k:' '.join(v.split()) for k,v in e.attrib.items()},(e.text or '').strip()) for e in ET.fromstring(raw).iter()]
 assert primitives(before)==primitives(after)
 p.write_bytes(after);changes.append(dict(path=str(p),before_sha256=hashlib.sha256(before).hexdigest(),after_sha256=hashlib.sha256(after).hexdigest(),check='XML primitives identical after insignificant whitespace normalization'))
for path in [Path('target/pecan-benchmark/render_report.py'),base/'reproduce/render_report.py']:
 s=path.read_text();old="        fig.savefig(output / f'{phase}-{algorithm}-scaling.{extension}', dpi=180)"
 new="        path = output / f'{phase}-{algorithm}-scaling.{extension}'\n        fig.savefig(path, dpi=180)\n        if extension == 'svg':\n            path.write_text('\\n'.join(line.rstrip() for line in path.read_text().splitlines()) + '\\n')"
 assert old in s;path.write_text(s.replace(old,new))
p=base/'README.md';s=p.read_text();old='Every planned cell remains present, including failures and cells never run.'
assert old in s;s=s.replace(old,'Published CSV sidecars use LF line endings; original CSV bytes remain in the\nproof archive. Every planned cell remains present, including failures and cells never run.');p.write_text(s)
Path('target/pecan-benchmark/public-format-normalization.json').write_text(json.dumps(dict(recorded_utc=datetime.now(timezone.utc).isoformat(),outcome='passed',boundary='Fix generated artifact whitespace without changing measured cells or visual primitives; original source evidence unchanged',files=changes),indent=2)+'\n')
p=Path('target/pecan-benchmark/evidence-selection-prepared.json');a=json.loads(p.read_text())
for name in ['public-format-normalization.json','report-format-check-before.log','normalize_public_formats.py']:
 source=str((Path('target/pecan-benchmark')/name).resolve())
 if not any(x['source']==source for x in a):a.append(dict(source=source,destination='qualification/mac-and-audit/'+name))
p.write_text(json.dumps(a,indent=2)+'\n')
print('Public CSV and SVG format normalization passed; values and primitives unchanged')
