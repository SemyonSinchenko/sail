# Independent Pecan pilot evidence audit

Written UTC: 2026-09-27T19:33:29.734723+00:00

The copied `pecan-pilots-a6567b51` evidence contains all 14 planned cells: 12 successful qualification calls and two intentional native nonconvergence cases. All 14 expected outcomes were observed. Replaying the exact a656 summarizer from Git reproduced every group in the supplied summary with zero integrity errors. This is a small-fixture functional audit, not a performance verdict or an admission guarantee for the separately running 150-cell matrix.

## Evidence and identities

- Raw evidence: `target/extensions-pecan-benchmark/evidence/pecan-pilots-a6567b51`.
- Export: `target/extensions-pecan-benchmark/evidence/pilots-a6567b51-summary`.
- Harness/Pecan source: `a6567b511a2ef1d99688f644134effb8461594f8`.
- Native Nutmeg source: `4e6100f0320fb952e9926b867193ec1768edfcda`.
- Sail executable source: `70b0d1cab2cab945d4dbaf6842ee0e38c8aa1822`.
- Sail executable SHA-256: `7353a7df02a624b3336f6c30d0968cbd42ae1f4bd3333ed6af9c638bbc77165a`; identical in all 14 receipts and the host release-build receipt.
- Native wheel SHA-256 in release/install evidence: `f3546797a2f17a1c6907ddf6da0f5a0e77e412044ae315abf114d4e887b8a7d7`. All 14 receipts contain identical installed Nutmeg file hashes. The source/build/install trail distinguishes this wheel from the earlier host-source Nutmeg wheel.
- Container image: `sha256:f3518d652fbea8b9b9f9ebf9849277ca3bd39d0c21bb2c6e36fbaeaa2dc2678e`; all cell inspections agree.

All receipts declare clean source, no dirty/unisolated overrides, and matching source revisions. I independently checked the configuration fingerprint and planned arguments through the exact a656 export checks, including diagnostic caps. All required copies succeeded; Docker reported no OOM; cleanup error lists are empty. A total of 27 copied data/result/gate-log artifacts matched their recorded SHA-256 and size. The local audit did not execute a server, use Morrobay, or alter source.

## Outcomes and independent correctness checks

Sparse input: 128 vertices, 1,024 directed edges, seven components, six isolates, 16 dangling vertices and 11 self-loops. Chain input: 512 vertices and 511 edges. Dataset bytes match their manifests and every cell's embedded manifest.

For all 12 successful cells I reread the complete copied Parquet output locally, verified the complete unique ID set, and compared every result with the independent reference. I recomputed PageRank's probability sum, nonnegative finite scores, full-vector reference error and true fixed-point L1 residual using NumPy. For WCC I canonicalized every output component by numeric minimum and compared all memberships. Successful result file hashes and sizes match their receipt inventories. These small local audit collections occur outside any measured process.

| Cell | Outcome | Independent output check | Execution memory samples |
| --- | --- | --- | ---: |
| qualification-r1-sparse-128-nutmeg-datafusion-wcc-reference | passed | 7 components; zero mismatches | 9 |
| qualification-r1-sparse-128-nutmeg-native-wcc-reference | passed | 7 components; zero mismatches | 1 |
| qualification-r1-sparse-128-nutmeg-native-pagerank-reference | passed | residual 2.25251823e-09; 19 iteration(s) | 1 |
| qualification-r1-sparse-128-pecan-wcc-reference | passed | 7 components; zero mismatches | 8 |
| qualification-r1-sparse-128-nutmeg-datafusion-pagerank-optimized | passed | residual 2.39293754e-09; 19 iteration(s) | 47 |
| qualification-r1-sparse-128-nutmeg-datafusion-wcc-optimized | passed | 7 components; zero mismatches | 20 |
| qualification-r1-sparse-128-pecan-pagerank-reference | passed | residual 2.25251826e-09; 19 iteration(s) | 35 |
| qualification-r1-sparse-128-nutmeg-datafusion-pagerank-reference | passed | residual 2.25251822e-09; 19 iteration(s) | 34 |
| qualification-r1-sparse-128-pecan-pagerank-optimized | passed | residual 2.39293754e-09; 19 iteration(s) | 47 |
| qualification-r1-sparse-128-nutmeg-native-pagerank-optimized | passed | residual 2.39293754e-09; 19 iteration(s) | 1 |
| qualification-r1-sparse-128-nutmeg-native-wcc-optimized | passed | 7 components; zero mismatches | 1 |
| qualification-r1-sparse-128-pecan-wcc-optimized | passed | 7 components; zero mismatches | 21 |
| wcc-cap-r1-chain-512-nutmeg-native-wcc-optimized | nonconverged | 1-round cap; no result emitted | 1 |
| pagerank-cap-r1-sparse-128-nutmeg-native-pagerank-optimized | nonconverged | residual 0.108956377; 1 iteration(s) | 1 |

All six successful PageRank calls take 19 iterations. Reference true residuals are approximately `2.252518e-9`; optimized residuals approximately `2.392938e-9`, both below `1e-8`. The three optimized outputs have reference L1 error approximately `4.197e-10`, within the declared bound. All six WCC outputs have exactly seven components and zero membership mismatches.

The native PageRank cap output independently confirms 128 unique rows, one iteration, `converged=false`, normalized finite nonnegative scores and true residual `0.10895637745684622`. It correctly remains nonconverged. Native randomized WCC's one-round cap retains a failed read with zero rows, `converged=false` and 234 remaining edges; no complete result is expected.

## Cross-path algorithm diagnostics

The randomized WCC traces match exactly across Pecan, Banda and Grenada after comparing coefficient values as unsigned 64-bit bit patterns. Seed is 42 throughout. The shared trace is:

| Round | Active vertices before | Edges before | Edges after |
| --- | ---: | ---: | ---: |
| 1 | 122 | 899 | 166 |
| 2 | 25 | 166 | 8 |
| 3 | 5 | 8 | 1 |
| 4 | 2 | 1 | 0 |

All four pairs of affine coefficients also match, not just round counts. The original 1,024 directed edges become 899 distinct undirected non-loop edges before contraction. Isolates remain represented in final outputs.

All three optimized PageRank paths have identical active-vertex, active-edge and reactivation sequences. There are 19 pushes and 19,105 propagated edge messages. The last five frontier sizes are `128, 120, 116, 104, 89`; last four active-edge counts are `1014, 999, 895, 837`. Reactivation counts in rounds 17–19 are `2, 3, 11`. Native diagnostics identify the tolerance-capped policy and two certificate passes traversing 2,048 edges. These message counts do not claim that relational execution avoided scanning Parquet edges.

Native optimized kernels report requested concurrency 8 and actual kernel width 1 on 128 vertices, consistent with fixed 4,096-source blocks. This pilot does not exercise native multicore execution. Separate release tests below cover actual widths 1/2/8 on 32,768 vertices.

## Memory and execution boundaries

Every inspected pilot container has eight CPU quota units, cpuset `0-7`, 32 GiB memory with total memory-plus-swap also 32 GiB, private default PID mode and init enabled. All pilots use process-worker mode. This is one Linux VM/container execution class, not the physical two-host functional deployment.

I rebuilt each receipt's phase counts and memory peaks from the copied `memory-samples.jsonl` rows and obtained exact matches. RSS is the sum of observed process RSS; PSS is present for every included execution sample and is summed only when every sampled process has PSS. Transition samples are excluded from phase peaks. The sampler records a 50 ms delay between scans; scans themselves take additional time, so this is not a guaranteed 50 ms observation period.

Each native pilot has only one complete execution-phase memory sample. Relational successful cells have 8–47 samples. These tiny native-call sampled peaks cannot establish the true transient maximum or meaningful memory scaling. Kernel `memory.peak` through result delivery is a separate container lifetime/page-cache measure; the later lifetime peak can include verification. Native admission/reservation peaks are neither RSS nor PSS. The common extension deployment prepays native allowance even for relational paths, so accounting reservations must not be described as allocated physical memory.

Whole-VM `/proc/stat` steal is recorded as zero for these pilots. That is neither a per-cpuset steal measurement nor proof that the physical host was otherwise idle. One repetition per method and a 128-vertex graph provide no dispersion or representative timing evidence. No pilot timing ranking is asserted here.

## Final gate coverage inspected

- Native source `4e6100f0`, Linux release: 68 vendor unit tests, one allocator integration test and five bridge tests passed. All 13 optimized tests also passed in a 0.25-CPU container with cpuset `0-7`, including actual pool widths 1/2/8 on 32,768 vertices. The native receipt pins the registry Grust 0.23.0 dependency and enabled parallel feature. Nine recorded gate-log hashes were rechecked locally.
- Native source `4e6100f0`, exact detached Mac gate: the same 68 + 1 vendor and five bridge tests, formatting and strict vendor Clippy passed. Bridge Clippy is qualified by the explicitly retained existing `large_enum_variant` exception; its original strict failure remains in evidence.
- Harness source `a6567b51`, Linux: 53 benchmark tests, 14 launcher tests and 72 Pecan tests in each local/process-worker mode passed. The receipt names native source `4e6100f0` and host source `70b0d1ca` separately and reports no remaining staging files.
- Exact Mac harness gate `a6567b51` passed with unchanged clean HEAD.
- Physical Capitola/Morrobay reference and optimized functional runs at source `4e6100f0` both report passed, driver supervisor return code zero and completed work on both worker IDs. They explicitly carry a functional-only/emulation boundary and are not timing evidence for the Linux pilots. The later a656 change is a harness/reporting child, not a native algorithm change.

## Gaps and limits

1. The native PageRank cap is classified correctly, but its receipt lacks `native_status_after`, correctness fields and a result-file hash inventory because validation raises before those are stored. The copied Parquet output allowed this independent audit to confirm one-iteration nonconvergence. Retain the receipt's failure outcome; do not interpret missing diagnostics as a missing execution. A later harness revision could capture status and output inventory before raising on nonconvergence.
2. The pilot copy contains the native wheel's build/install/hash records and installed-file fingerprints, but not the wheel archive itself. I verified their internal consistency, not an independent extraction comparison between wheel bytes and installed extension bytes. The host binary likewise is identified by its build and cell hashes rather than rehashed from a locally copied Linux executable.
3. The small fixture does not validate large graph staging admission, worker task-slot capacity, wide native kernels, long-running cleanup, or resource scaling. Those claims require the preserved larger matrix outcomes and applicable stress gates. The 150-cell matrix is outside this report; none of its cells is replaced by these pilots.
4. a656 export integrity checks guard successful trial admission into statistics and compare identities, but they are not a substitute for rereading output artifacts and recomputing correctness. This audit supplied that independent check for the copied pilot outputs. Nonconverged cells remain separate and do not enter successful timing/memory statistics.

Machine-readable audit observations, including per-cell residuals, sample counts and complete common coefficient trace, are in `target/pecan-benchmark/pilot-audit-details.json`. The checks were executed locally from `/tmp/audit_pecan_pilots.py`; all assertions passed.
