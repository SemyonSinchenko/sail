# Independent primary-report review

Recorded 2026-09-27T21:02:34.833162+00:00.

Reviewed snapshot: `report-primary-reviewed-input.md`, SHA-256 `f53b8016666f36f3f9f650d542c8548bfb7b5488ef0d677f8ac3f2884545e063`. Numeric checker: `check_report_primary.py`; machine results: `report-primary-review.json`.

**No blocking numeric or semantic finding.** The review covers the completed primary matrix. Fusion result insertion and final fusion accuracy statements remain pending its evidence audit.

## Numeric checks

- All 12 primary table rows match raw receipts, including time, PSS, RSS and cgroup medians/minima/maxima at the stated precision.
- All six chain rows preserve their actual outcomes and distinguish complete-answer time from elapsed-to-cap time.
- All three fixture-count rows match manifests. All 24 sparse advanced/reference median pairs support the report’s stated elapsed-time observation.
- Iteration counts, message totals and the four 1m WCC time/PSS examples agree with all applicable records.
- Relational PageRank PSS at 1m is lower than at 100k across every three-repetition range. The report correctly leaves the cause unestablished.

## Contracts and boundaries

The PageRank bounds are consistent: reference power’s stationary error is bounded by `d*t/(1-d)` after a last-step difference of at most `t`; delta certifies `t/(1-d)`. Comparing each with the independent power reference yields `2*d*t/(1-d)` and `(1+d)*t/(1-d)`, respectively, with the separate numerical slack and true-residual check disclosed.

WCC methods, minimum-label diameter dependence, seeded randomized contraction, fused preprocessing scope and original-ID representatives are described accurately. The native reference algorithm and local additions are distinguished.

The report correctly identifies driver-only native prepayment, per-worker pools, aggregate container limits and requested versus actual advanced pool widths. Timing and memory boundaries match the frozen code. The one-sample native chain caveat and zero whole-VM steal qualification are preserved.

## Two optional precision edits

- **Correctness, gates and retained failures: independent primary audit paragraph:** Use independently checks sixteen retained full output vectors rather than independently recalculates sixteen retained full outputs. The audit reconstructs WCC answers, applies the PageRank operator to every raw score, and compares every score with the stored independent reference; it does not run a fresh stationary PageRank solve.
- **Measurement protocol: timing paragraph:** Per-iteration instrumentation is more precise than diagnostics: algorithm observers and certificates are inside timing, while native status snapshots, result hashes and correctness validation occur after the output-write timer stops.

These edits clarify wording; neither changes a measurement, observed result, or audit verdict.
