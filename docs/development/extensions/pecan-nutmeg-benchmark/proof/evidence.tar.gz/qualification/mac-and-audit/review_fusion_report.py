"""Read-only report arithmetic checks; writes only a scratch review receipt."""
from collections import defaultdict
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
from statistics import median
import csv
import json
import subprocess

ROOT = Path('/Users/alexy/src/sail-extensions-poc')
BASE = Path('docs/development/extensions/pecan-nutmeg-benchmark')

def read_json(path):
    return json.loads((ROOT / path).read_text())

summary = read_json(BASE / 'fusion/summary.json')
audit = read_json(BASE / 'audit/fusion-audit.json')
report_path = Path('docs/development/extensions/pecan-nutmeg-benchmark.md')
report = (ROOT / report_path).read_text()
assert report == (ROOT / 'target/pecan-benchmark/report-draft.md').read_text()
assert summary['planned_cells'] == 78
assert summary['outcomes'] == {'passed': 78}
assert not summary['integrity_errors']
with (ROOT / BASE / 'fusion/cells.csv').open() as stream:
    cells = list(csv.DictReader(stream))
assert len(cells) == 78 and all(c['outcome'] == 'passed' for c in cells)
assert all(float(c['whole_vm_steal_fraction']) == 0 for c in cells)
assert all(c[k] == v for c in cells for k,v in summary['sources'].items())
assert len({c['native_installed_files_identity'] for c in cells}) == 1

groups = {(g['suite'], g['dataset'], g['mode'], g['engine'], g['variant']): g for g in summary['groups']}
by_group = defaultdict(list)
for cell in cells:
    by_group[tuple(cell[k] for k in ('suite', 'dataset', 'mode', 'engine', 'variant'))].append(cell)
metrics_checked = 0
for key, group in groups.items():
    raw = by_group[key]
    assert group['planned'] == group['passed'] == len(raw)
    for name in ('seconds', 'execution_pss_bytes', 'execution_rss_bytes', 'cgroup_peak_through_result_bytes', 'iterations'):
        values = [float(c[name]) for c in raw if c[name]]
        value = group['metrics'][name]
        if not values:
            assert value is None, (key, name)
        else:
            assert value == {'samples': len(values), 'median': median(values), 'minimum': min(values), 'maximum': max(values)}, (key, name, value, values)
        metrics_checked += 1

names = {'pecan':'Pecan', 'nutmeg-native':'Banda', 'nutmeg-datafusion':'Grenada'}
comparisons = []
expected_lines = []
for size in (10_000, 100_000, 1_000_000):
    for engine, label in names.items():
        pair = [groups[('distributed', f'sparse-{size}', 'process-cluster', engine, variant)] for variant in ('optimized','fused')]
        assert all(g['planned'] == g['passed'] == 3 for g in pair)
        times = [g['metrics']['seconds'] for g in pair]
        pss = [g['metrics']['execution_pss_bytes'] for g in pair]
        ut, ft = [v['median'] for v in times]
        up, fp = [v['median'] / 2**20 for v in pss]
        ratio = ft / ut
        line = f'| {size:,} | {label} | {ut:.3f} | {ft:.3f} | {ratio:.3f} | {up:.3f} | {fp:.3f} |'
        assert line in report, line
        expected_lines.append(line)
        comparisons.append(dict(vertices=size, path=label, unfused_seconds=ut, fused_seconds=ft,
            fused_to_unfused_seconds_ratio=ratio, time_reduction_percent=100*(1-ratio),
            unfused_pss_mib=up, fused_pss_mib=fp, pss_change_percent=100*(fp/up-1),
            unfused_time_range=[times[0]['minimum'], times[0]['maximum']], fused_time_range=[times[1]['minimum'], times[1]['maximum']]))
fig_table = (ROOT / BASE / 'figures/fusion-comparison.md').read_text().splitlines()
assert fig_table[2:] == expected_lines
ratios = read_json(BASE / 'figures/fusion-ratios.json')
assert len(ratios) == len(comparisons) == 9
for row, comparison in zip(ratios, comparisons):
    assert all(comparison[k] == v for k,v in row.items())

local = []
for engine, label in names.items():
    pair = [groups[('local', 'sparse-100000', 'local', engine, variant)]['metrics']['seconds'] for variant in ('optimized','fused')]
    local.append(dict(path=label, time_reduction_percent=100*(1-pair[1]['median']/pair[0]['median']),
                      unfused_time_range=[pair[0]['minimum'],pair[0]['maximum']],
                      fused_time_range=[pair[1]['minimum'],pair[1]['maximum']],
                      ranges_overlap=max(p['minimum'] for p in pair)<=min(p['maximum'] for p in pair)))
rel = [c['time_reduction_percent'] for c in comparisons if c['path'] in ('Pecan','Grenada')]
assert [f'{min(rel):.1f}',f'{max(rel):.1f}'] == ['10.3','25.8']
rel_local = [c['time_reduction_percent'] for c in local if c['path'] in ('Pecan','Grenada')]
assert [f'{min(rel_local):.1f}',f'{max(rel_local):.1f}'] == ['25.3','27.1']
banda = [c for c in comparisons if c['path']=='Banda']
assert [f"{min(c['time_reduction_percent'] for c in banda):.1f}",f"{max(c['time_reduction_percent'] for c in banda):.1f}"] == ['2.6','5.0']
banda_local = next(c for c in local if c['path']=='Banda')
assert f"{banda_local['time_reduction_percent']:.1f}" == '1.0' and banda_local['ranges_overlap']
assert f"{banda[0]['pss_change_percent']:.1f}" == '1.6'
for label, expected in [('Pecan','33.0'),('Grenada','27.8')]:
    value = next(c for c in comparisons if c['path']==label and c['vertices']==1_000_000)
    assert f"{value['pss_change_percent']:.1f}" == expected

chain = next(c for c in cells if c['suite']=='chain-diagnostic' and c['engine']=='nutmeg-native' and c['variant']=='fused')
assert chain['execution_sampled']=='False' and not chain['execution_pss_bytes'] and not chain['execution_rss_bytes']
assert '| Banda | advanced fused | passed | completed output | 0.042 | unavailable |' in (ROOT / BASE / 'figures/fusion-chain-diagnostic.md').read_text()
assert audit['unique_verified_files']==525 and audit['reconstructed_samples']==5147
assert audit['raw_coverage']=={'raw_full_vector':6,'receipt_only':72}
assert audit['sources']==summary['sources']
assert sum(len(x['compared_cells']) for x in audit['cross_path_contractions'])==78
assert {x['dataset']:x['rounds'] for x in audit['cross_path_contractions']} == {'sparse-10000':6,'sparse-100000':9,'sparse-1000000':11,'chain-512':9}
assert audit['post_stop_cleanup']['remaining_staging_regular_files']==[]
assert 'ratio of three-run medians' in report and 'not a paired-trial speedup' in report
assert 'no execution memory sample' in report and 'unavailable, not zero' in report
assert 'not statistical confidence or a universal ranking' in report

paths = [report_path, Path('target/pecan-benchmark/report-draft.md'), Path('target/pecan-benchmark/render_report.py'),
         Path('target/pecan-benchmark/review_fusion_report.py'), BASE/'fusion/summary.json', BASE/'fusion/cells.csv', BASE/'fusion/tables.md',
         BASE/'audit/fusion-audit.json', BASE/'audit/fusion-audit.md', BASE/'reproduce/render_report.py']
paths.extend(sorted((BASE/'figures'/p.name) for p in (ROOT/BASE/'figures').glob('fusion-*')))
receipt = dict(generated_utc=datetime.now(timezone.utc).isoformat(), reviewer='client_graph',
    outcome='passed', scope='Final measured fusion report, numerical comparisons, generated tables/figure, qualifiers and recorded audit attribution; read-only review.',
    implementation_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    documentation_state='Uncommitted report/navigation artifacts; verdict covers exact artifact hashes, not a documentation commit.',
    sources=summary['sources'], artifacts=[dict(path=str(p),sha256=sha256((ROOT/p).read_bytes()).hexdigest()) for p in paths],
    checked_cells=78, checked_groups=len(groups), reconstructed_group_metrics_from_csv=metrics_checked,
    distributed_comparisons=comparisons, local_100k_comparisons=local,
    verified_claims=[
        'All nine process-worker table rows and all nine ratios match full-precision summary medians, correctly rounded; CSV independently reconstructs summary time/PSS/RSS/cgroup/iteration metrics.',
        'Pecan/Grenada time reductions 10.3-25.8% process-worker and 25.3-27.1% local; one-million-vertex sampled PSS increases 33.0% and 27.8%.',
        'Banda process-worker median reductions 2.6-5.0%; local reduction 1.0% with overlapping observed timing ranges; 10k sampled PSS increase 1.6%.',
        'Matched controls use identical native installed identity/source across all 78 cells. No primary-versus-fusion phase substitution is used in the nine comparisons.',
        'The published fusion figure is visually legible and labels log elapsed time, sampled execution peak PSS, medians/full ranges, three repetitions and driver-local Banda kernels. Renderer uses summary minimum/maximum error bars.',
        'Single-repetition chain results remain separate. Native fused chain sampled PSS/RSS is unavailable, not zero; audit and generated chain table agree.',
        'Final fusion audit attribution matches 525 unique files, 5147 raw memory samples, six full output checks, 72 receipt-only checks, all 78 contraction traces grouped by dataset, zero recorded VM steal and empty post-stop staging.',
        'Report states sampled/lifetime/admission memory boundaries, three-run medians rather than paired speedups, limited fixtures/one seed, no confidence or universal ranking, and no isolated allocation cause.',
        'Seven-vertex two-host proof is explicitly relational and separate from one-host process-worker timing; unchanged old native wheel does not qualify distributed Banda.'
    ], findings=[], limitations=[
        'No benchmark or test rerun and no remote host operations in this review.',
        'Numerical re-aggregation uses published per-cell CSV; raw-sample/output reconstruction belongs to the separately identified independent fusion audit.',
        'This review does not establish causal allocation mechanisms, statistical confidence, physical multi-host scaling or performance beyond retained fixtures.',
        'Final proof archive packaging and any later report edits require separate checks; earlier report-review-3fd69787.json remains unchanged.'
    ])
out = ROOT/'target/pecan-benchmark/report-fusion-review-3fd69787.json'
out.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(dict(outcome=receipt['outcome'],receipt=str(out.relative_to(ROOT)),sha256=sha256(out.read_bytes()).hexdigest(),groups=len(groups),metrics=metrics_checked,report_sha256=sha256((ROOT/report_path).read_bytes()).hexdigest(),generated_utc=receipt['generated_utc']),indent=2))
