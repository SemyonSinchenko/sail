import argparse, ast, hashlib, json, os, re, shutil, subprocess, tarfile
from datetime import datetime, timezone
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('--repo',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--python',type=Path,required=True)
p.add_argument('--plot-python',type=Path,required=True)
a=p.parse_args();repo=a.repo.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
def git(*args): return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
source=git('rev-parse','HEAD'); assert not git('status','--porcelain')
receipt=dict(started_utc=datetime.now(timezone.utc).isoformat(),source_sha=source,free_disk_before=shutil.disk_usage(repo).free,commands=[])
base=repo/'docs/development/extensions/pecan-nutmeg-benchmark'
repro=base/'reproduce';proof=base/'proof';unpacked=repo/'target/pecan-public-proof'
def run(name,cmd,env=None):
 with (out/(name+'.log')).open('w') as stream:
  r=subprocess.run([str(c) for c in cmd],cwd=repo,env=env,stdout=stream,stderr=subprocess.STDOUT)
 receipt['commands'].append(dict(name=name,command=[str(c) for c in cmd],returncode=r.returncode))
 assert r.returncode==0,(name,r.returncode)
try:
 run('benchmark-launcher',[a.python,'-m','pytest','-q','examples/extensions/benchmarks','examples/extensions/scripts/tests'])
 blocks=[]
 for doc in [repo/'examples/extensions/benchmarks/TUTORIAL.md',base/'README.md']:
  text=doc.read_text()
  for code in re.findall(r'```bash\n(.*?)```',text,re.S):
   subprocess.run(['bash','-n'],input=code,text=True,check=True);blocks.append('bash')
  for code in re.findall(r"<<'PY'\n(.*?)\nPY",text,re.S):ast.parse(code);blocks.append('python')
  for code in re.findall(r'```json\n(.*?)```',text,re.S):json.loads(code);blocks.append('json')
 receipt['documentation_blocks_checked']=blocks
 archive=proof/'evidence.tar.gz';bundle=json.loads((proof/'bundle.json').read_text());manifest=json.loads((proof/'manifest.json').read_text())
 assert hashlib.sha256(archive.read_bytes()).hexdigest()==bundle['archive_sha256']
 unpacked.mkdir(parents=True,exist_ok=False)
 with tarfile.open(archive,'r:gz') as tar:
  assert tar.extractfile('manifest.json').read()==(proof/'manifest.json').read_bytes()
  for entry in manifest['included']:
   data=tar.extractfile(entry['path']).read()
   assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256']
  tar.extractall(unpacked,filter='data')
 receipt['unpacked_files_verified']=len(manifest['included'])
 env=dict(os.environ,PECAN_AUDIT_PILOTS=str(unpacked/'qualification/linux/pecan-pilots-a6567b51'))
 run('auditor-corruption-controls',[a.python,repro/'test_audit_matrix.py'],env)
 for phase,kind,dirname in [('primary','main','export-matrix-3c1fd28c'),('fusion','fusion','export-fusion-matrix-3fd69787')]:
  run('public-'+phase+'-audit',[a.python,repro/'audit_matrix.py','--repo',repo,'--kind',kind,'--evidence',unpacked/phase/dirname,'--summary',base/phase,'--output',out/('public-'+phase+'-audit')])
 rendered=repo/'target/pecan-rebuilt-figures'
 run('render-figures',[a.plot_python,repro/'render_report.py','--primary',base/'primary/summary.json','--fusion',base/'fusion/summary.json','--output',rendered])
 for path in rendered.iterdir():
  if path.suffix in {'.md','.json'}:assert path.read_bytes()==(base/'figures'/path.name).read_bytes(),path
 run('artifact-delivery',[a.python,repro/'validate_delivery.py','--repo',repo,'--output',out/'artifact-delivery.json'])
 assert git('rev-parse','HEAD')==source and not git('status','--porcelain')
 receipt['outcome']='passed'
except BaseException as e:
 receipt['outcome']='failed';receipt['error']=repr(e);raise
finally:
 receipt['finished_utc']=datetime.now(timezone.utc).isoformat();receipt['ending_sha']=git('rev-parse','HEAD');receipt['ending_status']=git('status','--porcelain');receipt['free_disk_after']=shutil.disk_usage(repo).free
 (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('PECAN_DOCUMENTATION_GATE',source,'PASSED')
