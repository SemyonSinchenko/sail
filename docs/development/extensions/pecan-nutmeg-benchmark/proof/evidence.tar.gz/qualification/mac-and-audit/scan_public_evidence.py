"""Check a proof archive for task credentials without displaying their values."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import tarfile

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--archive',type=Path,required=True)
p.add_argument('--private-environment',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args()
environment=json.loads(a.private_environment.read_text())
values={k:str(v).encode() for k,v in environment.items()
        if any(word in k for word in ['ACCESS_KEY','SECRET','TOKEN','PASSWORD']) and str(v)}
assert values,'No task credential values found to check'
found=[]; count=0
with tarfile.open(a.archive,'r:gz') as t:
 for item in t:
  if not item.isfile():continue
  count+=1;data=t.extractfile(item).read()
  keys=[k for k,v in values.items() if v in data]
  if keys:found.append(dict(path=item.name,credential_keys=keys))
record=dict(recorded_utc=datetime.now(timezone.utc).isoformat(),archive_sha256=hashlib.sha256(a.archive.read_bytes()).hexdigest(),
            scanned_files=count,credential_fields_checked=sorted(values),matches=found,outcome='passed' if not found else 'failed',
            boundary='Exact task credential-value scan; no claim of exhaustive secret detection.')
a.output.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
assert not found,'Private task credentials found; do not publish this archive'
