# Two-host fused Pecan qualification

The final run uses clean harness source `3fd6978757713482942656cb0b23205fe57647d0`, with Pecan algorithm source unchanged from `9d7155aa2302d9dda4e93e48ee3fd81aac1ee637`. Both physical hosts use the preserved `70b0d1ca` Sail executable and identical previously qualified `de8e67098` native extension bytes. This is relational functional evidence; it does not qualify new Banda kernels or performance.

The original 9d attempt is retained: delta PageRank passed, but fused WCC was refused because its representative query required eight task slots and the launcher supplied four. All Sail processes stopped and two storage scans found zero objects. The corrected launcher adds an explicit positive integer `--worker-task-slots`, preserving default two. The final attempt selects four slots per worker (eight total). Its immutable benchmark/launcher suite passed 101 tests.

The final run passed PageRank and exact WCC validation. Both physical workers completed tasks within 72 delta PageRank iteration windows and two fused WCC contraction windows. The supervisor returned zero, all Sail PIDs exited, independent scans found zero objects under the dedicated prefix, and MinIO was stopped with its endpoint closed.

See `two-host-fusion-3fd69787/fused/receipt.json`, `final-verification.json` and the storage/MinIO receipts for the final result. The failed receipt under `two-host-fusion-9d7155aa/fused/receipt.json` remains unchanged. Exact command arrays, source checks, harness snapshots, controller/server logs, both cleanup records, and original/export SHA256s are retained. `manifest.json` describes omissions and redactions.
