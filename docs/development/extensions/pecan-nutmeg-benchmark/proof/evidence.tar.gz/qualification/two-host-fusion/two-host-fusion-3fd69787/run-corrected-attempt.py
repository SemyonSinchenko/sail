from datetime import datetime,timezone
import json,os,shlex,subprocess,sys
from pathlib import Path
SHA='3fd6978757713482942656cb0b23205fe57647d0'
SOURCE=Path('/tmp/sail-pecan-twohost-capacity-3fd69787')
ROOT=Path('/Users/alexy/src/sail-extensions-poc/target/pecan-benchmark')
OUT=ROOT/'two-host-fusion-3fd69787'
OLD=ROOT/'two-host-fusion-9d7155aa'
REMOTE='/Users/alexy/src/sail-extensions-gates/graph-algorithms/pecan-two-host-3fd69787'
REMOTE_GIT='/Users/alexy/src/sail-extensions-gates/graph-algorithms/pecan-two-host-9d7155aa'
REMOTE_BUNDLE='/Users/alexy/src/sail-extensions-gates/pecan-benchmark/twohost-capacity-3fd69787.bundle'
REMOTE_PYTHON='/Users/alexy/src/sail-extensions-gates/mac-venv-de8e67098/bin/python'
PYTHON='/Users/alexy/src/sail-extensions-poc/.venvs/extensions-x86-final-de8e67098/bin/python'
SSH=['ssh','-T','-o','BatchMode=yes','-o','ConnectTimeout=10','morrobay']
OUT.mkdir(parents=True,exist_ok=False)
config=json.loads((OLD/'config.json').read_text())
for target in [config['driver'],*config['workers']]: target['repo']=REMOTE if target.get('ssh') else str(SOURCE)
(OUT/'config.json').write_text(json.dumps(config,indent=2)+'\n')
provenance=json.loads((OLD/'qualification-provenance.json').read_text())
provenance.update(created_utc=datetime.now(timezone.utc).isoformat(),candidate_source_sha=SHA,algorithm_source_sha='9d7155aa2302d9dda4e93e48ee3fd81aac1ee637',worker_task_slots=4,configured_total_worker_task_slots=8,prior_attempt='../two-host-fusion-9d7155aa/fused/receipt.json')
(OUT/'qualification-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')

def utc(): return datetime.now(timezone.utc).isoformat()
def source_state():
    return dict(sha=subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip(),status_porcelain=subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain'],text=True).strip())
def persist(): (OUT/'orchestration-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
def step(name,command):
    row=dict(name=name,command=command,started_utc=utc(),log=name+'.log'); receipt['steps'].append(row);persist()
    print(utc(),'START',name,flush=True)
    with (OUT/row['log']).open('w') as log:
        result=subprocess.run(command,cwd=SOURCE,env=dict(os.environ,PYTHONPATH=str(SOURCE/'examples/extensions/graph-algorithms/src')),stdout=log,stderr=subprocess.STDOUT)
    row.update(returncode=result.returncode,finished_utc=utc());persist()
    print(utc(),'END',name,'returncode',result.returncode,flush=True)
    assert result.returncode==0,f'{name} failed, retained its log'
def remote(name,argv): step(name,SSH+[shlex.join(argv)])

def remote_source_program():
    return "from datetime import datetime,timezone; import json,subprocess; p="+repr(REMOTE)+"; sha=subprocess.check_output(['git','-C',p,'rev-parse','HEAD'],text=True).strip(); status=subprocess.check_output(['git','-C',p,'status','--porcelain'],text=True).strip(); assert sha=="+repr(SHA)+" and not status; print(json.dumps(dict(checked_utc=datetime.now(timezone.utc).isoformat(),sha=sha,status_porcelain=status)))"

receipt=dict(started_utc=utc(),source_sha=SHA,local_source_before=source_state(),steps=[],worker_task_slots=4,configured_total_worker_task_slots=8)
assert receipt['local_source_before']==dict(sha=SHA,status_porcelain='')
try:
    step('immutable-benchmark-launcher',[PYTHON,'-m','pytest','-q','examples/extensions/benchmarks','examples/extensions/scripts/tests'])
    assert '101 passed' in (OUT/'immutable-benchmark-launcher.log').read_text()
    step('copy-child-bundle',['scp','-o','BatchMode=yes','-o','ConnectTimeout=10','/tmp/sail-pecan-twohost-capacity-3fd69787.bundle','morrobay:'+REMOTE_BUNDLE])
    remote('remote-fetch',['git','-C',REMOTE_GIT,'fetch',REMOTE_BUNDLE,'refs/codex/pecan-twohost-capacity-candidate'])
    remote('remote-worktree',['git','-C',REMOTE_GIT,'worktree','add','--detach',REMOTE,SHA])
    remote('remote-source-start',['env','-u','PYTHONHOME','-u','PYTHONPATH',REMOTE_PYTHON,'-c',remote_source_program()])
    command=[PYTHON,str(SOURCE/'examples/extensions/scripts/two_host.py'),'--config',str(OUT/'config.json'),'--exercise','portable-graphs','--pagerank-method','delta','--pagerank-iterations','1000','--tolerance','1e-8','--wcc-method','randomized_fused','--wcc-iterations','100','--seed','42','--worker-task-slots','4','--output',str(OUT/'fused')]
    step('fused-controller',command)
    remote('remote-source-end',['env','-u','PYTHONHOME','-u','PYTHONPATH',REMOTE_PYTHON,'-c',remote_source_program()])
    receipt.update(outcome='passed; awaiting zero storage and MinIO shutdown',finished_utc=utc(),local_source_after=source_state())
    assert receipt['local_source_after']==dict(sha=SHA,status_porcelain='')
except BaseException as error:
    receipt.update(outcome='failed',finished_utc=utc(),error=repr(error),local_source_after=source_state())
    raise
finally:
    persist()
