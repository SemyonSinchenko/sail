"""Owned functional-test MinIO lifecycle; credentials stay in process memory."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import time
from urllib.parse import urlsplit
import pyarrow.fs as fs

SOURCE_SHA = '9d7155aa2302d9dda4e93e48ee3fd81aac1ee637'
ROOT = Path('/Users/alexy/src/sail-extensions-gates/graph-algorithms')
OUTPUT = Path('/Users/alexy/src/sail-extensions-gates/pecan-benchmark/two-host-fusion-9d7155aa')


def utc():
    return datetime.now(timezone.utc).isoformat()


def listening(endpoint):
    try:
        with socket.create_connection((endpoint.hostname, endpoint.port), timeout=1):
            return True
    except OSError:
        return False


def objects(config, endpoint):
    staging = urlsplit(config['SAIL_GRAPH_UTILS_ROOT'])
    assert staging.scheme == 's3' and staging.netloc and staging.path.strip('/'), 'dedicated S3 prefix required'
    store = fs.S3FileSystem(access_key=config['AWS_ACCESS_KEY_ID'],
                           secret_key=config['AWS_SECRET_ACCESS_KEY'],
                           endpoint_override=endpoint.netloc, scheme=endpoint.scheme,
                           region=config['AWS_DEFAULT_REGION'])
    prefix = staging.netloc + staging.path
    entries = store.get_file_info(fs.FileSelector(prefix, recursive=True, allow_not_found=True))
    return prefix, [p.path for p in entries if p.type == fs.FileType.File]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['start', 'inspect', 'stop'])
    args = parser.parse_args()
    config = json.loads((ROOT / 'storage-environment.json').read_text())
    endpoint = urlsplit(config.get('AWS_ENDPOINT_URL') or config['AWS_ENDPOINT'])
    assert endpoint.hostname and endpoint.port
    OUTPUT.mkdir(parents=True, exist_ok=True)
    receipt = dict(started_utc=utc(), source_sha=SOURCE_SHA, action=args.action)
    destination = OUTPUT / f'minio-{args.action}.json'
    assert not destination.exists(), 'retain existing lifecycle receipt; choose a separate attempt'
    process = None
    try:
        if args.action == 'start':
            assert not listening(endpoint), 'MinIO port is already occupied'
            env = dict(os.environ, MINIO_ROOT_USER=config['AWS_ACCESS_KEY_ID'],
                       MINIO_ROOT_PASSWORD=config['AWS_SECRET_ACCESS_KEY'])
            executable = ROOT / 'bin/minio'
            command = [str(executable), 'server', str(ROOT / 'minio-data'),
                       '--address', f'0.0.0.0:{endpoint.port}', '--console-address', '127.0.0.1:39001']
            with (OUTPUT / 'minio.log').open('w') as log:
                process = subprocess.Popen(command, env=env, stdin=subprocess.DEVNULL,
                                           stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            (ROOT / 'minio.pid').write_text(str(process.pid) + '\n')
            receipt.update(pid=process.pid, command=command,
                           binary_sha256=hashlib.sha256(executable.read_bytes()).hexdigest())
            for _ in range(100):
                assert process.poll() is None, 'owned MinIO process exited during startup'
                if listening(endpoint):
                    break
                time.sleep(.1)
            else:
                raise TimeoutError('owned MinIO endpoint did not become ready')
        prefix, remaining = objects(config, endpoint)
        receipt.update(scope='s3://' + prefix, remaining_object_count=len(remaining), remaining_objects=remaining)
        assert not remaining, 'scoped object store still contains files'
        if args.action == 'stop':
            pid = int((ROOT / 'minio.pid').read_text())
            command = subprocess.check_output(['ps', '-p', str(pid), '-o', 'command='], text=True).strip()
            assert str(ROOT / 'bin/minio') in command and str(ROOT / 'minio-data') in command
            os.kill(pid, signal.SIGTERM)
            for _ in range(100):
                status = subprocess.run(['ps', '-p', str(pid), '-o', 'stat='], text=True, capture_output=True)
                if status.returncode != 0 or status.stdout.strip().startswith('Z'):
                    break
                time.sleep(.1)
            else:
                raise RuntimeError('owned MinIO did not stop after SIGTERM')
            assert not listening(endpoint), 'owned MinIO endpoint still accepts connections'
            receipt.update(pid=pid, minio_stopped=True)
        receipt['outcome'] = 'passed'
    except BaseException as error:
        receipt.update(outcome='failed', error_type=type(error).__name__, error=str(error))
        if process is not None and process.poll() is None:
            process.terminate()
            process.wait(timeout=10)
        raise
    finally:
        receipt['finished_utc'] = utc()
        destination.write_text(json.dumps(receipt, indent=2) + '\n')
        print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
