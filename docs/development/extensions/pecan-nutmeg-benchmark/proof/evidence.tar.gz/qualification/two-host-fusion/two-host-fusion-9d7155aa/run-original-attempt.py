from datetime import datetime, timezone
import json, os
from pathlib import Path
import shlex, subprocess, time

BASE=Path('/Users/alexy/src/sail-extensions-poc/target/pecan-benchmark/two-host-fusion-9d7155aa')
SOURCE=Path('/tmp/sail-pecan-fusion-9d7155aa')
REMOTE='/Users/alexy/src/sail-extensions-gates/graph-algorithms/pecan-two-host-9d7155aa'
REMOTE_OUTPUT='/Users/alexy/src/sail-extensions-gates/pecan-benchmark/two-host-fusion-9d7155aa'
REMOTE_PYTHON='/Users/alexy/src/sail-extensions-gates/mac-venv-de8e67098/bin/python'
SHA='9d7155aa2302d9dda4e93e48ee3fd81aac1ee637'
SSH=['ssh','-T','-o','BatchMode=yes','-o','ConnectTimeout=10','morrobay']

def utc(): return datetime.now(timezone.utc).isoformat()
def state():
    return {'sha':subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip(), 'status_porcelain':subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain'],text=True).strip()}
def persist():
    (BASE/'orchestration-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
def step(name,command):
    item={'name':name,'command':command,'started_utc':utc()}; receipt['steps'].append(item);persist()
    print(utc(),'START',name,flush=True)
    with (BASE/f'{name}.log').open('w') as stream:
        result=subprocess.run(command,cwd=SOURCE,env=os.environ,stdout=stream,stderr=subprocess.STDOUT)
    item.update(returncode=result.returncode,finished_utc=utc(),log=f'{name}.log');persist()
    print(utc(),'END',name,'returncode',result.returncode,flush=True)
    if result.returncode: raise RuntimeError(f'{name} failed; retained its log')

def remote(name,argv): step(name,SSH+[shlex.join(argv)])

receipt={'started_utc':utc(),'source_sha':SHA,'local_source_before':state(),'steps':[], 'boundary':'functional two-host Pecan methods; preserved70b0 runtime and de8e native wheel; no timings qualified'}
assert receipt['local_source_before']=={'sha':SHA,'status_porcelain':''}
try:
    remote('remote-fetch',['git','-C','/Users/alexy/src/sail-extensions-gates/graph-algorithms/pecan-two-host-4e6100f0','fetch','/Users/alexy/src/sail-extensions-gates/pecan-benchmark/candidate.bundle','refs/codex/pecan-fusion-candidate'])
    remote('remote-worktree',['git','-C','/Users/alexy/src/sail-extensions-gates/graph-algorithms/pecan-two-host-4e6100f0','worktree','add','--detach',REMOTE,SHA])
    remote('remote-source-start',['env','-u','PYTHONHOME','-u','PYTHONPATH',REMOTE_PYTHON,'-c',"from datetime import datetime,timezone; import json,shutil,subprocess; p="+repr(REMOTE)+"; sha=subprocess.check_output(['git','-C',p,'rev-parse','HEAD'],text=True).strip(); status=subprocess.check_output(['git','-C',p,'status','--porcelain'],text=True).strip(); assert sha=="+repr(SHA)+" and not status; print(json.dumps(dict(checked_utc=datetime.now(timezone.utc).isoformat(),sha=sha,status_porcelain=status,free_disk_bytes=shutil.disk_usage(p).free)))"])
    remote('remote-output',['mkdir','-p',REMOTE_OUTPUT])
    step('copy-minio-controller',['scp','-o','BatchMode=yes','-o','ConnectTimeout=10',str(BASE/'minio-control.py'),'morrobay:'+REMOTE_OUTPUT+'/minio-control.py'])
    remote('minio-start',['env','-u','PYTHONHOME','-u','PYTHONPATH',REMOTE_PYTHON,REMOTE_OUTPUT+'/minio-control.py','start'])
    command=json.loads((BASE/'planned-command.json').read_text())['command']
    step('fused-controller',command)
    remote('remote-source-end',['git','-C',REMOTE,'status','--porcelain'])
    remote('remote-sha-end',['git','-C',REMOTE,'rev-parse','HEAD'])
    assert not (BASE/'remote-source-end.log').read_text().strip()
    assert (BASE/'remote-sha-end.log').read_text().strip()==SHA
    remote('minio-inspect',['env','-u','PYTHONHOME','-u','PYTHONPATH',REMOTE_PYTHON,REMOTE_OUTPUT+'/minio-control.py','inspect'])
    receipt.update(outcome='passed; awaiting independent prefix scan before MinIO shutdown',local_source_after=state(),finished_utc=utc())
    assert receipt['local_source_after']=={'sha':SHA,'status_porcelain':''}
except BaseException as error:
    receipt.update(outcome='failed',error=repr(error),local_source_after=state(),finished_utc=utc())
    raise
finally:
    persist()
