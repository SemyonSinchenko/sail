# Pecan two-host functional evidence

Final candidate `4e6100f0320fb952e9926b867193ec1768edfcda` was exercised on
Capitola and Morrobay. Both frozen source inventories were clean. The Sail
runtime was preserved from `70b0d1cab2cab945d4dbaf6842ee0e38c8aa1822`, with
unchanged installed native packages inventoried in each receipt. These runs
qualify Pecan relational algorithms across two hosts. They do not qualify new
native Banda kernels and are not performance measurements.

| Final exercise | Iteration windows | Outcome |
| --- | --- | --- |
| `power` + `min_label` | 3 + 3 | Passed |
| `delta` + `randomized` | 72 + 2 | Passed |

For each of the four algorithms, completed tasks inside its recorded iteration
windows include both physical-host workers. Both driver supervisors returned
zero. Independent PID checks found all launched Sail processes stopped. The
optimized PageRank certificate was `4.1598713154678e-9` at tolerance `1e-8`;
its independently calculated stationary L1 error was `1.9815763550867782e-8`,
within the reported bound `2.7732474973859077e-8`. Both WCC methods produced
exact minimum-ID component labels, including the isolate.

`4e6100f0/` contains both final receipts, server/worker logs, controller logs,
exact harness sources, and explicit source/runtime provenance. The controller
logs are empty because both commands completed without controller diagnostics.

`713ffaeb/` preserves an earlier, unadopted candidate's reference exercise.
Its answers and worker placement passed, but its supervisor returned one after
a macOS process-group polling error. That historical receipt incorrectly says
`passed`: the accompanying `reference-review-observation.json` classifies it
as `supervisor_cleanup_failed`. The receipt is not rewritten. Its provenance
records two planned exercises; only the reference exercise ran on that candidate.
The final candidate fixes shutdown polling and rejects nonzero supervisor exit.

`manifest.json` records each original and exported SHA256, sizes, and any
redactions. Original evidence files remain intact. Standalone launcher configs
and private storage environment files are excluded. Environment-file paths in
receipts are retained; credential values are checked and redacted in the export.
No binaries or wheel files are included.

An independent post-run listing found zero objects under the scoped graph-run
prefix. The MinIO service was stopped and its endpoint closed before benchmark
timing work; see `4e6100f0/minio-cleanup.json`.
