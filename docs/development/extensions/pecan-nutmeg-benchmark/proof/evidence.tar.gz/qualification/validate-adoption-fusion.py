import json, subprocess
from datetime import datetime, timezone
from pathlib import Path

def git(*args): return subprocess.check_output(['git',*args],text=True).strip()
def read(p): return json.loads(Path(p).read_text())
base='a0dd29d586fc1cfc7d9f78adca09728a7945443a'
code='9d7155aa2302d9dda4e93e48ee3fd81aac1ee637'
final='3fd6978757713482942656cb0b23205fe57647d0'
assert git('rev-parse','HEAD')==base
assert git('rev-parse',code+'^')==base
assert git('rev-parse',final+'^')==code
assert git('write-tree')==git('rev-parse',final+'^{tree}')
subprocess.run(['git','diff','--quiet'],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
evidence=[]
def check(path):
 evidence.append(path); return read(path)
d=check('target/pecan-benchmark/gates-mac-fusion-9d7155aa/receipt.json')
assert d['outcome']=='passed' and d['source_sha']==code
assert d['source_after']['sha']==code and not d['source_after']['status_porcelain']
assert not d['runtime_processes_after']
assert [r['passed'] for r in d['runs']]==[95,84,84]
d=check('target/pecan-benchmark/gates-mac-native-fusion-9d7155aa/receipt.json')
assert d['expected_sha']==d['head_before']==d['head_after']==code
assert d['outcome']=='qualified_pass' and not d['failures'] and not d['status_after']
assert [(c['name'],c['exit_code']) for c in d['commands'] if c['exit_code']]==[('bridge-clippy-strict',101)]
d=check('target/extensions-pecan-benchmark/evidence/native-9d7155aa-evidence/native-release-receipt.json')
assert d['source_sha']==code and d['outcome']=='passed'
assert d['stress']['actual_pagerank_pool_widths']==[1,2,8]
assert d['tests']['optimized-quarter-cpu-tests.log'][0]['passed']==18
d=check('target/extensions-pecan-benchmark/evidence/python-3fd69787-evidence/receipt.json')
assert d['source_sha']==final and d['native_source_sha']==code and d['outcome']=='passed'
assert not d['staging_remaining_files']
d=check('target/extensions-pecan-benchmark/export/export-tutorial-3fd69787/evidence/tutorial-gate-receipt.json')
assert d['outcome']=='passed' and d['tutorial_source_sha']==final
assert d['benchmark_unit_tests']+d['launcher_unit_tests']==101
assert len(d['helper_cells'])==30 and all(c['outcome']=='passed' for c in d['helper_cells'])
assert d['persistent_api_calls']==15 and not d['remaining_staging_regular_files']
d=check('target/pecan-benchmark/two-host-fusion-3fd69787/qualification-verdict.json')
assert d['outcome']=='passed' and d['tested_run_source_sha']==final and d['algorithm_source_sha']==code
assert d['supervisor_returncode']==0 and d['minio_shutdown']['minio_stopped']
assert not d['independent_final_storage']['remaining_object_count']
assert all(not p['alive'] for ps in d['process_cleanup'].values() for p in ps)
assert all(len(w['workers'])==2 and w['completed_tasks']>0 for w in d['work_by_algorithm'].values())
d=check('target/extensions-pecan-benchmark/export/fusion-pilots-3fd69787-summary/summary.json')
assert d['planned_cells']==d['expected_outcomes_observed']==6
assert d['outcomes']=={'passed':6} and not d['integrity_errors']
assert d['sources']['harness_source_sha']==final and d['sources']['native_source_sha']==code
verdict='FUSION_ADOPTION_GATE '+final+' PASSED; bridge Clippy qualified only for existing large_enum_variant'
Path('target/pecan-benchmark/adoption-fusion-3fd69787.json').write_text(json.dumps(dict(recorded_utc=datetime.now(timezone.utc).isoformat(),base_sha=base,algorithm_sha=code,adopted_sha=final,evidence=evidence,verdict=verdict),indent=2)+'\n')
print(verdict)
