# Linux traversal qualification, 038c9b9597d3

This archive records functional qualification on Morrobay, Linux in Colima,
for source `038c9b9597d3fcf7e0b8c30c1253d7d77563f012`. It is not a performance
comparison. The Sail CLI is a development build; the native wheel and stress
executables are release builds. A separate release CLI build is pending outside
this archive and does not replace the runtime in these receipts.

## Verdict and boundaries

- Host: 258 library tests, strict all-target Clippy, and CLI build passed.
- Native graph core: 85 unit tests, one admission test, strict Clippy passed.
- Native extension: five FFI tests passed. Strict Clippy failed on the unchanged
  `mutation.rs` `Operation` large-enum finding. The failed receipt/log remain.
  The controlled rerun allowed only `clippy::large_enum_variant`; all other
  warnings remained errors. This is not an unqualified native strict-Clippy pass.
- Live tests: 51 passed locally and 51 with two process workers.
- Full calls: 36 local/process method combinations plus six Graph500 certificate
  cases passed, with delivered output hashes and staging cleanup checked.
- A separate bounded audit recomputed all 42 output vectors from exported edges
  using deque BFS and heap Dijkstra. The certificate cases still had no reference
  vector at execution time; this later audit is a distinct check on tiny inputs.
- Harness tests: 61 passed, 30 initially skipped. Three real-generator cases
  subsequently passed. The remaining 27 skips require external GAP/Parallel-SSSP
  control binaries; those controls are not Linux-qualified by this archive.
- Release stress: five idle runs and 90 saturated runs passed under a two-CPU,
  8 GiB, no-swap container limit. All load processes were reaped. CPU throttling
  counters prove the cap applied; these elapsed times are not benchmark numbers.

The bounded all-method fixture has 32 vertices and 79 edges. The official pinned
Graph500 generator produced 64 vertices and 256 tuples, with 48 reachable vertices.
Its canonical edge hash matches the earlier platform's fixture. Loops, duplicates,
and upstream float32 weights widened to float64 were preserved. Fixed source zero,
small input size and missing native SSSP parent output preclude an official
Graph500 benchmark claim. Banda remains driver-local in process-cluster mode.

## Evidence and reproduction

`handoff-summary.json` states counts, binary/wheel hashes and the lint boundary.
`host-gate/` retains the runtime build/tests. `build-logs/` preserves strict and
controlled native gates. `functional/` contains every command, outcome, input,
result Parquet and original receipt. `stress/` records all runs and cleanup;
`generator-tests/` records the additional real-generator tests.
`functional-independent-audit.json` is the separate full-vector audit.

`reproduce/` preserves the exact orchestration scripts, including the initial
strict failure and the explicitly qualified resume. They use private paths and
named Docker volumes on Morrobay; adapt paths in fresh directories to reproduce.
Build and launch scripts guard source SHA, clean checkout, disk capacity and the
older benchmark binary hash. The real generator is pinned to
`f89d643ce4aaae9a823d310c6ab2dd10e3d2982c`. Python packages use the source's locked
requirements. Every gate stores its commands and timestamps in its receipt.

Native wheel and Sail binaries are retained in the recorded Morrobay volume;
their hashes are included rather than bundling the large binaries. This archive
includes all small Parquet inputs and results for independent checking. To audit:

```bash
python reproduce/audit-functional.py /path/to/extracted/evidence
```

Run it on a working copy: it writes a fresh audit receipt.
It requires PyArrow 21.0.0 and verifies file hashes and all bounded
vectors without running Sail. `manifest.json` inventories every archived file.
