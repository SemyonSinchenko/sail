"""Independent bounded-fixture full-vector check of exported Linux results."""
import collections
import datetime
import hashlib
import heapq
import json
import math
from pathlib import Path
import sys

import pyarrow.parquet as pq

ROOT = Path(sys.argv[1]).resolve()
SUMMARY = json.loads((ROOT / 'functional/summary.json').read_text())
assert SUMMARY['outcome'] == 'passed' and len(SUMMARY['results']) == 42
assert not SUMMARY['failures']


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def reference(dataset, directed):
    vertices = pq.read_table(dataset / 'vertices.parquet').column('id').to_pylist()
    adjacency = {v: [] for v in vertices}
    for edge in pq.read_table(dataset / 'edges.parquet').to_pylist():
        u, v, weight = edge['src'], edge['dst'], edge['weight']
        assert u in adjacency and v in adjacency and math.isfinite(weight) and weight >= 0
        adjacency[u].append((v, weight))
        if not directed:
            adjacency[v].append((u, weight))
    bfs = {0: 0}
    frontier = collections.deque([0])
    while frontier:
        u = frontier.popleft()
        for v, _weight in adjacency[u]:
            if v not in bfs:
                bfs[v] = bfs[u] + 1
                frontier.append(v)
    distances = {0: 0.0}
    heap = [(0.0, 0)]
    while heap:
        distance, u = heapq.heappop(heap)
        if distances[u] != distance:
            continue
        for v, weight in adjacency[u]:
            candidate = distance + weight
            if candidate < distances.get(v, math.inf):
                distances[v] = candidate
                heapq.heappush(heap, (candidate, v))
    return {algorithm: {v: reached.get(v) for v in vertices}
            for algorithm, reached in [('bfs', bfs), ('sssp', distances)]}


references = {}
verified_files = {}
for name, directed in [('all-dataset', True), ('certificate-dataset', False)]:
    dataset = ROOT / 'functional' / name
    manifest = json.loads((dataset / 'manifest.json').read_text())
    for relative, detail in manifest['files'].items():
        path = dataset / relative
        assert path.is_relative_to(dataset) and '..' not in Path(relative).parts
        assert path.stat().st_size == detail['bytes'] and digest(path) == detail['sha256']
        verified_files[str(path.relative_to(ROOT))] = detail['sha256']
    references[name] = reference(dataset, directed)

rows = []
for cell in SUMMARY['results']:
    name = cell['cell']
    directory = ROOT / 'functional' / name
    original_path = directory / 'receipt.json'
    assert digest(original_path) == cell['original_receipt_sha256']
    original = json.loads(original_path.read_text())
    assert original['outcome'] == 'passed' and original['cleanup_errors'] == []
    assert original['staging_files_after_shutdown'] == []
    assert not list((directory / 'staging').rglob('*.parquet'))
    expected_files = {x['name']: x for x in original['result_files']}
    files = list((directory / 'result').rglob('*.parquet'))
    assert len(files) == len(expected_files) > 0
    for path in files:
        detail = expected_files[path.name]
        assert path.stat().st_size == detail['bytes'] and digest(path) == detail['sha256']
        verified_files[str(path.relative_to(ROOT))] = detail['sha256']
    command = cell['command']
    algorithm = command[command.index('--algorithm') + 1]
    certificate = name.startswith('certificate-')
    expected = references['certificate-dataset' if certificate else 'all-dataset'][algorithm]
    delivered = pq.read_table(directory / 'result').to_pylist()
    actual = {row['id']: row['distance'] for row in delivered}
    assert len(actual) == len(delivered) == len(expected) and set(actual) == set(expected)
    max_absolute_error = 0.0
    for vertex, value in expected.items():
        measured = actual[vertex]
        if value is None:
            assert measured is None, (name, vertex, measured)
            continue
        assert measured is not None and math.isfinite(measured)
        error = abs(measured - value)
        tolerance = 1e-12 * max(1.0, abs(value)) if certificate and algorithm == 'sssp' else 0.0
        assert error <= tolerance, (name, vertex, measured, value)
        max_absolute_error = max(max_absolute_error, error)
    rows.append(dict(cell=name, rows=len(actual), reached=sum(v is not None for v in expected.values()),
                     max_absolute_distance_error=max_absolute_error, outcome='passed'))
receipt = dict(recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), outcome='passed',
               source_sha=SUMMARY['source_sha'], auditor_sha256=digest(Path(__file__)),
               scope='42 bounded output vectors independently recomputed from exported edges; not a large-graph oracle',
               reference='independent deque BFS and heap Dijkstra; exact integer-fixture distances, 1e-12 relative/absolute floor for fractional SSSP',
               summary_sha256=digest(ROOT / 'functional/summary.json'), files=verified_files, results=rows)
(ROOT / 'functional-independent-audit.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: v for k, v in receipt.items() if k not in ('files', 'results')}, indent=2))
print('PASS', len(rows), 'bounded vectors;', len(verified_files), 'Parquet files hash-verified')
