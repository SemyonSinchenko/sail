"""Frozen Linux traversal build gate; no performance conclusions."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

SHA = "038c9b9597d3fcf7e0b8c30c1253d7d77563f012"
RUN = Path("/targets/traversal-linux-038c9b9597d3")
SOURCE = RUN / "source"
TARGET = RUN / "target"
VENV = RUN / "venv"
OLD = Path("/targets/portable-graphs/target-70b0d1cab2cab945d4dbaf6842ee0e38c8aa1822/debug/sail")
OLD_HASH = "6911cfa0f6cccc9d41fff4bcc88ec21257c731dbd12ff28af804fa36499e7f7c"
HOST_RECEIPT = Path("/targets/argentea/linux-038c9b9597d3-receipt.json")


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 << 20), b""):
            h.update(block)
    return h.hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=SOURCE, text=True).strip()


def guard():
    assert git("rev-parse", "HEAD") == SHA
    assert not git("status", "--porcelain")


def save():
    (RUN / "build-resume-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")


def step(name, command, cwd=SOURCE):
    guard()
    assert shutil.disk_usage(RUN).free > 12 << 30
    item = {"name": name, "command": list(map(str, command)), "started_utc": utc()}
    receipt["steps"].append(item)
    save()
    with (RUN / (name + ".log")).open("x") as output:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=output,
                                stderr=subprocess.STDOUT)
    item.update(finished_utc=utc(), returncode=result.returncode)
    guard()
    save()
    print(name, result.returncode, flush=True)
    if result.returncode:
        raise RuntimeError(name + " failed")


strict_path = RUN / "build-receipt.json"
strict = json.loads(strict_path.read_text())
assert strict["outcome"] == "failed" and strict["source_sha"] == SHA
assert strict["steps"][-1]["name"] == "native-clippy" and strict["steps"][-1]["returncode"] == 101
assert not (RUN / "build-resume-receipt.json").exists()
guard()
assert digest(OLD) == OLD_HASH
boundary = json.loads(Path("/work/traversal-linux-038c/lint-boundary.json").read_text())
assert digest(RUN / "native-clippy.log") == boundary["strict_log_sha256"]
assert digest(SOURCE / "examples/extensions/nutmeg/src/mutation.rs") == boundary["source_file_comparisons"][0]["sha256"]
receipt = dict(source_sha=SHA, purpose="Linux traversal build with disclosed preexisting lint exception", started_utc=utc(),
               outcome="running", steps=[], strict_receipt=str(strict_path), strict_receipt_sha256=digest(strict_path),
               native_clippy_boundary=boundary, python=strict["python"], protected_binary_sha256_before=digest(OLD),
               strict_native_clippy="failed", target=str(TARGET), free_bytes_before=shutil.disk_usage(RUN).free)
save()
env = dict(os.environ)
for key in ("PYTHONHOME", "PYTHONPATH", "LD_LIBRARY_PATH", "DYLD_LIBRARY_PATH"):
    env.pop(key, None)
python = str(VENV / "bin/python")
env.update(PATH="/root/.cargo/bin:/usr/local/cargo/bin:" + env["PATH"], RUSTUP_TOOLCHAIN="1.97.1",
           CARGO_INCREMENTAL="0", CARGO_BUILD_JOBS="16", CARGO_PROFILE_DEV_DEBUG="0", CARGO_PROFILE_TEST_DEBUG="0",
           CARGO_PROFILE_RELEASE_DEBUG="0", CARGO_TARGET_DIR=str(TARGET), PYTHONDONTWRITEBYTECODE="1",
           PYO3_PYTHON=python, LD_LIBRARY_PATH=strict["python"]["lib"])
core = SOURCE / "examples/extensions/vendor/nutmeg-graph/Cargo.toml"
native = SOURCE / "examples/extensions/nutmeg/Cargo.toml"
try:
    step("native-clippy-controlled", ["cargo", "clippy", "--locked", "--manifest-path", str(native),
                                     "--all-targets", "--", "-D", "warnings", "-A", "clippy::large_enum_variant"])
    step("core-release-build", ["cargo", "test", "--locked", "--release",
                                "--manifest-path", str(core), "--lib", "--no-run",
                                "--message-format=json"])
    artifacts = []
    for line in (RUN / "core-release-build.log").read_text().splitlines():
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        if value.get("reason") == "compiler-artifact" and value.get("executable") and value.get("profile", {}).get("test"):
            artifacts.append(value["executable"])
    assert len(artifacts) == 1, artifacts
    test_binary = Path(artifacts[0])
    receipt["release_test_binary"] = {"path": str(test_binary), "sha256": digest(test_binary)}
    step("native-release-build", ["cargo", "test", "--locked", "--release",
                                  "--manifest-path", str(native), "--lib", "--no-run",
                                  "--message-format=json"])
    native_artifacts = []
    for line in (RUN / "native-release-build.log").read_text().splitlines():
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        if value.get("reason") == "compiler-artifact" and value.get("executable") and value.get("profile", {}).get("test"):
            native_artifacts.append(value["executable"])
    assert len(native_artifacts) == 1, native_artifacts
    native_test = Path(native_artifacts[0])
    receipt["native_release_test_binary"] = {"path": str(native_test), "sha256": digest(native_test)}
    step("wheel", [python, "-m", "maturin", "build", "--locked", "--manifest-path", str(native),
                   "--release", "--interpreter", python, "--out", str(RUN / "wheels"), "--auditwheel", "repair"])
    wheels = list((RUN / "wheels").glob("*.whl"))
    assert len(wheels) == 1, wheels
    receipt["wheel"] = {"path": str(wheels[0]), "sha256": digest(wheels[0]), "bytes": wheels[0].stat().st_size}
    step("install-native", ["uv", "pip", "install", "--python", python, "--no-deps", str(wheels[0])])
    package = RUN / "pecan-package"
    shutil.copytree(SOURCE / "examples/extensions/graph-algorithms", package)
    step("install-pecan", ["uv", "pip", "install", "--python", python, "--no-deps", str(package)])
    receipt["installed_packages"] = subprocess.check_output(["uv", "pip", "freeze", "--python", python], text=True)
    receipt["outcome"] = "passed_with_disclosed_lint"
except BaseException as error:
    receipt.update(outcome="failed", error=repr(error))
    raise
finally:
    receipt.update(finished_utc=utc(), free_bytes_after=shutil.disk_usage(RUN).free,
                   protected_binary_sha256_after=digest(OLD))
    if receipt["protected_binary_sha256_after"] != OLD_HASH:
        receipt.update(outcome="failed", error="protected old binary changed")
    save()
    guard()
    assert receipt["protected_binary_sha256_after"] == OLD_HASH
print("PASS Linux traversal build with disclosed baseline lint " + SHA, flush=True)
