"""Frozen Linux traversal build gate; no performance conclusions."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

SHA = "038c9b9597d3fcf7e0b8c30c1253d7d77563f012"
RUN = Path("/targets/traversal-linux-038c9b9597d3")
SOURCE = RUN / "source"
TARGET = RUN / "target"
VENV = RUN / "venv"
OLD = Path("/targets/portable-graphs/target-70b0d1cab2cab945d4dbaf6842ee0e38c8aa1822/debug/sail")
OLD_HASH = "6911cfa0f6cccc9d41fff4bcc88ec21257c731dbd12ff28af804fa36499e7f7c"
HOST_RECEIPT = Path("/targets/argentea/linux-038c9b9597d3-receipt.json")


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 << 20), b""):
            h.update(block)
    return h.hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=SOURCE, text=True).strip()


def guard():
    assert git("rev-parse", "HEAD") == SHA
    assert not git("status", "--porcelain")


def save():
    (RUN / "build-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")


def step(name, command, cwd=SOURCE):
    guard()
    assert shutil.disk_usage(RUN).free > 12 << 30
    item = {"name": name, "command": list(map(str, command)), "started_utc": utc()}
    receipt["steps"].append(item)
    save()
    with (RUN / (name + ".log")).open("x") as output:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=output,
                                stderr=subprocess.STDOUT)
    item.update(finished_utc=utc(), returncode=result.returncode)
    guard()
    save()
    print(name, result.returncode, flush=True)
    if result.returncode:
        raise RuntimeError(name + " failed")


host = json.loads(HOST_RECEIPT.read_text())
assert host["source_sha"] == SHA and host["outcome"] == "passed", host
assert host["protected_sha256_after"] == OLD_HASH
assert digest(OLD) == OLD_HASH
assert not RUN.exists()
RUN.mkdir()
assert shutil.disk_usage(RUN).free > 35 << 30
receipt = {"source_sha": SHA, "purpose": "Linux functional qualification; not benchmark timings",
           "started_utc": utc(), "outcome": "running", "steps": [],
           "host_receipt": str(HOST_RECEIPT), "host_receipt_sha256": digest(HOST_RECEIPT),
           "protected_binary_sha256_before": digest(OLD), "target": str(TARGET),
           "free_bytes_before": shutil.disk_usage(RUN).free}
save()
env = dict(os.environ)
for key in ("PYTHONHOME", "PYTHONPATH", "LD_LIBRARY_PATH", "DYLD_LIBRARY_PATH"):
    env.pop(key, None)
env.update(PATH="/root/.cargo/bin:/usr/local/cargo/bin:" + env["PATH"],
           RUSTUP_TOOLCHAIN="1.97.1", CARGO_INCREMENTAL="0", CARGO_BUILD_JOBS="16",
           CARGO_PROFILE_DEV_DEBUG="0", CARGO_PROFILE_TEST_DEBUG="0",
           CARGO_PROFILE_RELEASE_DEBUG="0", CARGO_TARGET_DIR=str(TARGET),
           PYTHONDONTWRITEBYTECODE="1")
try:
    subprocess.run(["git", "--git-dir=/targets/linux-gates/repository.git", "worktree",
                    "add", "--detach", str(SOURCE), SHA], check=True, env=env)
    guard()
    seed = Path("/targets/pecan-benchmark/native-9d7155aa2302d9dda4e93e48ee3fd81aac1ee637/target")
    subprocess.run(["cp", "-a", "--reflink=auto", str(seed), str(TARGET)], check=True)
    receipt["seed_target"] = str(seed)
    base_python = "/targets/linux-gates/venv-de8e670989edb8ed5343764c52d0d002b6b6cd63/bin/python"
    step("venv", ["uv", "venv", "--python", base_python, str(VENV)])
    python = str(VENV / "bin/python")
    step("dependencies", ["uv", "pip", "sync", "--python", python,
                          str(SOURCE / "examples/extensions/requirements.lock")])
    config = json.loads(subprocess.check_output([python, "-I", "-c",
        'import sys,sysconfig,json; print(json.dumps(dict(base=sys.base_prefix,lib=sysconfig.get_config_var("LIBDIR"),purelib=sysconfig.get_path("purelib"),version=sys.version)))'], text=True))
    env.update(PYO3_PYTHON=python, LD_LIBRARY_PATH=config["lib"])
    receipt.update(python=config, rust=subprocess.check_output(["rustc", "--version"], env=env, text=True).strip(),
                   uname=subprocess.check_output(["uname", "-a"], text=True).strip(),
                   cgroup={k: (Path("/sys/fs/cgroup") / k).read_text().strip()
                           for k in ("cpu.max", "memory.max", "memory.swap.max")})
    core = SOURCE / "examples/extensions/vendor/nutmeg-graph/Cargo.toml"
    native = SOURCE / "examples/extensions/nutmeg/Cargo.toml"
    step("core-tests", ["cargo", "test", "--locked", "--manifest-path", str(core)])
    step("core-clippy", ["cargo", "clippy", "--locked", "--manifest-path", str(core),
                         "--all-targets", "--", "-D", "warnings"])
    step("native-tests", ["cargo", "test", "--locked", "--manifest-path", str(native),
                          "--lib", "--", "--skip", "argentea::"])
    step("native-clippy", ["cargo", "clippy", "--locked", "--manifest-path", str(native),
                           "--all-targets", "--", "-D", "warnings"])
    step("core-release-build", ["cargo", "test", "--locked", "--release",
                                "--manifest-path", str(core), "--lib", "--no-run",
                                "--message-format=json"])
    artifacts = []
    for line in (RUN / "core-release-build.log").read_text().splitlines():
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        if value.get("reason") == "compiler-artifact" and value.get("executable") and value.get("profile", {}).get("test"):
            artifacts.append(value["executable"])
    assert len(artifacts) == 1, artifacts
    test_binary = Path(artifacts[0])
    receipt["release_test_binary"] = {"path": str(test_binary), "sha256": digest(test_binary)}
    step("native-release-build", ["cargo", "test", "--locked", "--release",
                                  "--manifest-path", str(native), "--lib", "--no-run",
                                  "--message-format=json"])
    native_artifacts = []
    for line in (RUN / "native-release-build.log").read_text().splitlines():
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            continue
        if value.get("reason") == "compiler-artifact" and value.get("executable") and value.get("profile", {}).get("test"):
            native_artifacts.append(value["executable"])
    assert len(native_artifacts) == 1, native_artifacts
    native_test = Path(native_artifacts[0])
    receipt["native_release_test_binary"] = {"path": str(native_test), "sha256": digest(native_test)}
    step("wheel", [python, "-m", "maturin", "build", "--locked", "--manifest-path", str(native),
                   "--release", "--interpreter", python, "--out", str(RUN / "wheels"), "--auditwheel", "repair"])
    wheels = list((RUN / "wheels").glob("*.whl"))
    assert len(wheels) == 1, wheels
    receipt["wheel"] = {"path": str(wheels[0]), "sha256": digest(wheels[0]), "bytes": wheels[0].stat().st_size}
    step("install-native", ["uv", "pip", "install", "--python", python, "--no-deps", str(wheels[0])])
    package = RUN / "pecan-package"
    shutil.copytree(SOURCE / "examples/extensions/graph-algorithms", package)
    step("install-pecan", ["uv", "pip", "install", "--python", python, "--no-deps", str(package)])
    receipt["installed_packages"] = subprocess.check_output(["uv", "pip", "freeze", "--python", python], text=True)
    receipt["outcome"] = "passed"
except BaseException as error:
    receipt.update(outcome="failed", error=repr(error))
    raise
finally:
    receipt.update(finished_utc=utc(), free_bytes_after=shutil.disk_usage(RUN).free,
                   protected_binary_sha256_after=digest(OLD))
    if receipt["protected_binary_sha256_after"] != OLD_HASH:
        receipt.update(outcome="failed", error="protected old binary changed")
    save()
    guard()
    assert receipt["protected_binary_sha256_after"] == OLD_HASH
print("PASS Linux traversal build " + SHA, flush=True)
