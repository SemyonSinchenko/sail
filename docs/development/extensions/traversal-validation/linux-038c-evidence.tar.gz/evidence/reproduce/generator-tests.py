"""Fill the three real-generator gates skipped before Linux generator build."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

RUN = Path('/targets/traversal-linux-038c9b9597d3')
SOURCE = RUN / 'source'
BENCH = SOURCE / 'examples/extensions/benchmarks'
OUT = RUN / 'generator-tests'
SHA = '038c9b9597d3fcf7e0b8c30c1253d7d77563f012'
assert not OUT.exists()
OUT.mkdir()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip() == SHA
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=SOURCE, text=True).strip()
functional = json.loads((RUN / 'functional/summary.json').read_text())
assert functional['outcome'] == 'passed'
generator = RUN / 'functional/graph500-stream'
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', GRAPH500_SOURCE=str(RUN / 'graph500-upstream'),
           GRAPH500_MATRIX_GENERATOR=str(generator), PYTHONPATH=str(BENCH))
env['PATH'] = str(RUN / 'venv/bin') + ':' + env['PATH']
command = [str(RUN / 'venv/bin/python'), '-m', 'pytest', '-q', '-p', 'no:cacheprovider',
           str(BENCH / 'test_graph500_fixture.py') + '::test_real_generator_chunk_invariance_manifest_and_small_oracle',
           str(BENCH / 'test_graph500_fixture.py') + '::test_real_generator_rejects_stale_binary_and_retains_failed_preparation',
           str(BENCH / 'test_graph500_matrix.py') + '::test_preparation_command_generates_real_graph500_fixture']
receipt = dict(source_sha=SHA, started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), command=command,
               generator_sha256=hashlib.sha256(generator.read_bytes()).hexdigest(),
               outcome='running', scope='real-generator chunk invariance, stale binary refusal and matrix preparation')
with (OUT / 'pytest.log').open('x') as output:
    result = subprocess.run(command, cwd=SOURCE, env=env, stdout=output, stderr=subprocess.STDOUT)
text = (OUT / 'pytest.log').read_text()
passed = result.returncode == 0 and '3 passed' in text and 'skipped' not in text
receipt.update(returncode=result.returncode, finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               outcome='passed' if passed else 'failed', log_sha256=hashlib.sha256(text.encode()).hexdigest())
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip() == SHA
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=SOURCE, text=True).strip()
print(text, flush=True)
raise SystemExit(0 if passed else 1)
