import datetime
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/Users/alexy/src/sail-extensions-gates')
RUN = ROOT / 'traversal-linux-038c'
DOCKER = ['/usr/local/bin/docker', '--context', 'colima-sail-gate']
NAME = 'sail-traversal-build-resume-linux-038c'


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


old = json.loads((RUN / 'container-build.json').read_text())
assert old['outcome'] == 'failed'
image = old['image_id']
path = RUN / 'container-build-resume.json'
assert not path.exists()
command = [*DOCKER, 'run', '--init', '--name', NAME, '--cpus', '16', '--memory', '56g', '--memory-swap', '56g',
           '--mount', 'type=volume,source=sail-extension-targets,target=/targets',
           '--mount', 'type=volume,source=sail-extension-cargo-registry,target=/usr/local/cargo/registry',
           '--mount', f'type=bind,source={ROOT},target=/work,readonly', '-e', 'PYTHONDONTWRITEBYTECODE=1',
           '--entrypoint', '/targets/traversal-linux-038c9b9597d3/venv/bin/python', image,
           '-I', '/work/traversal-linux-038c/build-resume.py']
receipt = dict(started_utc=utc(), command=command, image_id=image, container_name=NAME,
               script_sha256=hashlib.sha256((RUN / 'build-resume.py').read_bytes()).hexdigest(),
               outcome='running', strict_native_clippy='failed; retained in original build receipt')
path.write_text(json.dumps(receipt, indent=2) + '\n')
with (RUN / 'container-build-resume.log').open('x') as log:
    result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
receipt.update(finished_utc=utc(), returncode=result.returncode, outcome='passed' if result.returncode == 0 else 'failed')
for field in ['State', 'HostConfig']:
    receipt[field] = json.loads(subprocess.check_output([*DOCKER, 'inspect', NAME, '--format', '{{json .' + field + '}}'], text=True))
path.write_text(json.dumps(receipt, indent=2) + '\n')
subprocess.run([*DOCKER, 'cp', NAME + ':/targets/traversal-linux-038c9b9597d3/build-resume-receipt.json',
                str(RUN / 'build-resume-receipt.json')], check=False)
print('RESUMED BUILD RETURN', result.returncode, flush=True)
raise SystemExit(result.returncode)
