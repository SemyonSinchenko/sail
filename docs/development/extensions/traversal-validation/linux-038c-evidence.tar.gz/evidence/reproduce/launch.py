"""Host supervisor: start the private native gate only after the host gate passes."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/Users/alexy/src/sail-extensions-gates')
RUN = ROOT / 'traversal-linux-038c'
HOST = ROOT / 'argentea'
DOCKER = ['/usr/local/bin/docker', '--context', 'colima-sail-gate']
NAME = 'sail-traversal-build-linux-038c'
SHA = '038c9b9597d3fcf7e0b8c30c1253d7d77563f012'


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


receipt_path = RUN / 'container-build.json'
assert not receipt_path.exists()
receipt = dict(started_utc=utc(), outcome='waiting-for-host-gate', source_sha=SHA,
               script_sha256=hashlib.sha256((RUN / 'build.py').read_bytes()).hexdigest())
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
deadline = time.monotonic() + 10800
while True:
    path = HOST / 'linux-038c9b9597d3-receipt.json'
    if path.exists():
        host = json.loads(path.read_text())
        if host.get('outcome') == 'failed':
            receipt.update(outcome='blocked-by-host-failure', finished_utc=utc())
            receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
            raise SystemExit(1)
        if host.get('outcome') == 'passed':
            break
    if time.monotonic() > deadline:
        raise TimeoutError('host gate did not complete within supervisor window')
    time.sleep(20)
assert host['source_sha'] == SHA
assert host['protected_sha256_after'] == '6911cfa0f6cccc9d41fff4bcc88ec21257c731dbd12ff28af804fa36499e7f7c'
image = json.loads((HOST / 'linux-038c9b9597d3-container.json').read_text())['image_id']
command = [*DOCKER, 'run', '--init', '--name', NAME, '--cpus', '16', '--memory', '56g',
           '--memory-swap', '56g', '--mount', 'type=volume,source=sail-extension-targets,target=/targets',
           '--mount', 'type=volume,source=sail-extension-cargo-registry,target=/usr/local/cargo/registry',
           '--mount', f'type=bind,source={ROOT},target=/work,readonly',
           '-e', 'PYTHONDONTWRITEBYTECODE=1', '--entrypoint',
           '/targets/linux-gates/venv-de8e670989edb8ed5343764c52d0d002b6b6cd63/bin/python',
           image, '-I', '/work/traversal-linux-038c/build.py']
receipt.update(outcome='running', command=command, image_id=image, container_name=NAME,
               build_started_utc=utc())
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
with (RUN / 'container-build.log').open('x') as output:
    result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
receipt.update(finished_utc=utc(), returncode=result.returncode,
               outcome='passed' if result.returncode == 0 else 'failed')
for field in ['State', 'HostConfig']:
    receipt[field] = json.loads(subprocess.check_output(
        [*DOCKER, 'inspect', NAME, '--format', '{{json .' + field + '}}'], text=True))
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
subprocess.run([*DOCKER, 'cp', NAME + ':/targets/traversal-linux-038c9b9597d3/build-receipt.json',
                str(RUN / 'build-receipt.json')], check=False)
print('LINUX TRAVERSAL BUILD RETURN', result.returncode, flush=True)
raise SystemExit(result.returncode)
