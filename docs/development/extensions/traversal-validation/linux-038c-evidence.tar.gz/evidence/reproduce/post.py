"""Run functional and capped stress containers after the native build passes."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/Users/alexy/src/sail-extensions-gates')
RUN = ROOT / 'traversal-linux-038c'
DOCKER = ['/usr/local/bin/docker', '--context', 'colima-sail-gate']
BASE = '/targets/traversal-linux-038c9b9597d3'


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save():
    (RUN / 'post-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')


assert not (RUN / 'post-receipt.json').exists()
receipt = dict(started_utc=utc(), outcome='waiting-for-native-build', phases=[])
save()
deadline = time.monotonic() + 21600
while True:
    build = json.loads((RUN / 'container-build.json').read_text())
    if build['outcome'] in ('failed', 'blocked-by-host-failure'):
        receipt.update(outcome='blocked-by-native-build', finished_utc=utc())
        save()
        raise SystemExit(1)
    if build['outcome'] == 'passed':
        break
    if time.monotonic() > deadline:
        raise TimeoutError('native build did not complete within supervisor window')
    time.sleep(20)
image = build['image_id']
receipt.update(outcome='running')
save()
for phase, script, cpus, memory in [('functional', 'qualify.py', '8', '32g'), ('stress', 'stress.py', '2', '8g')]:
    name = 'sail-traversal-' + phase + '-linux-038c'
    command = [*DOCKER, 'run', '--init', '--name', name, '--cpus', cpus, '--memory', memory,
               '--memory-swap', memory, '--mount', 'type=volume,source=sail-extension-targets,target=/targets',
               '--mount', f'type=bind,source={ROOT},target=/work,readonly', '-e', 'PYTHONDONTWRITEBYTECODE=1',
               '--entrypoint', BASE + '/venv/bin/python', image, '-I', '/work/traversal-linux-038c/' + script]
    item = dict(phase=phase, started_utc=utc(), command=command, script_sha256=hashlib.sha256((RUN / script).read_bytes()).hexdigest())
    receipt['phases'].append(item)
    save()
    with (RUN / ('container-' + phase + '.log')).open('x') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    item.update(finished_utc=utc(), returncode=result.returncode)
    for field in ['State', 'HostConfig']:
        item[field] = json.loads(subprocess.check_output([*DOCKER, 'inspect', name, '--format', '{{json .' + field + '}}'], text=True))
    subprocess.run([*DOCKER, 'cp', name + ':' + BASE + '/' + phase, str(RUN / phase)], check=False)
    save()
    print(phase, result.returncode, flush=True)
receipt.update(finished_utc=utc(), outcome='passed' if all(p['returncode'] == 0 for p in receipt['phases']) else 'failed')
save()
raise SystemExit(0 if receipt['outcome'] == 'passed' else 1)
