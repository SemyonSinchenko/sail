"""Replay Linux traversal correctness and retained lifecycle evidence."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

SHA = "038c9b9597d3fcf7e0b8c30c1253d7d77563f012"
RUN = Path("/targets/traversal-linux-038c9b9597d3")
SOURCE = RUN / "source"
BENCH = SOURCE / "examples/extensions/benchmarks"
PYTHON = RUN / "venv/bin/python"
HOST = Path("/targets/argentea/sail-linux-x86_64-038c9b9597d3")
OUT = RUN / "functional"


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 << 20), b""):
            h.update(block)
    return h.hexdigest()


def guard():
    assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=SOURCE, text=True).strip() == SHA
    assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=SOURCE, text=True).strip()


def save():
    path = OUT / "summary.json"
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(receipt, indent=2) + "\n")
    temporary.replace(path)


def command(name, args, *, environment=None, cwd=SOURCE, require=True):
    guard()
    item = dict(name=name, command=list(map(str, args)), started_utc=utc())
    receipt["steps"].append(item)
    save()
    with (OUT / (name + ".log")).open("x") as stream:
        result = subprocess.run(args, cwd=cwd, env=environment or env, stdout=stream,
                                stderr=subprocess.STDOUT)
    item.update(finished_utc=utc(), returncode=result.returncode)
    guard()
    save()
    print(name, result.returncode, flush=True)
    if require and result.returncode:
        raise RuntimeError(name + " failed")
    return result.returncode


def cell(mode, engine, algorithm, variant, dataset, *, certificate=False):
    name = ("certificate" if certificate else mode) + "-" + engine + "-" + algorithm + "-" + variant
    output = OUT / name
    args = [str(PYTHON), str(BENCH / "graph_cell.py"), "--sail-binary", str(HOST),
            "--runtime-source-sha", SHA, "--native-source-sha", SHA,
            "--dataset", str(dataset), "--output", str(output), "--engine", engine,
            "--algorithm", algorithm, "--variant", variant, "--mode", mode,
            "--partitions", "2", "--threads", "4", "--native-quota", "2147483648",
            "--sail-pool-bytes", "8589934592", "--source", "0", "--allow-unisolated"]
    args += ["--delta", "0.1", "--no-directed", "--traversal-validation", "certificate"] if certificate else ["--delta", "4", "--directed"]
    rc = command(name, args, require=False)
    row = dict(cell=name, command=args, returncode=rc, outcome="missing_receipt")
    receipt["results"].append(row)
    try:
        original = json.loads((output / "receipt.json").read_text())
        row.update(outcome=original["outcome"], original_receipt_sha256=digest(output / "receipt.json"),
                   correctness=original.get("correctness"), cleanup_errors=original.get("cleanup_errors"),
                   staging_files_after_shutdown=original.get("staging_files_after_shutdown"))
        assert rc == 0 and original["outcome"] == "passed", row
        assert original["runtime_source_sha"] == original["native_source_sha"] == original["harness_source_sha"] == SHA
        assert original["binary_sha256"] == receipt["binary_sha256"]
        assert original["source_dirty"] == ""
        assert original["cleanup_errors"] == []
        assert original["staging_files_after_shutdown"] == []
        assert not list((output / "staging").rglob("*.parquet"))
        assert original["correctness"]["rows"] == original["correctness"]["unique"] == (64 if certificate else 32)
        if certificate:
            assert original["correctness"]["reached"] == 48
            assert original["correctness"]["reference"] == "distributed certificate; no precomputed reference vector"
        result_files = list((output / "result").rglob("*.parquet"))
        expected = {x["name"]: x for x in original["result_files"]}
        assert len(result_files) == len(expected) > 0
        for path in result_files:
            assert digest(path) == expected[path.name]["sha256"]
            assert path.stat().st_size == expected[path.name]["bytes"]
        row["output_files_rechecked"] = len(result_files)
    except BaseException as error:
        row.update(qualification_error=repr(error))
        receipt["failures"].append(name)
    save()


build = json.loads((RUN / "build-resume-receipt.json").read_text())
assert build["outcome"] == "passed_with_disclosed_lint" and build["source_sha"] == SHA
assert not OUT.exists()
OUT.mkdir()
guard()
env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", SPARK_CONNECT_MODE_ENABLED="1")
for key in ("PYTHONHOME", "PYTHONPATH", "LD_LIBRARY_PATH", "DYLD_LIBRARY_PATH"):
    env.pop(key, None)
env["PYTHONPATH"] = str(BENCH)
env["LD_LIBRARY_PATH"] = build["python"]["lib"]
env["PATH"] = str(PYTHON.parent) + ":" + env["PATH"]
receipt = dict(source_sha=SHA, started_utc=utc(), outcome="running", steps=[], results=[], failures=[],
               purpose="Linux functional correctness and lifecycle qualification; reused container, no benchmark timing claims",
               build_receipt_sha256=digest(RUN / "build-resume-receipt.json"), binary_sha256=digest(HOST),
               cgroup={k: (Path("/sys/fs/cgroup") / k).read_text().strip()
                       for k in ("cpu.max", "memory.max", "memory.swap.max")})
save()
try:
    unit = sorted(BENCH.glob("test_traversal*.py")) + sorted(BENCH.glob("test_graph500*.py")) + [BENCH / "test_tutorial_methods.py"]
    unit.remove(BENCH / "test_traversal_certificate.py")
    command("harness-tests", [str(PYTHON), "-m", "pytest", "-q", "-p", "no:cacheprovider", *map(str, unit)])
    all_dataset = OUT / "all-dataset"
    command("all-fixture", [str(PYTHON), str(BENCH / "traversal_fixture.py"), "--output", str(all_dataset),
                             "--vertices", "32", "--degree", "2", "--seed", "42", "--source", "0", "--directed"])
    fixture = json.loads((all_dataset / "manifest.json").read_text())
    assert fixture["counts"] == {"vertices": 32, "edges": 79}
    receipt["all_fixture_manifest_sha256"] = digest(all_dataset / "manifest.json")
    sys.path.insert(0, str(BENCH))
    from runtime import server
    for mode in ("local", "process-cluster"):
        live_out = OUT / ("live-tests-" + mode)
        live_out.mkdir()
        cleanup_errors = []
        with server(HOST, live_out, mode, 2, 4, 2147483648, cleanup_errors,
                    worker_task_slots=16, sail_pool_bytes=8589934592) as (endpoint, _pid):
            live_env = dict(env, SAIL_GRAPH_TEST_REMOTE=endpoint)
            files = [SOURCE / "examples/extensions/graph-algorithms/tests/test_traversal.py",
                     SOURCE / "examples/extensions/graph-algorithms/tests/test_algorithms.py",
                     BENCH / "test_traversal_certificate.py"]
            command("live-tests-" + mode, [str(PYTHON), "-m", "pytest", "-q", "-p", "no:cacheprovider", *map(str, files)],
                    environment=live_env)
        assert cleanup_errors == []
        assert not list((live_out / "staging").rglob("*.parquet"))
        for engine in ("pecan", "nutmeg-native", "nutmeg-datafusion"):
            for algorithm in ("bfs", "sssp"):
                for variant in ("reference", "frontier", "push_pull" if algorithm == "bfs" else "delta_star"):
                    cell(mode, engine, algorithm, variant, all_dataset)
    generator_source = RUN / "graph500-upstream"
    command("graph500-clone", ["git", "clone", "--no-checkout", "https://github.com/graph500/graph500.git", str(generator_source)])
    command("graph500-checkout", ["git", "-C", str(generator_source), "checkout", "--detach", "f89d643ce4aaae9a823d310c6ab2dd10e3d2982c"])
    generator = OUT / "graph500-stream"
    command("graph500-build", ["bash", str(BENCH / "traversal-controls/build_graph500.sh"), str(generator_source), str(generator)])
    cert_dataset = OUT / "certificate-dataset"
    command("graph500-fixture", [str(PYTHON), str(BENCH / "graph500_fixture.py"), "--generator", str(generator),
                                 "--output", str(cert_dataset), "--scale", "6", "--edge-factor", "4", "--seed1", "42",
                                 "--seed2", "54", "--source", "0", "--no-directed", "--expected-edge-sha256",
                                 "8b357f4aafb3b20085725f3d74a02c1910062d42a6173d8886ec0edfb72f2a0f"])
    receipt["certificate_fixture_manifest_sha256"] = digest(cert_dataset / "manifest.json")
    for engine in ("pecan", "nutmeg-native", "nutmeg-datafusion"):
        for algorithm, variant in (("bfs", "push_pull"), ("sssp", "delta_star")):
            cell("process-cluster", engine, algorithm, variant, cert_dataset, certificate=True)
    assert len(receipt["results"]) == 42
    assert not receipt["failures"], receipt["failures"]
    receipt["outcome"] = "passed"
except BaseException as error:
    receipt.update(outcome="failed", error=repr(error))
    raise
finally:
    receipt["finished_utc"] = utc()
    save()
    guard()
print("PASS Linux traversal functional " + SHA, flush=True)
