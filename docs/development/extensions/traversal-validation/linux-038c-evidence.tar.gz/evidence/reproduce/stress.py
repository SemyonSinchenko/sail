"""Run the frozen release tests with saturation inside a CPU-capped container."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

RUN = Path('/targets/traversal-linux-038c9b9597d3')
SOURCE = RUN / 'source'
OUT = RUN / 'stress'
SHA = '038c9b9597d3fcf7e0b8c30c1253d7d77563f012'


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(8 << 20), b''):
            h.update(block)
    return h.hexdigest()


def stats():
    return {k: int(v) for k, v in (line.split() for line in Path('/sys/fs/cgroup/cpu.stat').read_text().splitlines())}


def guard():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip() == SHA
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=SOURCE, text=True).strip()


def save():
    (OUT / 'summary.json').write_text(json.dumps(receipt, indent=2) + '\n')


build = json.loads((RUN / 'build-resume-receipt.json').read_text())
assert build['outcome'] == 'passed_with_disclosed_lint'
assert not OUT.exists()
OUT.mkdir()
guard()
tests = [
    ('parallel-bfs', 'optimized::tests_bfs::direction_bfs_matches_reference_and_exercises_parallel_push_pull'),
    ('pull-work-meter', 'optimized::tests_bfs::direction_bfs_pull_charges_and_checks_blocks_without_edges'),
    ('parallel-stepping', 'optimized::tests_stepping::parallel_stepping_matches_dijkstra_across_buckets_widths_and_zero_cycles'),
    ('traversal-resources', 'optimized::tests_traversal_resources::traversal_refusals_and_stream_stop_release_scratch_but_retain_exported_arrays'),
    ('ffi-cancellation', 'tests::dropped_blocked_stream_cancels_and_keeps_exported_batch_valid'),
]
receipt = dict(source_sha=SHA, purpose='Functional stress only, no timing comparison', started_utc=utc(), outcome='running', steps=[],
               build_receipt_sha256=digest(RUN / 'build-resume-receipt.json'), cpu_before=stats(),
               cgroup={k: (Path('/sys/fs/cgroup') / k).read_text().strip()
                       for k in ('cpu.max', 'memory.max', 'memory.swap.max')})
save()
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', LD_LIBRARY_PATH=build['python']['lib'])
try:
    for short, test in tests:
        is_ffi = short == 'ffi-cancellation'
        artifact = build['native_release_test_binary' if is_ffi else 'release_test_binary']
        binary = Path(artifact['path'])
        assert digest(binary) == artifact['sha256']
        manifest = SOURCE / ('examples/extensions/nutmeg/Cargo.toml' if is_ffi else 'examples/extensions/vendor/nutmeg-graph/Cargo.toml')
        output = OUT / (short + '.json')
        command = [str(RUN / 'venv/bin/python'), str(SOURCE / 'examples/extensions/nutmeg/scripts/stress_cancel.py'),
                   '--manifest-path', str(manifest), '--test-binary', str(binary), '--runs', '10' if is_ffi else '20',
                   '--test-name', test, '--output', str(output)]
        item = dict(name=short, command=command, started_utc=utc())
        receipt['steps'].append(item)
        save()
        with (OUT / (short + '.log')).open('x') as log:
            result = subprocess.run(command, env=env, cwd=SOURCE, stdout=log, stderr=subprocess.STDOUT)
        item.update(finished_utc=utc(), returncode=result.returncode)
        save()
        if result.returncode:
            raise RuntimeError(short + ' failed')
        proof = json.loads(output.read_text())
        assert proof['unchanged'] and proof['head_before'] == proof['head_after'] == SHA
        assert len(proof['runs']) == (11 if is_ffi else 21)
        assert all(row['exit_code'] == 0 and '1 passed' in row['stdout'] and '0 failed' in row['stdout'] for row in proof['runs'])
        assert digest(binary) == artifact['sha256']
        item.update(receipt_sha256=digest(output), executed_runs=len(proof['runs']))
        guard()
        print(short, 'PASS', len(proof['runs']), flush=True)
    receipt['cpu_after'] = stats()
    assert receipt['cpu_after']['nr_throttled'] > receipt['cpu_before']['nr_throttled']
    # The shared driver terminates and waits for each exact child it starts.
    # The private container additionally must have no remaining load process.
    listing = subprocess.check_output(['ps', '-eo', 'comm='], text=True)
    assert 'yes' not in listing.splitlines()
    receipt.update(outcome='passed', saturated_runs=90, unsaturated_runs=5, remaining_yes_processes=0)
except BaseException as error:
    receipt.update(outcome='failed', error=repr(error))
    raise
finally:
    receipt.update(finished_utc=utc(), cpu_final=stats())
    save()
    guard()
print('PASS Linux traversal release stress ' + SHA, flush=True)
