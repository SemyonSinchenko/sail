# Linux RELEASE traversal qualification and prepared campaign

Harness: 538b94cbb99298f94667cde29e94b3e4cefe60fc (clean source).
Runtime and native sources: 038c9b9597d3fcf7e0b8c30c1253d7d77563f012.
Host release binary SHA256: c66eeaa32ef9d3c2355ddceb167f9c0a0ce952a8e8a522a9c6d9f002fef0b39c.
Nutmeg release wheel SHA256: 0086af1beaec92f9797e6224a9e8fd949efc3ae01d24270489d56c26a958ddc3.
Sedona wheel SHA256: 7aad880b8ffe911af14faf1f7522a6108c0d1d4b26fa2df22c4d6dec1532e06d.
The Sedona artifact path is recorded; its directory name alone is not a claim
about the source commit used to build that artifact.

`supervisor.json` records bootstrap, qualification, preparation: each exit zero,
no OOM kill, and all evidence copies succeeded. Private containers had four CPUs,
20 GiB and no swap. This was functional qualification on a shared outer host;
cell timings in raw receipts are not publishable performance measurements.

`qualification/summary.json`: 54 passed cells: 36 local/process × Pecan/Banda/
Grenada × BFS/SSSP methods, six Graph500 certificate controls, and twelve real
65,536-vertex imported-topology controls using both independent references and
scalable certificates. Focused Linux harness tests: 71 passed, one optional
external-generator control skipped. Actual Sedona distance queries returned all
17 expected rows in both local and process modes; all54 cell server logs also
record both Sedona and Nutmeg native registrations. Installation alone is not
used as proof of loading.

Correction to older immutable Linux038c DEV42 evidence: its generic extension
prose was overbroad. That earlier environment proved Nutmeg traversal correctness,
but did not prove sail-sedona-extension loaded; it contained apache-sedona instead.
Those archived receipts are unchanged. This RELEASE gate supplies independent
actual Sedona execution and registration evidence.

`independent-output-audit.json` rechecks all54 full output vectors,135 input/output
file hashes and787,968 result rows after copying to Capitola. For the tiny64-vertex
Graph500 fixture the auditor reconstructs BFS/heap-Dijkstra independently; other
cells use retained independent reference vectors. All maximum errors are zero.
The auditor is included and hashed; this audit does not reinterpret performance.

`preparation/summary.json` retains four prepared weighted Graph Kernels datasets.
Original topology hashes, all partition hashes and canonical weighted hashes are
in the four manifests. Weights are explicit SplitMix64-1-16, seed42; source0,
directed. Original topology rows, duplicate arcs and loops retain input order.
The large datasets remain in the private Linux volume; this archive contains
manifests and preparation receipts, not those large Parquet files.

`preparation/matrix-final.json` and `matrix-plan.json` specify216 cells; the plan
was NOT EXECUTED as part of this qualification. Three repetitions for four graphs,
three paths and three variants of each of BFS and SSSP. Every cell uses one fresh
container,16 CPUs,56 GiB/no swap,48 GiB Sail pool and32 GiB native quota, and a
30-minute inner /40-minute outer timeout. The host runner dry run exactly matched
all216 generated commands and configuration fingerprint. No outcome is assumed.

The finalized files live on Morrobay below
`/Users/alexy/src/sail-extensions-gates/graph-kernels-traversal-1f18`.
The volume namespace is `/targets/graph-kernels-traversal-1f18`.
After an explicit host-quiet reservation, the standalone launch command is:

```bash
root=/Users/alexy/src/sail-extensions-gates/graph-kernels-traversal-1f18
PATH=/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin /usr/bin/python3   "$root/host-harness/run_matrix.py"   --config "$root/preparation/matrix-final.json" --skip-prepare
```

The first run must not use `--resume`. If interrupted, preserve every recorded
outcome and use the same immutable config plus `--resume --skip-prepare` only
after inspecting the interruption. The runner stops on orchestration/copy errors.
Qualification and preparation did not start the measured campaign.

At the recorded preflight both Colima Docker contexts had no running containers;
the default Docker socket had no daemon. The large-fixture volume had40.3 GB free.
A conservative raw four8-byte-field result estimate is21.7 GB across216 cells,
not a hard bound on Parquet/staging/diagnostic overhead. Monitor remaining disk;
do not delete failed-cell evidence to make a campaign appear complete.
