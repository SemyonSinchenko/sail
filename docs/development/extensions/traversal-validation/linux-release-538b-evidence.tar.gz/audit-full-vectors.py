import collections,datetime,hashlib,heapq,json,math,pathlib
import pyarrow.parquet as pq
root=pathlib.Path('/tmp/sail-linux-release-traversal-538b-evidence');qroot=root/'qualification'
q=json.loads((qroot/'summary.json').read_text());assert q['outcome']=='passed' and len(q['results'])==54 and not q['failures']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
refs={};checked_files=0
for name in ['bounded-dataset','certificate-dataset','imported-dataset']:
 ds=qroot/name;m=json.loads((ds/'manifest.json').read_text());n=m['counts']['vertices']
 for path,pin in m['files'].items():
  p=ds/path;assert sha(p)==pin['sha256'];assert p.stat().st_size==pin['bytes'];checked_files+=1
 if (ds/'reference.parquet').exists():
  rows=pq.read_table(ds/'reference.parquet').to_pylist();refs[name]={a:{r['id']:r[a] for r in rows} for a in ['bfs','sssp']}
 else:
  assert n==64
  adj=[[] for _ in range(n)]
  for row in pq.read_table(ds/'edges.parquet').to_pylist():
   a,b,w=row['src'],row['dst'],row['weight'];adj[a].append((b,w));adj[b].append((a,w))
  refs[name]={}
  for algo in ['bfs','sssp']:
   distances=[math.inf]*n;distances[0]=0.;front=[(0.,0)]
   while front:
    d,u=heapq.heappop(front)
    if d!=distances[u]:continue
    for v,w in adj[u]:
     cand=d+(1. if algo=='bfs' else w)
     if cand<distances[v]:distances[v]=cand;heapq.heappush(front,(cand,v))
   refs[name][algo]=dict(enumerate(distances))
results=[]
for item in q['results']:
 cell=qroot/item['cell'];receipt=json.loads((cell/'receipt.json').read_text());assert sha(cell/'receipt.json')==item['receipt_sha256']
 assert receipt['outcome']=='passed' and receipt['cleanup_errors']==[] and receipt['staging_files_after_shutdown']==[]
 assert 'bound native extension sedona@' in (cell/'server.log').read_text() and 'bound native extension nutmeg@' in (cell/'server.log').read_text()
 expected={i['name']:i for i in receipt['result_files']};files=sorted((cell/'result').rglob('*.parquet'))
 assert set(expected)=={p.name for p in files};rows=[]
 for p in files:
  pin=expected[p.name];assert sha(p)==pin['sha256'] and p.stat().st_size==pin['bytes'];checked_files+=1;rows+=pq.read_table(p).to_pylist()
 ds=pathlib.Path(item['dataset']).name;algorithm='sssp' if '-sssp-' in item['cell'] else 'bfs';ref=refs[ds][algorithm]
 assert len(rows)==len(ref) and collections.Counter(r['id'] for r in rows)==collections.Counter(ref.keys())
 max_error=0.
 for row in rows:
  wanted=ref[row['id']];actual=row['distance']
  if wanted is None or math.isinf(wanted):assert actual is None or math.isinf(actual)
  else:
   assert actual is not None and math.isfinite(actual)
   error=abs(actual-wanted);assert error<=1e-12;max_error=max(max_error,error)
 results.append(dict(cell=item['cell'],rows=len(rows),max_absolute_error=max_error,reference='independent heap traversal of copied64V graph' if ds=='certificate-dataset' else 'retained independent BFS/heap-Dijkstra full vector'))
receipt=dict(recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),outcome='passed',cells=54,files_sha256_verified=checked_files,rows_compared=sum(r['rows'] for r in results),auditor_sha256=sha(pathlib.Path(__file__)),results=results,boundary='Detached local full-vector/hash re-audit of Linux functional outputs; no timing claim; certificate64V oracle reconstructed independently')
(root/'independent-output-audit.json').write_text(json.dumps(receipt,indent=2)+'\n');print({k:v for k,v in receipt.items() if k!='results'})
