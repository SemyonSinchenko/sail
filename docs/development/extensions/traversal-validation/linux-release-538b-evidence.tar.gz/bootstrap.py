import datetime,hashlib,json,os,shutil,subprocess
from pathlib import Path
SHA='538b94cbb99298f94667cde29e94b3e4cefe60fc'
RUN=Path('/targets/graph-kernels-traversal-1f18');SOURCE=RUN/'source';VENV=RUN/'venv'
OLD=Path('/targets/traversal-linux-038c9b9597d3')
HOST=Path('/targets/traversal-host-release-038c9b9597d3/sail-linux-x86_64-038c9b9597d3-release')
NATIVE=OLD/'wheels/sail_nutmeg-0.1.0-cp312-cp312-manylinux_2_34_x86_64.whl'
SEDONA=Path('/targets/linux-gates/target-de8e670989edb8ed5343764c52d0d002b6b6cd63/wheels/sail_sedona_extension-0.1.0-cp312-cp312-manylinux_2_34_x86_64.whl')
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8<<20),b''):h.update(b)
 return h.hexdigest()
assert not RUN.exists();RUN.mkdir()
r=dict(started_utc=utc(),outcome='running',harness_source_sha=SHA,runtime_source_sha='038c9b9597d3fcf7e0b8c30c1253d7d77563f012',native_source_sha='038c9b9597d3fcf7e0b8c30c1253d7d77563f012',steps=[],free_bytes_before=shutil.disk_usage(RUN).free)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',UV_LINK_MODE='copy')
for k in ('PYTHONHOME','PYTHONPATH','DYLD_LIBRARY_PATH','LD_LIBRARY_PATH'):env.pop(k,None)
def save():(RUN/'bootstrap-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
def step(name,args):
 with (RUN/(name+'.log')).open('x') as f:run=subprocess.run(list(map(str,args)),env=env,stdout=f,stderr=subprocess.STDOUT)
 r['steps'].append(dict(name=name,command=list(map(str,args)),returncode=run.returncode,finished_utc=utc()));save();print(name,run.returncode,flush=True)
 assert run.returncode==0,name
try:
 assert r['free_bytes_before']>15<<30
 for key,path in [('host',HOST),('native',NATIVE),('sedona',SEDONA)]:r[key]=dict(path=str(path),sha256=digest(path),bytes=path.stat().st_size)
 assert r['host']['sha256']=='c66eeaa32ef9d3c2355ddceb167f9c0a0ce952a8e8a522a9c6d9f002fef0b39c'
 assert r['native']['sha256']=='0086af1beaec92f9797e6224a9e8fd949efc3ae01d24270489d56c26a958ddc3'
 step('clone',['git','clone','--no-hardlinks','--no-checkout',OLD/'source',SOURCE])
 step('fetch',['git','-C',SOURCE,'fetch','/work/graph-kernels-traversal-1f18/source.bundle','refs/argentea/graph-kernels-traversal'])
 step('detach',['git','-C',SOURCE,'checkout','--detach',SHA])
 step('venv',['uv','venv','--python',OLD/'venv/bin/python',VENV])
 python=VENV/'bin/python'
 step('dependencies',['uv','pip','sync','--python',python,SOURCE/'examples/extensions/requirements.lock'])
 step('native-wheels',['uv','pip','install','--python',python,'--no-deps',NATIVE,SEDONA])
 package=RUN/'pecan-package';shutil.copytree(SOURCE/'examples/extensions/graph-algorithms',package)
 step('pecan',['uv','pip','install','--python',python,'--no-deps',package])
 r['python']=json.loads(subprocess.check_output([str(python),'-I','-c','import sys,sysconfig,json;print(json.dumps(dict(base=sys.base_prefix,lib=sysconfig.get_config_var("LIBDIR"),version=sys.version)))'],env=env,text=True))
 r['packages']=subprocess.check_output(['uv','pip','freeze','--python',str(python)],env=env,text=True)
 r['entry_points']=json.loads(subprocess.check_output([str(python),'-I','-c','import importlib.metadata as m,json;print(json.dumps([dict(name=e.name,value=e.value,distribution=e.dist.name) for e in m.entry_points(group="pysail.extensions")]))'],env=env,text=True))
 assert {e['name'] for e in r['entry_points']}=={'nutmeg','sedona','argentea'}
 assert subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip()==SHA
 assert not subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain'],text=True).strip()
 r['outcome']='passed'
except BaseException as e:r.update(outcome='failed',error=repr(e));raise
finally:r.update(finished_utc=utc(),free_bytes_after=shutil.disk_usage(RUN).free);save()
