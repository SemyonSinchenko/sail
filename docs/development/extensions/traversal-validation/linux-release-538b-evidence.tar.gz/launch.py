import datetime,hashlib,json,subprocess
from pathlib import Path
ROOT=Path('/Users/alexy/src/sail-extensions-gates');RUN=ROOT/'graph-kernels-traversal-1f18';BASE='/targets/graph-kernels-traversal-1f18'
DOCKER=['/usr/local/bin/docker','--context','colima-sail-gate'];IMAGE='sha256:f3518d652fbea8b9b9f9ebf9849277ca3bd39d0c21bb2c6e36fbaeaa2dc2678e'
record=dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),outcome='running',phases=[],boundary='release functional checks and fixture preparation only; no benchmark campaign')
path=RUN/'supervisor.json';assert not path.exists()
def save():path.write_text(json.dumps(record,indent=2)+'\n')
save()
for phase in ('bootstrap','qualify','prepare'):
 name='sail-graph-kernels-traversal-1f18-'+phase
 python='/targets/traversal-linux-038c9b9597d3/venv/bin/python' if phase=='bootstrap' else BASE+'/venv/bin/python'
 cmd=[*DOCKER,'run','--init','--name',name,'--cpus','4','--memory','20g','--memory-swap','20g','--mount','type=volume,source=sail-extension-targets,target=/targets','--mount',f'type=bind,source={ROOT},target=/work,readonly','-e','PYTHONDONTWRITEBYTECODE=1','--entrypoint',python,IMAGE,'-I','/work/graph-kernels-traversal-1f18/'+phase+'.py']
 item=dict(phase=phase,command=cmd,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),script_sha256=hashlib.sha256((RUN/(phase+'.py')).read_bytes()).hexdigest());record['phases'].append(item);save()
 with (RUN/(phase+'-container.log')).open('x') as f:run=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 item.update(returncode=run.returncode,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 item['state']=json.loads(subprocess.check_output([*DOCKER,'inspect',name,'--format','{{json .State}}'],text=True))
 targets={'bootstrap':['bootstrap-receipt.json'],'qualify':['qualification'],'prepare':['preparation']}[phase]
 for target in targets:
  copied=subprocess.run([*DOCKER,'cp',name+':'+BASE+'/'+target,str(RUN/target)],capture_output=True,text=True)
  item.setdefault('copies',[]).append(dict(path=target,returncode=copied.returncode,error=copied.stderr))
 save();print(phase,run.returncode,flush=True)
 if run.returncode or item['state']['OOMKilled']:
  record['outcome']='failed';break
else:record['outcome']='passed'
record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
raise SystemExit(0 if record['outcome']=='passed' else 1)
