"""Prepare pinned large inputs and a complete plan; never execute timed cells."""
import datetime,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
H='538b94cbb99298f94667cde29e94b3e4cefe60fc';R='038c9b9597d3fcf7e0b8c30c1253d7d77563f012'
BASE=Path('/targets/graph-kernels-traversal-1f18');SOURCE=BASE/'source';BENCH=SOURCE/'examples/extensions/benchmarks';PYTHON=BASE/'venv/bin/python';OUT=BASE/'preparation'
HOST=Path('/targets/traversal-host-release-038c9b9597d3/sail-linux-x86_64-038c9b9597d3-release')
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(8<<20),b''):h.update(b)
 return h.hexdigest()
def guard():
 assert subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip()==H
 assert not subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain'],text=True).strip()
assert json.loads((BASE/'qualification/summary.json').read_text())['outcome']=='passed'
assert not OUT.exists();OUT.mkdir();guard()
config=json.loads((BENCH/'graph-kernels-traversal-matrix.example.json').read_text())
config.update(run_id='gk-traversal-release-538b',image='sha256:f3518d652fbea8b9b9f9ebf9849277ca3bd39d0c21bb2c6e36fbaeaa2dc2678e',container_python=str(PYTHON),container_repo=str(SOURCE),container_sail_binary=str(HOST),runtime_source_sha=R,native_source_sha=R,harness_source_sha=H,container_root=str(BASE),host_output='/Users/alexy/src/sail-extensions-gates/graph-kernels-traversal-1f18/campaign')
record=dict(started_utc=utc(),outcome='running',harness_source_sha=H,runtime_source_sha=R,native_source_sha=R,host_sha256=sha(HOST),datasets=[],boundary='preparation and exact plan only; no measured campaign started',free_bytes_before=shutil.disk_usage(BASE).free)
assert record['free_bytes_before']>10<<30
bootstrap=json.loads((BASE/'bootstrap-receipt.json').read_text())
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONHOME',None);env.pop('PYTHONPATH',None)
env['LD_LIBRARY_PATH']=bootstrap['python']['lib']
sys.path.insert(0,str(BENCH));from run_matrix import dataset_command,plan_cells,cell_command,configuration_fingerprint
from graph_cell import validate_dataset_identity,validate_dataset_files

def save():(OUT/'summary.json').write_text(json.dumps(record,indent=2)+'\n')
save()
try:
 for name,options in config['datasets'].items():
  guard();command=[str(PYTHON),*dataset_command(config,name)]
  item=dict(name=name,command=command,started_utc=utc());record['datasets'].append(item);save()
  with (OUT/(name+'.log')).open('x') as log:run=subprocess.run(command,env=env,cwd=SOURCE,stdout=log,stderr=subprocess.STDOUT)
  item.update(returncode=run.returncode,finished_utc=utc());save();assert run.returncode==0,name
  dataset=BASE/'datasets'/name;manifest=json.loads((dataset/'manifest.json').read_text())
  assert manifest['counts']['vertices']==options['vertices']
  assert manifest['traversal']==dict(source=0,directed=True,weight_policy='splitmix64-1-16',weight_seed=42,source_policy='explicit fixed vertex')
  assert manifest['validation']['status']=='reference-not-generated' and not (dataset/'reference.parquet').exists()
  options['expected_edge_sha256']=manifest['canonical']['edges']['sha256']
  validate_dataset_identity(manifest,family='edge-list-traversal',vertices=options['vertices'],input_sha256=options['edge_sha256'],edge_sha256=options['expected_edge_sha256'],weight_policy=options['weight_policy'],weight_seed=options['weight_seed'])
  validate_dataset_files(dataset,manifest)
  for file in ('manifest.json','preparation.json'):shutil.copy2(dataset/file,OUT/(name+'-'+file))
  item.update(manifest_sha256=sha(dataset/'manifest.json'),canonical=manifest['canonical'],counts=manifest['counts'],original_input_sha256=manifest['input']['sha256'],parquet_files=len(manifest['files']),parquet_bytes=sum(v['bytes'] for v in manifest['files'].values()))
  save();guard();print(name,'PREPARED',options['expected_edge_sha256'],flush=True)
 cells=plan_cells(config);assert len(cells)==216
 plan=dict(configuration_sha256=configuration_fingerprint(config),configuration=config,cells=cells,commands={c['cell_id']:cell_command(config,c) for c in cells},randomized_order='Python random.Random(seed), shuffle independently within each suite/repetition',execution_status='NOT_STARTED')
 (OUT/'matrix-final.json').write_text(json.dumps(config,indent=2)+'\n')
 (OUT/'matrix-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
 record.update(outcome='prepared_not_run',planned_cells=len(cells),configuration_sha256=configuration_fingerprint(config),plan_sha256=sha(OUT/'matrix-plan.json'),free_bytes_after=shutil.disk_usage(BASE).free)
except BaseException as e:record.update(outcome='failed',error=repr(e));raise
finally:record['finished_utc']=utc();save();guard()
