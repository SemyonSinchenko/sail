"""Moderate-envelope Linux release runtime checks; never a timing campaign."""
import datetime,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
H='538b94cbb99298f94667cde29e94b3e4cefe60fc';R='038c9b9597d3fcf7e0b8c30c1253d7d77563f012'
BASE=Path('/targets/graph-kernels-traversal-1f18');SOURCE=BASE/'source';BENCH=SOURCE/'examples/extensions/benchmarks';PYTHON=BASE/'venv/bin/python';OUT=BASE/'qualification'
HOST=Path('/targets/traversal-host-release-038c9b9597d3/sail-linux-x86_64-038c9b9597d3-release')
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(8<<20),b''):h.update(b)
 return h.hexdigest()
def guard():
 assert subprocess.check_output(['git','-C',str(SOURCE),'rev-parse','HEAD'],text=True).strip()==H
 assert not subprocess.check_output(['git','-C',str(SOURCE),'status','--porcelain'],text=True).strip()
def save():(OUT/'summary.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert not OUT.exists();OUT.mkdir();guard()
bootstrap=json.loads((BASE/'bootstrap-receipt.json').read_text());assert bootstrap['outcome']=='passed'
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',SPARK_CONNECT_MODE_ENABLED='1')
for k in ('PYTHONHOME','PYTHONPATH','DYLD_LIBRARY_PATH','LD_LIBRARY_PATH'):env.pop(k,None)
env.update(PYTHONPATH=str(BENCH),LD_LIBRARY_PATH=bootstrap['python']['lib'],PATH=str(PYTHON.parent)+':'+env['PATH'])
receipt=dict(started_utc=utc(),outcome='running',harness_source_sha=H,runtime_source_sha=R,native_source_sha=R,host_sha256=digest(HOST),steps=[],results=[],failures=[],
 boundary='54 functional cells on RELEASE host/native; shared outer host, reused Linux container; no publishable performance claims',
 earlier_linux_scope_correction='The immutable earlier038c42-cell receipts proved traversal correctness with Nutmeg; their generic Sedona-loaded prose was overbroad. That environment had apache-sedona but not sail-sedona-extension. New environment inventories and actual Sedona checks follow.',
 bootstrap_sha256=digest(BASE/'bootstrap-receipt.json'),cgroup={k:(Path('/sys/fs/cgroup')/k).read_text().strip() for k in ('cpu.max','memory.max','memory.swap.max')})
assert receipt['host_sha256']=='c66eeaa32ef9d3c2355ddceb167f9c0a0ce952a8e8a522a9c6d9f002fef0b39c';save()
def command(name,args,required=True):
 guard();item=dict(name=name,command=list(map(str,args)),started_utc=utc());receipt['steps'].append(item);save()
 with (OUT/(name+'.log')).open('x') as log:r=subprocess.run(list(map(str,args)),env=env,cwd=SOURCE,stdout=log,stderr=subprocess.STDOUT)
 item.update(returncode=r.returncode,finished_utc=utc());guard();save();print(name,r.returncode,flush=True)
 if required:assert r.returncode==0,name
 return r.returncode

def cell(name,mode,engine,algorithm,variant,dataset,policy,*,directed=True,delta=4.):
 manifest=json.loads((dataset/'manifest.json').read_text())
 args=[PYTHON,BENCH/'graph_cell.py','--sail-binary',HOST,'--runtime-source-sha',R,'--native-source-sha',R,'--dataset',dataset,'--output',OUT/name,'--engine',engine,'--algorithm',algorithm,'--variant',variant,'--mode',mode,'--partitions','2','--threads','4','--worker-task-slots','32','--native-quota',str(2<<30),'--sail-pool-bytes',str(8<<30),'--source','0','--delta',str(delta),'--timeout','600','--allow-unisolated','--traversal-validation',policy,'--expected-dataset-family',manifest['family'],'--expected-vertices',str(manifest['counts']['vertices'])]
 args.append('--directed' if directed else '--no-directed')
 if manifest['family']=='edge-list-traversal':
  args+=['--expected-input-sha256',manifest['input']['sha256'],'--expected-edge-sha256',manifest['canonical']['edges']['sha256'],'--expected-weight-policy','splitmix64-1-16','--expected-weight-seed','42']
 elif manifest['family']=='graph500':args+=['--expected-graph500-sha256',manifest['canonical']['edges']['sha256']]
 rc=command(name,args,False);row=dict(cell=name,returncode=rc,outcome='missing_receipt',dataset=str(dataset),validation=policy);receipt['results'].append(row)
 try:
  p=OUT/name/'receipt.json';original=json.loads(p.read_text());row.update(outcome=original['outcome'],receipt_sha256=digest(p),correctness=original.get('correctness'),cleanup_errors=original.get('cleanup_errors'),staging_files_after_shutdown=original.get('staging_files_after_shutdown'))
  assert rc==0 and original['outcome']=='passed'
  assert original['harness_source_sha']==H and original['runtime_source_sha']==original['native_source_sha']==R
  assert original['binary_sha256']==receipt['host_sha256'] and not original['source_dirty']
  assert original['cleanup_errors']==[] and original['staging_files_after_shutdown']==[]
  assert original['correctness']['rows']==original['correctness']['unique']==manifest['counts']['vertices']
  assert not list((OUT/name/'staging').rglob('*.parquet'))
  logs=(OUT/name/'server.log').read_text()
  assert 'bound native extension sedona@' in logs and 'bound native extension nutmeg@' in logs, 'cell did not register both extensions'
  files=list((OUT/name/'result').rglob('*.parquet'));expected={i['name']:i for i in original['result_files']};assert len(files)==len(expected)>0
  for f in files:assert digest(f)==expected[f.name]['sha256'] and f.stat().st_size==expected[f.name]['bytes']
  row['output_files_rechecked']=len(files)
 except BaseException as e:row['qualification_error']=repr(e);receipt['failures'].append(name)
 save()
try:
 command('focused-harness-tests',[PYTHON,'-m','pytest','-q','-p','no:cacheprovider',BENCH/'test_imported_traversal.py',BENCH/'test_graph500_matrix.py',BENCH/'test_run_matrix.py'])
 sys.path.insert(0,str(BENCH));from runtime import server
 from pyspark.sql.connect.session import SparkSession
 from pyspark.sql.connect.client.retries import DefaultPolicy
 receipt['sedona_execution']=[]
 for mode in ('local','process-cluster'):
  output=OUT/('sedona-'+mode);output.mkdir();cleanup=[]
  with server(HOST,output,mode,2,4,2<<30,cleanup,worker_task_slots=32,sail_pool_bytes=8<<30) as (endpoint,pid):
   spark=SparkSession.builder.remote(endpoint).create();spark.client.set_retry_policies([DefaultPolicy(max_retries=0)])
   try:
    rows=[r.asDict() for r in spark.sql('SELECT id, ST_Distance(ST_Point(CAST(id AS DOUBLE),2.0), ST_Point(0.0,2.0)) AS distance FROM range(17) ORDER BY id').collect()]
    assert rows==[dict(id=i,distance=float(i)) for i in range(17)]
   finally:spark.stop()
  assert cleanup==[] and not list((output/'staging').rglob('*.parquet'))
  receipt['sedona_execution'].append(dict(mode=mode,rows=rows,cleanup_errors=cleanup,server_log_sha256=digest(output/'server.log')));save()
 bounded=OUT/'bounded-dataset'
 command('bounded-fixture',[PYTHON,BENCH/'traversal_fixture.py','--output',bounded,'--vertices','32','--degree','2','--seed','42','--source','0','--directed'])
 for mode in ('local','process-cluster'):
  for engine in ('pecan','nutmeg-native','nutmeg-datafusion'):
   for algorithm in ('bfs','sssp'):
    for variant in ('reference','frontier','push_pull' if algorithm=='bfs' else 'delta_star'):
     cell('-'.join((mode,engine,algorithm,variant)),mode,engine,algorithm,variant,bounded,'reference')
 generator=Path('/targets/traversal-linux-038c9b9597d3/functional/graph500-stream');certificate=OUT/'certificate-dataset'
 command('graph500-fixture',[PYTHON,BENCH/'graph500_fixture.py','--generator',generator,'--output',certificate,'--scale','6','--edge-factor','4','--seed1','42','--seed2','54','--source','0','--no-directed','--expected-edge-sha256','8b357f4aafb3b20085725f3d74a02c1910062d42a6173d8886ec0edfb72f2a0f'])
 for engine in ('pecan','nutmeg-native','nutmeg-datafusion'):
  for algorithm,variant in (('bfs','push_pull'),('sssp','delta_star')):
   cell('-'.join(('graph500',engine,algorithm,variant)),'process-cluster',engine,algorithm,variant,certificate,'certificate',directed=False,delta=.1)
 imported=OUT/'imported-dataset';pins=json.loads((BENCH/'large-fixtures.json').read_text())['fixtures'];pin=next(p for p in pins if p['name']=='hub-65536.edges')
 command('imported-fixture',[PYTHON,BENCH/'imported_traversal_fixture.py','--edge-file','/targets/pecan-benchmark/large-inputs/hub-65536.edges','--edge-sha256',pin['sha256'],'--vertices',str(pin['nodes']),'--weight-policy','splitmix64-1-16','--weight-seed','42','--source','0','--directed','--reference','--output',imported])
 for policy in ('reference','certificate'):
  for engine in ('pecan','nutmeg-native','nutmeg-datafusion'):
   for algorithm,variant in (('bfs','push_pull'),('sssp','delta_star')):
    cell('-'.join(('imported',policy,engine,algorithm,variant)),'process-cluster',engine,algorithm,variant,imported,policy)
 assert len(receipt['results'])==54
 assert not receipt['failures'],receipt['failures']
 receipt['outcome']='passed'
except BaseException as e:receipt.update(outcome='failed',error=repr(e));raise
finally:receipt['finished_utc']=utc();guard();save()
